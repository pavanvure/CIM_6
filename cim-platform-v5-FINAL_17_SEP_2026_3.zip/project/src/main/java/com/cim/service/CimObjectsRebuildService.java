package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.RawCimObject;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.ValidationJobRepository;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

/**
 * Rebuilds cim_objects from raw_objects by re-applying the CIM type filter.
 *
 * WHY:
 *   When the CimTypeFilterConfig changes (new types added, types removed),
 *   existing cim_objects for past imports are stale. This service:
 *     1. Deletes existing cim_objects for the job/org+version
 *     2. Re-reads raw_objects (complete, unfiltered)
 *     3. Re-applies the current CimTypeFilterConfig
 *     4. Writes new cim_objects
 *
 * raw_objects are NEVER modified — they are the source of truth.
 */
@Service
public class CimObjectsRebuildService {

    private static final Logger log = LoggerFactory.getLogger(CimObjectsRebuildService.class);
    private static final int BATCH = 500;

    private final MongoTemplate              mongo;
    private final CimTypeFilterService       filterService;
    private final ValidationJobRepository    jobRepo;
    private final CimObjectRecordRepository  objectRepo;

    public CimObjectsRebuildService(MongoTemplate mongo,
                                     CimTypeFilterService filterService,
                                     ValidationJobRepository jobRepo,
                                     CimObjectRecordRepository objectRepo) {
        this.mongo         = mongo;
        this.filterService = filterService;
        this.jobRepo       = jobRepo;
        this.objectRepo    = objectRepo;
    }

    // ── Rebuild by jobId ──────────────────────────────────────────────────

    public RebuildResult rebuildByJobId(String jobId) {
        com.cim.model.mongo.ValidationJob job = jobRepo.findByJobId(jobId)
                .orElseThrow(() -> new IllegalArgumentException("Job not found: " + jobId));
        return rebuild(jobId, job.getOrgId(),
                "jobId=" + jobId + " orgId=" + job.getOrgId());
    }

    // ── Rebuild by orgId + networkVersion ─────────────────────────────────

    public List<RebuildResult> rebuildByOrgAndVersion(String orgId, String version) {
        // Find all jobIds matching org + version
        Query q = new Query(Criteria.where("orgId").is(orgId)
                .and("networkVersion").is(version));
        q.fields().include("jobId");
        List<Document> jobs = mongo.find(q, Document.class, "validation_jobs");
        if (jobs.isEmpty())
            throw new IllegalArgumentException(
                    "No jobs found for orgId=" + orgId + " version=" + version);

        List<RebuildResult> results = new ArrayList<>();
        for (Document j : jobs) {
            String jId = j.getString("jobId");
            try {
                results.add(rebuild(jId, orgId,
                        "orgId=" + orgId + " version=" + version + " jobId=" + jId));
            } catch (Exception e) {
                log.error("Rebuild failed for jobId={}: {}", jId, e.getMessage());
                results.add(new RebuildResult(jId, orgId, version, 0, 0, 0,
                        "FAILED: " + e.getMessage()));
            }
        }
        return results;
    }

    // ── Core rebuild logic ────────────────────────────────────────────────

    private RebuildResult rebuild(String jobId, String orgId, String context) {
        log.info("Rebuild cim_objects: {}", context);
        Instant start = Instant.now();

        // Step 1: Load current filter for this org
        Set<String> allowedTypes = filterService.getAllowedTypes(orgId);
        log.info("Rebuild filter: {} types for orgId={} (empty=no filter)",
                allowedTypes.size(), orgId);

        // Step 2: Delete existing cim_objects for this job
        Query deleteQ = new Query(Criteria.where("jobId").is(jobId));
        long deleted = mongo.remove(deleteQ, "cim_objects").getDeletedCount();
        log.info("Rebuild: deleted {} existing cim_objects for jobId={}", deleted, jobId);

        // Step 3: Re-read raw_objects and rebuild cim_objects
        long rawCount = 0, cimCount = 0;
        String lastId = null;
        List<CimObjectRecord> writeBatch = new ArrayList<>(BATCH);

        while (true) {
            Query rawQ = new Query(Criteria.where("jobId").is(jobId));
            if (lastId != null)
                rawQ.addCriteria(Criteria.where("_id").gt(
                        new org.bson.types.ObjectId(lastId)));
            rawQ.limit(BATCH);
            rawQ.with(org.springframework.data.domain.Sort.by("_id"));

            List<Document> rawBatch = mongo.find(rawQ, Document.class, "raw_objects");
            if (rawBatch.isEmpty()) break;

            lastId = rawBatch.get(rawBatch.size()-1)
                    .getObjectId("_id").toHexString();

            for (Document raw : rawBatch) {
                rawCount++;
                String cimType = raw.getString("cimType");

                // Apply filter — same logic as during initial parse
                if (!filterService.isAllowed(cimType, allowedTypes)) continue;

                // Convert raw_objects doc back to CimObjectRecord shape
                CimObjectRecord rec = toCimObjectRecord(raw, jobId);
                if (rec != null) {
                    writeBatch.add(rec);
                    cimCount++;
                }

                if (writeBatch.size() >= BATCH) {
                    objectRepo.saveAll(new ArrayList<>(writeBatch));
                    writeBatch.clear();
                }
            }
        }
        // Final batch
        if (!writeBatch.isEmpty()) objectRepo.saveAll(writeBatch);

        long durationMs = Instant.now().toEpochMilli() - start.toEpochMilli();
        log.info("Rebuild complete: jobId={} rawRead={} cimWritten={} in {}ms",
                jobId, rawCount, cimCount, durationMs);

        // Update validation_jobs with new totalObjects count
        org.springframework.data.mongodb.core.query.Update u =
                new org.springframework.data.mongodb.core.query.Update()
                        .set("totalObjects", (int) cimCount)
                        .set("lastRebuildAt", Instant.now())
                        .push("phaseHistory",
                                buildRebuildPhase(start, cimCount, allowedTypes.size()));
        mongo.updateFirst(new Query(Criteria.where("jobId").is(jobId)),
                u, "validation_jobs");

        String version = jobRepo.findByJobId(jobId)
                .map(j -> j.getNetworkVersion()).orElse("unknown");
        return new RebuildResult(jobId, orgId, version,
                rawCount, cimCount, durationMs, "COMPLETED");
    }

    /**
     * Convert a raw_objects Document back into a CimObjectRecord.
     * raw_objects stores the vendor-format shape; we copy the CIM-relevant
     * fields (rdfId, mrid, cimType, attributes, resolvedRefIds, pathIssues).
     */
    @SuppressWarnings("unchecked")
    private CimObjectRecord toCimObjectRecord(Document raw, String jobId) {
        try {
            CimObjectRecord rec = new CimObjectRecord();
            rec.setJobId(jobId);
            rec.setRdfId(raw.getString("rdfId"));
            rec.setMrid(raw.getString("mrid"));
            rec.setCimType(raw.getString("cimType"));
            rec.setName(raw.getString("name"));
            rec.setOrgId(raw.getString("orgId"));
            rec.setVersion(raw.getString("version"));
            rec.setSourceFormat(raw.getString("sourceFormat"));
            rec.setSourceFile(raw.getString("sourceFile"));
            rec.setCreatedAt(raw.get("createdAt", Instant.class));

            // Copy attributes and resolvedRefIds as-is
            Document attrs = raw.get("attributes", Document.class);
            if (attrs != null)
                rec.setAttributes(new java.util.LinkedHashMap<>(attrs));
            Document refs = raw.get("resolvedRefIds", Document.class);
            if (refs != null)
                rec.setResolvedRefIds(new java.util.LinkedHashMap<>(refs));

            return rec;
        } catch (Exception e) {
            log.warn("toCimObjectRecord failed for rdfId={}: {}",
                    raw.getString("rdfId"), e.getMessage());
            return null;
        }
    }

    private com.cim.model.mongo.PhaseRecord buildRebuildPhase(
            Instant start, long count, int filterSize) {
        return new com.cim.model.mongo.PhaseRecord(
            "CIM_OBJECTS_REBUILD",
            start, Instant.now(), count, "COMPLETED", null,
            String.format("Rebuilt cim_objects: %,d documents written " +
                          "from raw_objects. Filter: %s types.",
                    count, filterSize == 0 ? "none (all types)" : filterSize));
    }

    // ── Result DTO ────────────────────────────────────────────────────────

    public static class RebuildResult {
        public final String jobId;
        public final String orgId;
        public final String networkVersion;
        public final long   rawObjectsRead;
        public final long   cimObjectsWritten;
        public final long   durationMs;
        public final String status;

        public RebuildResult(String jobId, String orgId, String networkVersion,
                              long rawRead, long cimWritten, long durationMs,
                              String status) {
            this.jobId            = jobId;
            this.orgId            = orgId;
            this.networkVersion   = networkVersion;
            this.rawObjectsRead   = rawRead;
            this.cimObjectsWritten = cimWritten;
            this.durationMs       = durationMs;
            this.status           = status;
        }
    }
}
