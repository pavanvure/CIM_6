package com.cim.service;

import com.cim.model.mongo.CimTypeFilterConfig;
import com.cim.repository.CimTypeFilterConfigRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Manages the CIM type filter for cim_objects collection.
 *
 * LOGIC:
 *   1. Look for an org-specific enabled config (orgId matches)
 *   2. Fall back to global enabled config (orgId is null/blank)
 *   3. If no config found — store ALL types (no filtering)
 *
 * raw_objects ALWAYS receives ALL types regardless of this config.
 * cim_objects only receives types in allowedTypes when a filter is active.
 *
 * This keeps cim_objects lean (only Neo4j-relevant types) while
 * raw_objects remains the complete audit record of all parsed data.
 */
@Service
public class CimTypeFilterService {

    private static final Logger log = LoggerFactory.getLogger(CimTypeFilterService.class);

    private final CimTypeFilterConfigRepository repo;

    public CimTypeFilterService(CimTypeFilterConfigRepository repo) {
        this.repo = repo;
    }

    /**
     * Returns the set of allowed cimTypes for the given org.
     * Empty set means NO filter — all types are allowed.
     *
     * @param orgId the org being imported
     * @return Set of allowed cimType strings, or empty set if no filter configured
     */
    public Set<String> getAllowedTypes(String orgId) {
        // Try org-specific config first
        if (orgId != null && !orgId.isBlank()) {
            Optional<CimTypeFilterConfig> orgConfig =
                    repo.findByOrgIdAndEnabledTrue(orgId);
            if (orgConfig.isPresent()) {
                Set<String> types = new HashSet<>(orgConfig.get().getAllowedTypes());
                log.info("CimTypeFilter: org-specific filter for orgId={} — {} types",
                        orgId, types.size());
                return types;
            }
        }
        // Fall back to global config
        Optional<CimTypeFilterConfig> globalConfig =
                repo.findByOrgIdIsNullAndEnabledTrue();
        if (globalConfig.isPresent()) {
            Set<String> types = new HashSet<>(globalConfig.get().getAllowedTypes());
            log.info("CimTypeFilter: global filter applied — {} types", types.size());
            return types;
        }
        // No filter configured — allow all types
        log.debug("CimTypeFilter: no filter configured for orgId={} — storing all types", orgId);
        return Collections.emptySet();
    }

    /**
     * Returns true if the given cimType should be stored in cim_objects.
     * Returns true always if no filter is configured (empty allowedTypes).
     *
     * @param cimType      the CIM class name to check
     * @param allowedTypes the filter set from getAllowedTypes()
     */
    public boolean isAllowed(String cimType, Set<String> allowedTypes) {
        if (allowedTypes.isEmpty()) return true;  // no filter — allow all
        return allowedTypes.contains(cimType);
    }

    // ── CRUD helpers used by the config API ───────────────────────────────

    public List<CimTypeFilterConfig> findAll() {
        return repo.findAll();
    }

    public Optional<CimTypeFilterConfig> findById(String id) {
        return repo.findById(id);
    }

    public CimTypeFilterConfig save(CimTypeFilterConfig config) {
        config.setUpdatedAt(java.time.Instant.now());
        if (config.getCreatedAt() == null)
            config.setCreatedAt(config.getUpdatedAt());
        return repo.save(config);
    }

    public void delete(String id) {
        repo.deleteById(id);
    }
}
