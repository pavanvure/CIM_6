package com.cim.config;

import com.mongodb.MongoClientSettings;
import org.bson.UuidRepresentation;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.mongodb.core.index.CompoundIndexDefinition;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexOperations;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.bson.Document;

/**
 * MongoDB configuration.
 * Key setting: dot replacement for attribute map keys.
 * CIM attributes use dots (ACLineSegment.r) — MongoDB rejects dots in keys.
 * Replace with U+FF0E (FULLWIDTH FULL STOP) as a safe substitute.
 */
@Configuration
public class MongoConfig {

    @Bean
    public MongoTemplate mongoTemplate(MongoDatabaseFactory factory,
                                        MappingMongoConverter converter) {
        converter.setTypeMapper(new DefaultMongoTypeMapper(null));
        converter.setMapKeyDotReplacement("_");
        return new MongoTemplate(factory, converter);
    }

    /**
     * Creates all required MongoDB indexes on startup.
     *
     * CRITICAL INDEXES FOR CimEnrichmentService:
     *
     *   cim_objects: {jobId, _id}
     *     → fetchPage() cursor — without this, every page scan does a full
     *       950k-document collection scan. O(n²) total = 1.5 hour hang.
     *
     *   cim_objects: {jobId, cimType}
     *     → all buildXxxMap() methods filter by jobId+cimType.
     *       Without this: 950k scan per map build. With this: instant.
     *
     *   cim_objects: {jobId, cimType, rdfId}
     *     → enrichWithRegions batched $in queries on rdfId.
     *
     *   cim_objects: {jobId, cimType, mrid}
     *     → SGR lookup by mrid.
     *
     *   raw_objects: {jobId, _id}
     *     → CimObjectsRebuildService fetchPage() on raw_objects.
     *
     *   validation_jobs: {jobId} unique
     *     → every job lookup uses jobId — must be unique index.
     */
    @EventListener(ContextRefreshedEvent.class)
    public void ensureIndexes(ContextRefreshedEvent event) {
        MongoTemplate mongo = event.getApplicationContext().getBean(MongoTemplate.class);
        try {
            ensureCimObjectsIndexes(mongo);
            ensureRawObjectsIndexes(mongo);
            ensureValidationJobsIndexes(mongo);
            ensureOtherIndexes(mongo);
        } catch (Exception e) {
            // Non-fatal — app starts without indexes, just slower
            org.slf4j.LoggerFactory.getLogger(MongoConfig.class)
                    .warn("Index creation warning (non-fatal): {}", e.getMessage());
        }
    }

    private void ensureCimObjectsIndexes(MongoTemplate mongo) {
        IndexOperations idx = mongo.indexOps("cim_objects");

        // ── CRITICAL: jobId + _id for fetchPage() cursor pagination ──────
        // Without this: O(n²) full scans during enrichment = 1.5hr hang
        idx.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("_id", 1))
                .named("cim_jobId_id"));

        // ── jobId + cimType for all buildXxxMap() queries ─────────────────
        // All map-building queries filter by both: jobId + cimType
        idx.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("cimType", 1))
                .named("cim_jobId_cimType"));

        // ── jobId + cimType + rdfId for batched $in substation lookups ────
        idx.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("cimType", 1).append("rdfId", 1))
                .named("cim_jobId_cimType_rdfId"));

        // ── jobId + cimType + mrid for SGR/GR mrid lookups ───────────────
        idx.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("cimType", 1).append("mrid", 1))
                .named("cim_jobId_cimType_mrid"));

        // ── rdfId alone for reference resolution cross-lookups ────────────
        idx.ensureIndex(new Index("rdfId", Sort.Direction.ASC)
                .named("cim_rdfId"));

        // ── orgId + version for Neo4j export queries ──────────────────────
        idx.ensureIndex(new CompoundIndexDefinition(
                new Document("orgId", 1).append("version", 1))
                .named("cim_orgId_version"));

        org.slf4j.LoggerFactory.getLogger(MongoConfig.class)
                .info("cim_objects indexes ensured (6 indexes)");
    }

    private void ensureRawObjectsIndexes(MongoTemplate mongo) {
        IndexOperations idx = mongo.indexOps("raw_objects");

        // fetchPage() in CimObjectsRebuildService pages raw_objects by jobId + _id
        idx.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("_id", 1))
                .named("raw_jobId_id"));

        // cimType filter during rebuild
        idx.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("cimType", 1))
                .named("raw_jobId_cimType"));

        org.slf4j.LoggerFactory.getLogger(MongoConfig.class)
                .info("raw_objects indexes ensured (2 indexes)");
    }

    private void ensureValidationJobsIndexes(MongoTemplate mongo) {
        IndexOperations idx = mongo.indexOps("validation_jobs");

        // Every job lookup uses jobId — unique
        idx.ensureIndex(new Index("jobId", Sort.Direction.ASC)
                .unique().named("vj_jobId_unique"));

        // Progress API: lookup by orgId + networkVersion
        idx.ensureIndex(new CompoundIndexDefinition(
                new Document("orgId", 1).append("networkVersion", 1))
                .named("vj_orgId_version"));

        org.slf4j.LoggerFactory.getLogger(MongoConfig.class)
                .info("validation_jobs indexes ensured (2 indexes)");
    }

    private void ensureOtherIndexes(MongoTemplate mongo) {
        // cim_classes: lookup by className
        mongo.indexOps("cim_classes").ensureIndex(
                new Index("className", Sort.Direction.ASC)
                        .unique().named("cls_className_unique"));

        // namespace_configs: lookup by prefix + orgId
        mongo.indexOps("namespace_configs").ensureIndex(
                new CompoundIndexDefinition(
                        new Document("prefix", 1).append("orgId", 1))
                        .named("ns_prefix_orgId"));

        // cim_type_filter_configs: lookup by orgId + enabled
        mongo.indexOps("cim_type_filter_configs").ensureIndex(
                new CompoundIndexDefinition(
                        new Document("orgId", 1).append("enabled", 1))
                        .named("ctf_orgId_enabled"));

        org.slf4j.LoggerFactory.getLogger(MongoConfig.class)
                .info("Supporting collection indexes ensured");
    }
}
