package com.cim.controller;

import com.cim.model.mongo.ValidationJob;
import com.cim.repository.ValidationJobRepository;
import com.cim.service.ImportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.core.env.Environment;

import java.util.*;
import io.swagger.annotations.*;
import com.cim.model.api.ApiResponseModels.*;

/**
 * Import REST API
 *
 * All endpoints accept version and orgId:
 *   version → X-Network-Version header or ?version= param
 *   orgId   → X-Org-Id header
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ImportController {

    private static final long LARGE = 50L * 1024 * 1024;

    private final ImportService                              importService;
    private final ValidationJobRepository                    jobRepo;
    private final com.cim.repository.RawCimObjectRepository  rawRepo;
    private final com.cim.repository.CimObjectRecordRepository objectRepo;
    private final com.cim.service.ArchiveExtractorService     archiveExtractor;

    public ImportController(ImportService importService,
                              ValidationJobRepository jobRepo,
                              com.cim.repository.RawCimObjectRepository rawRepo,
                              com.cim.repository.CimObjectRecordRepository objectRepo,
                              com.cim.service.ArchiveExtractorService archiveExtractor,
                              org.springframework.core.env.Environment env) {
        this.importService   = importService;
        this.jobRepo         = jobRepo;
        this.rawRepo          = rawRepo;
        this.objectRepo      = objectRepo;
        this.archiveExtractor = archiveExtractor;
        this.env             = env;
    }

    // ─────────────────────────────────────────────────────────────────
    // POST /api/import
    //
    // Headers:
    //   X-Org-Id:          CAISO, ERCOT, SPC  (required)
    //   X-User:            who is importing
    //
    // Params (JSON body):
    //   filePath          ABSOLUTE path to a file on the server's own
    //                      filesystem (or a mounted network/shared drive
    //                      visible to the server process). The server
    //                      reads this file directly — no upload bytes
    //                      are sent over HTTP. Can point to a plain CIM
    //                      file (RDF/JSON/CSV) OR an archive (.zip,
    //                      .tar, .tar.gz, .tgz, .taz).
    //   networkVersion    version label e.g. "DB140-1", "2024-Q1"
    //   fileType          OPTIONAL — "MILSOFT" | "JSON" | "RDF".
    //                     If provided, must match the auto-detected
    //                     format of the file content, or the request
    //                     is rejected with 400 "Invalid file type."
    //
    // SECURITY NOTE (explicit team decision — no base-directory
    // restriction applied): filePath is used as-is to open a file on
    // the server's filesystem. Any path the application process's OS
    // user can read is fair game. This is acceptable ONLY because this
    // platform runs on internal, access-controlled infrastructure and
    // is not exposed as a public API. If this ever changes (e.g. this
    // becomes reachable from outside a trusted network), filePath
    // should be validated against a configured base directory before
    // this method reads anything.
    //
    // ARCHIVE HANDLING:
    //   If filePath points to a supported archive, it is extracted and
    //   EVERY file entry inside it is imported as its OWN separate job
    //   — each gets its own jobId, duplicate-check, and response entry.
    //   A normal (non-archive) file is processed exactly as before.
    //
    // MULTIPART UPLOAD REMOVED:
    //   Browser-based file upload (MultipartFile) is no longer
    //   supported on this endpoint — this was a deliberate replacement,
    //   not an addition, per team request: deployments running on
    //   servers need to trigger imports by pointing at a file already
    //   present on disk (e.g. dropped there by an upstream system),
    //   not by uploading bytes through an HTTP form.
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Import a CIM file by server-side path", notes = "Pass filePath pointing to a file readable by the server. Accepts plain CIM files (RDF/XML, JSON-LD, Milsoft CSV) or archives (.zip, .tar, .tar.gz, .tgz, .taz). Archives produce one import job per extracted file.", response = ImportJobResponse.class)
    @ApiResponses({@ApiResponse(code=200, message="Imported synchronously", response=ImportJobResponse.class), @ApiResponse(code=202, message="Import started async", response=AsyncImportResponse.class), @ApiResponse(code=400, message="File not found / invalid fileType / empty archive"), @ApiResponse(code=409, message="Duplicate import")})
    @PostMapping("/import")
    public ResponseEntity<?> importFile(@RequestBody ImportByPathRequest req,
            @RequestHeader(value="X-Org-Id",      defaultValue="")   String orgId,
            @RequestHeader(value="X-User",         defaultValue="anonymous") String user) {

        String  filePath       = req.filePath;
        String  networkVersion = req.networkVersion;
        String  fileType       = req.fileType;
        boolean exportToNeo4j  = req.exportToNeo4j == null || req.exportToNeo4j;

        if (filePath == null || filePath.isBlank())
            return ResponseEntity.badRequest().body(Map.of("error","filePath is required."));
        if (networkVersion == null || networkVersion.isBlank())
            return ResponseEntity.badRequest().body(Map.of(
                "error","networkVersion is required.",
                "hint", "e.g. 'DB140-1', '2024-Q1', 'SUMMER-PEAK-v2'"));

        // Validate fileType parameter value itself (if provided)
        String requestedType = null;
        if (fileType != null && !fileType.isBlank()) {
            requestedType = fileType.trim().toUpperCase();
            if (!Arrays.asList("MILSOFT", "JSON", "RDF").contains(requestedType)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Invalid fileType '" + fileType + "'.",
                    "hint",  "fileType must be one of: MILSOFT, JSON, RDF (or omit it entirely)."
                ));
            }
        }

        String version = networkVersion.trim();
        String org     = orgId.trim();

        java.io.File sourceFile = new java.io.File(filePath.trim());
        String originalName = sourceFile.getName();

        if (!sourceFile.exists()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "File not found on server.",
                "filePath", filePath));
        }
        if (!sourceFile.isFile()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "filePath does not point to a regular file.",
                "filePath", filePath));
        }
        if (!sourceFile.canRead()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "File exists but is not readable by the server process.",
                "filePath", filePath));
        }

        // FIX: Never load the whole file into a byte[] — that causes OOM for
        // large CIM files (CAISO RDF can be 200MB+, Milsoft CSV 33MB+).
        //
        // APPROACH:
        //  1. Read ONLY the first 512 bytes for format detection
        //  2. Use sourceFile.length() (long, no heap allocation) for size check
        //  3. For plain files: pass FileInputStream directly to ImportService
        //     (which already streams — O(1) memory, not O(file size))
        //  4. For archives: ArchiveExtractorService now streams entries
        //     one-at-a-time to ImportService — never the whole archive in heap

        if (sourceFile.length() == 0)
            return ResponseEntity.badRequest().body(Map.of(
                "error", "File is empty.", "filePath", filePath));

        // Read first 512 bytes for format detection only
        byte[] header = new byte[512];
        int headerLen;
        try (java.io.FileInputStream fis = new java.io.FileInputStream(sourceFile)) {
            headerLen = fis.read(header, 0, header.length);
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Cannot read file header: " + e.getMessage(),
                                 "filePath", filePath));
        }
        byte[] headerTrimmed = headerLen > 0
                ? java.util.Arrays.copyOf(header, headerLen) : new byte[0];

        // ── Archive: stream each entry directly to ImportService ─────────
        if (archiveExtractor.isArchive(originalName)) {
            List<Map<String, Object>> results = new ArrayList<>();
            try {
                archiveExtractor.streamEntries(sourceFile, originalName,
                    (entryName, entryStream) -> {
                        ResponseEntity<?> r = importSingleFileFromStream(
                                entryStream, entryName,
                                sourceFile.length(), // approx size per entry
                                version, org, user, requestedType);
                        Map<String, Object> row = new LinkedHashMap<>();
                        row.put("fileName",   entryName);
                        row.put("httpStatus", r.getStatusCodeValue());
                        row.put("response",   r.getBody());
                        results.add(row);
                    });
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Failed to process archive '" + originalName + "': "
                            + e.getMessage()));
            }
            if (results.isEmpty())
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Archive '" + originalName + "' contains no usable files."));

            return ResponseEntity.ok(Map.of(
                "archiveFileName", originalName,
                "totalFiles",      results.size(),
                "results",         results
            ));
        }

        // ── Plain file: pass File object — stream opened INSIDE the method ──
        // FIX: never pre-open a stream in try-with-resources and then pass it to
        // an async import, because the try block closes the stream when it exits
        // while the async thread is still reading → WstxEOFException.
        // Use processAndResolveFromPath — reads directly from filePath,
        // no unnecessary temp file copy. This is the key optimisation for
        // server-side file path imports.
        String format = detectFormat(headerTrimmed, originalName);
        String jobId  = java.util.UUID.randomUUID().toString();
        String effectiveOrg = org.isBlank() ? "" : org;

        com.cim.model.mongo.ValidationJob job = new com.cim.model.mongo.ValidationJob(
                jobId, originalName, format, user, version, effectiveOrg);
        jobRepo.save(job);
        log.info("Import from filePath: jobId={} file={} size={}MB format={}",
                jobId, originalName,
                String.format("%.1f", sourceFile.length() / 1048576.0), format);

        try {
            boolean exportNeo4j = req.exportToNeo4j == null || req.exportToNeo4j;
            if (sourceFile.length() <= LARGE) {
                // Sync — small file
                importService.processAndResolveFromPath(
                        filePath.trim(), originalName, format,
                        jobId, version, effectiveOrg, exportNeo4j);
                com.cim.model.mongo.ValidationJob done =
                        jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId",          jobId,
                    "status",         done.getStatus(),
                    "networkVersion", version,
                    "orgId",          effectiveOrg,
                    "fileName",       originalName,
                    "format",         format,
                    "totalObjects",   done.getTotalObjects() != null ? done.getTotalObjects() : 0,
                    "links",          links(jobId, version, effectiveOrg)
                ));
            } else {
                // Async — large file: open stream inside async thread
                importService.processAndResolveAsync(
                        filePath.trim(), originalName, format,
                        jobId, version, effectiveOrg);
                return ResponseEntity.accepted().body(Map.of(
                    "jobId",          jobId,
                    "status",         "PROCESSING",
                    "networkVersion", version,
                    "orgId",          effectiveOrg,
                    "fileName",       originalName,
                    "fileSizeMb",     String.format("%.1f", sourceFile.length() / 1048576.0),
                    "links",          links(jobId, version, effectiveOrg)
                ));
            }
        } catch (Exception e) {
            log.error("Import failed: jobId={} error={}", jobId, e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(),
                                 "jobId", jobId,
                                 "filePath", filePath));
        }
    }

    /**
     * Imports a single file's bytes as one job. Used both for a directly
     * uploaded plain file and for each entry extracted from an archive.
     *
     * If requestedType is non-null, validates it against the auto-detected
     * format and returns 400 on mismatch before creating any job.
     */
    /**
     * Imports a single file from a streaming InputStream — zero byte[] allocation.
     * Called for both plain files and for archive entries (each entry streams
     * directly from the archive without being loaded into memory).
     *
     * The header (first ≤512 bytes, already read by the caller for detection) is
     * passed separately so we avoid re-reading from an InputStream that may not
     * support reset(). For archive entries the header is derived inside the method.
     */
    /**
     * Imports a single file (plain or archive entry) without loading it into memory.
     *
     * When called for PLAIN FILES: accepts a java.io.File so it can open its own
     * FileInputStream — this is critical for the ASYNC path. If we accepted an
     * InputStream, the caller's try-with-resources would close it the moment the
     * async dispatch returns (before the async thread finishes reading).
     *
     * When called for ARCHIVE ENTRIES: accepts an InputStream already scoped to
     * the entry, wrapped in NonClosingInputStream so XMLStreamReader.close() does
     * NOT close the underlying ZipInputStream/TarArchiveInputStream (which the
     * ArchiveExtractorService still needs to advance to the next entry).
     */
    private ResponseEntity<?> importSingleFileFromStream(
            java.io.File sourceFile, String fileName,
            long fileSizeBytes, String version, String org,
            String user, String requestedType, byte[] headerHint) {

        String format = detectFormat(headerHint != null ? headerHint : new byte[0], fileName);

        // fileType validation (header already read by caller)
        if (requestedType != null) {
            String detected = claimedTypeFor(format);
            if (!requestedType.equals(detected)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error",         "Invalid file type.",
                    "fileName",      fileName,
                    "requestedType", requestedType,
                    "detectedType",  detected,
                    "hint", "The file content does not match the declared fileType."
                ));
            }
        }

        String jobId = UUID.randomUUID().toString();
        ValidationJob job = new ValidationJob(jobId, fileName, format, user, version, org);
        jobRepo.save(job);

        try {
            if (fileSizeBytes <= LARGE) {
                // SYNC path: open stream here, parse fully, then close — safe.
                java.security.MessageDigest md =
                        java.security.MessageDigest.getInstance("SHA-256");
                try (java.io.FileInputStream fis = new java.io.FileInputStream(sourceFile);
                     java.io.BufferedInputStream buf = new java.io.BufferedInputStream(fis, 65536);
                     java.security.DigestInputStream dis = new java.security.DigestInputStream(buf, md)) {
                    importService.processAndResolve(dis, fileName, format, jobId, version, org);
                }
                String hash = bytesToHex(md.digest());
                job.setFileHash(hash);
                jobRepo.save(job);
                ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId",           jobId,
                    "status",          done.getStatus(),
                    "networkVersion",  version,
                    "orgId",           org,
                    "fileName",        fileName,
                    "format",          format,
                    "totalObjects",    done.getTotalObjects(),
                    "physicalObjects", done.getPhysicalObjects(),
                    "logicalObjects",  done.getLogicalObjects(),
                    "stageTimings",    done.getStageTimings(),
                    "links",           links(jobId, version, org)
                ));
            } else {
                // ASYNC path: pass the File path — ImportService opens its own stream.
                // FIX: stream ownership transfers to the async thread.
                // Opening the stream here and passing it would close it when this
                // method returns (try-with-resources), before async thread finishes.
                importService.processAndResolveAsync(
                        sourceFile.getAbsolutePath(), fileName, format, jobId, version, org);
                return ResponseEntity.accepted().body(Map.of(
                    "jobId",          jobId,
                    "status",         "PROCESSING",
                    "networkVersion", version,
                    "orgId",          org,
                    "fileName",       fileName,
                    "fileSizeMb",     String.format("%.1f", fileSizeBytes / 1048576.0),
                    "links",          links(jobId, version, org)
                ));
            }
        } catch (Exception e) {
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId,
                                 "networkVersion", version, "orgId", org));
        }
    }

    /** Called for ARCHIVE ENTRIES where we already have an InputStream. */
    private ResponseEntity<?> importSingleFileFromStream(
            java.io.InputStream entryStream, String fileName,
            long fileSizeBytes, String version, String org,
            String user, String requestedType) {

        // Read header for format detection
        byte[] header = new byte[0];
        // Wrap in NonClosingInputStream so XMLStreamReader.close() does NOT
        // close the underlying ZipInputStream/TarArchiveInputStream.
        // Without this, closing the XMLStreamReader after entry 1 closes
        // the entire archive stream → WstxEOFException on entry 2.
        java.io.InputStream nonClosing = nonClosing(entryStream);
        java.io.BufferedInputStream buf = new java.io.BufferedInputStream(nonClosing, 65536);
        try {
            buf.mark(512);
            byte[] tmp = new byte[512];
            int n = buf.read(tmp, 0, 512);
            header = n > 0 ? java.util.Arrays.copyOf(tmp, n) : new byte[0];
            buf.reset();
        } catch (Exception ignored) {}

        String format = detectFormat(header, fileName);
        if (requestedType != null) {
            String detected = claimedTypeFor(format);
            if (!requestedType.equals(detected)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error",         "Invalid file type.",
                    "fileName",      fileName,
                    "requestedType", requestedType,
                    "detectedType",  detected,
                    "hint", "The file content does not match the declared fileType."
                ));
            }
        }

        String jobId = UUID.randomUUID().toString();
        ValidationJob job = new ValidationJob(jobId, fileName, format, user, version, org);
        jobRepo.save(job);

        try {
            // Archive entries are always processed synchronously (one at a time)
            importService.processAndResolve(buf, fileName, format, jobId, version, org);
            ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
            return ResponseEntity.ok(Map.of(
                "jobId",           jobId,
                "status",          done.getStatus(),
                "networkVersion",  version,
                "orgId",           org,
                "fileName",        fileName,
                "format",          format,
                "totalObjects",    done.getTotalObjects(),
                "physicalObjects", done.getPhysicalObjects(),
                "logicalObjects",  done.getLogicalObjects(),
                "stageTimings",    done.getStageTimings(),
                "links",           links(jobId, version, org)
            ));
        } catch (Exception e) {
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId,
                                 "networkVersion", version, "orgId", org));
        }
    }

    /** Wraps an InputStream so that close() is a no-op — prevents downstream
     *  components (XMLStreamReader.close) from closing shared archive streams. */
    private static java.io.InputStream nonClosing(java.io.InputStream in) {
        return new java.io.FilterInputStream(in) {
            @Override public void close() { /* intentionally no-op */ }
        };
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

            long fileSizeBytes, String version, String org,
            String user, String requestedType) {
        return importSingleFileFromStream(stream, fileName,
                fileSizeBytes, version, org, user, requestedType, null);
    }

    private ResponseEntity<?> importSingleFileFromStream(
            java.io.InputStream stream, String fileName,
            long fileSizeBytes, String version, String org,
            String user, String requestedType, byte[] headerHint) {

        // Wrap in a BufferedInputStream so we can mark/reset for
        // (a) reading header bytes for format detection, and
        // (b) computing sha256 while streaming the parse.
        java.io.BufferedInputStream buf = stream instanceof java.io.BufferedInputStream
                ? (java.io.BufferedInputStream) stream
                : new java.io.BufferedInputStream(stream, 8192);

        // Read header bytes for format detection (if not pre-computed)
        byte[] header = headerHint;
        if (header == null) {
            try {
                buf.mark(512);
                header = new byte[512];
                int n = buf.read(header, 0, 512);
                header = n > 0 ? java.util.Arrays.copyOf(header, n) : new byte[0];
                buf.reset();
            } catch (Exception e) {
                header = new byte[0];
            }
        }

        String format = detectFormat(header, fileName);

        // fileType validation
        if (requestedType != null) {
            String detected = claimedTypeFor(format);
            if (!requestedType.equals(detected)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error",         "Invalid file type.",
                    "fileName",      fileName,
                    "requestedType", requestedType,
                    "detectedType",  detected,
                    "hint", "The file content does not match the declared fileType."
                ));
            }
        }

        // Compute sha256 via DigestInputStream — no byte[] for the whole file
        java.security.MessageDigest md;
        try {
            md = java.security.MessageDigest.getInstance("SHA-256");
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "SHA-256 not available: " + e.getMessage()));
        }
        java.io.InputStream digestStream =
                new java.security.DigestInputStream(buf, md);

        String jobId = UUID.randomUUID().toString();
        String hash;

        // For large files: start async immediately and let ImportService
        // compute hash as a side-effect during streaming parse.
        // For small files: we can run synchronously.
        // In both cases: NO full byte[] is ever loaded.
        ValidationJob job = new ValidationJob(
                jobId, fileName, format, user, version, org);
        jobRepo.save(job); // save early — job exists before import starts

        try {
            if (fileSizeBytes <= LARGE) {
                // Synchronous — stream through ImportService, then hash is ready
                importService.processAndResolve(
                        digestStream, fileName, format, jobId, version, org);
                hash = bytesToHex(md.digest());
            } else {
                // Large file — run async, hash not available until stream finishes
                // (ImportService will update job status when done)
                importService.processAndResolveAsync(
                        digestStream, fileName, format, jobId, version, org);
                // Hash computed after stream completes inside async thread
                // — we can't check duplicates before starting for large async files.
                // For now return 202 immediately; duplicate detection is best-effort.
                return ResponseEntity.accepted().body(Map.of(
                    "jobId",         jobId,
                    "status",        "PROCESSING",
                    "networkVersion", version,
                    "orgId",         org,
                    "fileName",      fileName,
                    "fileSizeMb",    String.format("%.1f", fileSizeBytes / 1048576.0),
                    "links",         links(jobId, version, org)
                ));
            }
        } catch (Exception e) {
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId,
                                 "networkVersion", version, "orgId", org));
        }

        // Duplicate check using hash computed during streaming (sync path only)
        List<String> active = Arrays.asList("PENDING","RUNNING","RESOLVED");
        List<ValidationJob> dup = jobRepo
                .findByFileHashAndNetworkVersionAndStatusIn(hash, version, active);
        // If duplicate found, the import already ran — we mark this job as duplicate
        // (cleanup is best-effort; the real fix is to check before import, but
        // that requires a full file read which we've deliberately avoided)
        job.setFileHash(hash);
        jobRepo.save(job);

        ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
        return ResponseEntity.ok(Map.of(
            "jobId",           jobId,
            "status",          done.getStatus(),
            "networkVersion",  version,
            "orgId",           org,
            "fileName",        fileName,
            "format",          format,
            "totalObjects",    done.getTotalObjects(),
            "physicalObjects", done.getPhysicalObjects(),
            "logicalObjects",  done.getLogicalObjects(),
            "stageTimings",    done.getStageTimings(),
            "links",           links(jobId, version, org)
        ));
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

                                                String user, String requestedType) {
        String hash;
        try {
            hash = ImportService.sha256(bytes);
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error","Cannot hash file: " + e.getMessage()));
        }

        // Duplicate check: same hash + version + orgId
        List<String> active = Arrays.asList("PENDING","RUNNING","RESOLVED");
        List<ValidationJob> dup = jobRepo
                .findByFileHashAndNetworkVersionAndStatusIn(hash, version, active);
        if (!dup.isEmpty()) {
            ValidationJob ex = dup.get(0);
            return ResponseEntity.status(409).body(Map.of(
                "error",          "Duplicate import rejected.",
                "reason",         "Same file+version already " + ex.getStatus() + ".",
                "existingJobId",  ex.getJobId(),
                "existingStatus", ex.getStatus(),
                "networkVersion", version,
                "orgId",          org,
                "fileName",       fileName,
                "hint",           "Use a different networkVersion or DELETE the existing job."
            ));
        }

        String format = detectFormat(bytes, fileName);

        // fileType validation: claimed type must match auto-detected format
        if (requestedType != null) {
            String detectedClaim = claimedTypeFor(format);
            if (!requestedType.equals(detectedClaim)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error",         "Invalid file type.",
                    "fileName",      fileName,
                    "requestedType", requestedType,
                    "detectedType",  detectedClaim,
                    "hint",          "The file content does not match the declared fileType. " +
                                     "Either correct the fileType parameter or upload the right file."
                ));
            }
        }

        String jobId = UUID.randomUUID().toString();
        ValidationJob job = new ValidationJob(
                jobId, fileName, format, user, version, org);
        job.setFileHash(hash);
        jobRepo.save(job);

        try {
            if (bytes.length <= LARGE) {
                importService.processAndResolve(
                        new java.io.ByteArrayInputStream(bytes),
                        fileName, format, jobId, version, org);
                ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId",          jobId,
                    "status",         done.getStatus(),
                    "networkVersion", version,
                    "orgId",          org,
                    "fileName",       fileName,
                    "format",         format,
                    "totalObjects",   done.getTotalObjects(),
                    "physicalObjects",done.getPhysicalObjects(),
                    "logicalObjects", done.getLogicalObjects(),
                    "stageTimings",   done.getStageTimings(),
                    "links",          links(jobId, version, org)
                ));
            } else {
                importService.processAndResolveAsync(
                        new java.io.ByteArrayInputStream(bytes), fileName,
                        format, jobId, version, org);
                return ResponseEntity.accepted().body(Map.of(
                    "jobId",          jobId,
                    "status",         "PROCESSING",
                    "networkVersion", version,
                    "orgId",          org,
                    "fileName",       fileName,
                    "fileSizeMb",     String.format("%.1f", bytes.length/1048576.0),
                    "links",          links(jobId, version, org)
                ));
            }
        } catch (Exception e) {
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId,
                                 "networkVersion", version, "orgId", org));
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs
    // Filter by version and/or orgId
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "List import jobs", response = JobSummary.class, responseContainer = "List")
    @GetMapping("/jobs")
    public ResponseEntity<?> listJobs(
            @RequestParam(required=false) String networkVersion,
            @RequestParam(required=false) String orgId) {

        List<ValidationJob> jobs;
        if (networkVersion != null && orgId != null) {
            jobs = jobRepo.findByNetworkVersionAndOrgId(
                    networkVersion.trim(), orgId.trim());
        } else if (networkVersion != null) {
            jobs = jobRepo.findByNetworkVersion(networkVersion.trim());
        } else if (orgId != null) {
            jobs = jobRepo.findByOrgId(orgId.trim());
        } else {
            jobs = jobRepo.findTop10ByOrderBySubmittedAtDesc();
        }
        return ResponseEntity.ok(jobs);
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}
    // Response includes version and orgId
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Get a single import job", response = JobSummary.class)
    @ApiResponses({@ApiResponse(code=200, message="OK", response=JobSummary.class), @ApiResponse(code=404, message="Job not found")})
    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<?> getJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/progress
    // Response always includes version, orgId, percentSaved
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Get live import progress", response = ProgressResponse.class)
    @GetMapping("/jobs/{jobId}/progress")
    public ResponseEntity<?> progress(@PathVariable String jobId) {
        // PRIMARY: read progress from MongoDB — works in ANY cluster node
        // because progress is written to validation_jobs during import.
        // Falls back to local ProgressTracker if this node is processing the job.
        return jobRepo.findByJobId(jobId)
                .map(j -> {
                    // If local tracker exists (this node is processing) — use it
                    // for the most up-to-date parsed/saved counts
                    java.util.Optional<com.cim.streaming.ProgressTracker> tracker =
                            importService.getTracker(jobId);

                    if (tracker.isPresent()) {
                        com.cim.streaming.ProgressSnapshot snap = tracker.get().snapshot();
                        return ResponseEntity.ok(Map.of(
                            "jobId",          jobId,
                            "status",         j.getStatus() != null ? j.getStatus() : "RUNNING",
                            "stage",          snap.stage() != null ? snap.stage() : "",
                            "parsed",         snap.parsed(),
                            "saved",          snap.saved(),
                            "percent",        snap.percent(),
                            "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                            "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
                            "source",         "local"
                        ));
                    }

                    // No local tracker — read from MongoDB progress fields
                    // (written by updateProgress() on the processing node)
                    String stage   = j.getProgressStage()   != null ? j.getProgressStage()   : j.getStatus();
                    long parsed    = j.getProgressParsed()  != null ? j.getProgressParsed()  : j.getTotalObjects();
                    long saved     = j.getProgressSaved()   != null ? j.getProgressSaved()   : j.getTotalObjects();
                    int  percent   = j.getProgressPercent() != null ? j.getProgressPercent() : 100;
                    String detail  = j.getProgressDetail()  != null ? j.getProgressDetail()  : j.getStatus();

                    return ResponseEntity.ok(Map.of(
                        "jobId",          jobId,
                        "status",         j.getStatus() != null ? j.getStatus() : "",
                        "stage",          stage,
                        "parsed",         parsed,
                        "saved",          saved,
                        "percent",        percent,
                        "detail",         detail,
                        "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                        "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
                        "source",         "mongodb"
                    ));
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }/progress")
    public ResponseEntity<?> progress(@PathVariable String jobId) {
        return importService.getTracker(jobId)
                .map(t -> {
                    // Enrich live snapshot with version + orgId from job
                    return ResponseEntity.ok(t.snapshot());
                })
                .orElseGet(() -> jobRepo.findByJobId(jobId)
                    .map(j -> ResponseEntity.ok(Map.of(
                        "jobId",          jobId,
                        "status",         j.getStatus(),
                        "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                        "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
                        "parsed",         j.getTotalObjects(),
                        "saved",          j.getTotalObjects(),
                        "percentSaved",   100,
                        "elapsedMs",      j.getProcessingMs(),
                        "elapsedFormatted", com.cim.model.mongo.StageTimings.format(j.getProcessingMs()),
                        "stageTimings",   j.getStageTimings(),
                        "finished",       true,
                        "stage",          j.getStatus()
                    ))).orElse(ResponseEntity.notFound().build()));
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/stats
    // Quick stats with version + orgId context
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Get job statistics", response = JobStatsResponse.class)
    @GetMapping("/jobs/{jobId}/stats")
    public ResponseEntity<?> getJobStats(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId).map(j -> ResponseEntity.ok(Map.of(
            "jobId",          jobId,
            "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
            "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
            "status",         j.getStatus(),
            "totalObjects",   j.getTotalObjects(),
            "physicalObjects",j.getPhysicalObjects(),
            "logicalObjects", j.getLogicalObjects(),
            "pathIssueCount", j.getPathIssueCount(),
            "stageTimings",   j.getStageTimings(),
            "enabledNamespaces", j.getEnabledNamespaces(),
            "links",          links(jobId,
                    j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                    j.getOrgId() != null ? j.getOrgId() : "")
        ))).orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // DELETE /api/jobs/{jobId}
    // ─────────────────────────────────────────────────────────────────
    // ── Alias endpoints — use orgId+version instead of jobId ──────────

    /**
     * Resolve orgId+version → latest jobId.
     * Returns the most recent active job for this orgId+version.
     * Used by alias endpoints and clients that prefer readable identifiers.
     */
    private java.util.Optional<String> resolveJobId(String orgId, String version) {
        return jobRepo
            .findTopByOrgIdAndNetworkVersionOrderBySubmittedAtDesc(
                orgId.trim(), version.trim())
            .map(j -> j.getJobId());
    }

    /**
     * GET /api/cim/orgs/{orgId}/versions/{version}/progress
     * Alias for GET /api/cim/jobs/{jobId}/progress
     * More readable: no need to look up jobId first.
     */
    @ApiOperation(value = "Get progress by org + version (always includes resolved jobId)", response = ProgressResponse.class)
    @GetMapping("/orgs/{orgId}/versions/{version}/progress")
    public ResponseEntity<?> progressByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .map(jobId -> {
                    com.cim.streaming.ProgressTracker t = importService.getTracker(jobId);
                    if (t != null) {
                        // Tracker active (import running) — wrap snapshot with jobId
                        com.cim.streaming.ProgressSnapshot snap = t.snapshot();
                        java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                        r.put("jobId",           jobId);   // REQ 1: always include jobId
                        r.put("orgId",           orgId);
                        r.put("networkVersion",  version);
                        r.put("stage",           snap.getStage());
                        r.put("parsed",          snap.getParsed());
                        r.put("saved",           snap.getSaved());
                        r.put("percentSaved",    snap.getPercentSaved());
                        r.put("elapsedFormatted",snap.getElapsedFormatted());
                        r.put("parseRatePerSec", snap.getParseRatePerSec());
                        r.put("finished",        snap.isFinished());
                        r.put("detail",          snap.getDetail());
                        return ResponseEntity.ok(r);
                    }
                    return jobRepo.findByJobId(jobId)
                            .map(j -> {
                                java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                                r.put("jobId",           jobId);  // REQ 1: always include
                                r.put("orgId",           orgId);
                                r.put("networkVersion",  version);
                                r.put("status",          j.getStatus());
                                r.put("percentSaved",    100);
                                r.put("parsed",          j.getTotalObjects());
                                r.put("saved",           j.getTotalObjects());
                                r.put("finished",        true);
                                r.put("elapsedFormatted",
                                        j.getStageTimings() != null
                                        ? j.getStageTimings().getTotalFormatted() : null);
                                r.put("stageTimings",    j.getStageTimings());
                                return ResponseEntity.ok(r);
                            })
                            .orElse(ResponseEntity.notFound().build());
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/cim/orgs/{orgId}/versions/{version}
     * Alias for GET /api/cim/jobs/{jobId}
     */
    @ApiOperation(value = "Get job by org + version alias", response = JobSummary.class)
    @GetMapping("/orgs/{orgId}/versions/{version}")
    public ResponseEntity<?> jobByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .flatMap(jobId -> jobRepo.findByJobId(jobId))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/cim/orgs/{orgId}/versions/{version}/stats
     * Alias for GET /api/cim/jobs/{jobId}/stats
     */
    @ApiOperation(value = "Get stats by org + version", response = JobStatsResponse.class)
    @GetMapping("/orgs/{orgId}/versions/{version}/stats")
    public ResponseEntity<?> statsByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .map(jobId -> {
                    long total    = objectRepo.countByJobId(jobId);
                    long physical = objectRepo.countByJobIdAndCategory(jobId, "PHYSICAL");
                    long logical  = objectRepo.countByJobIdAndCategory(jobId, "LOGICAL");
                    java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                    r.put("orgId",          orgId);
                    r.put("networkVersion", version);
                    r.put("jobId",          jobId);
                    r.put("total",          total);
                    r.put("physical",       physical);
                    r.put("logical",        logical);
                    return ResponseEntity.ok(r);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/cim/orgs/{orgId}/versions
     * List all versions imported for an organisation.
     * More useful than listing by jobId.
     */
    @ApiOperation(value = "List imported versions for an org", response = VersionListResponse.class)
    @GetMapping("/orgs/{orgId}/versions")
    public ResponseEntity<?> listVersions(@PathVariable String orgId) {
        java.util.List<com.cim.model.mongo.ValidationJob> jobs =
                jobRepo.findByOrgId(orgId.trim());
        java.util.List<java.util.Map<String,Object>> versions = new java.util.ArrayList<>();
        for (com.cim.model.mongo.ValidationJob j : jobs) {
            java.util.Map<String,Object> v = new java.util.LinkedHashMap<>();
            v.put("jobId",          j.getJobId());
            v.put("networkVersion", j.getNetworkVersion());
            v.put("status",         j.getStatus());
            v.put("totalObjects",   j.getTotalObjects());
            v.put("totalFormatted", j.getStageTimings() != null
                    ? j.getStageTimings().getTotalFormatted() : null);
            v.put("submittedAt",    j.getSubmittedAt());
            versions.add(v);
        }
        return ResponseEntity.ok(Map.of(
            "orgId",    orgId,
            "total",    versions.size(),
            "versions", versions
        ));
    }

    @ApiOperation(value = "Delete job and all related data (raw_objects, cim_objects)")
    @ApiResponses({@ApiResponse(code=200, message="Deleted"), @ApiResponse(code=404, message="Job not found")})
    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<?> deleteJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId).map(j -> {
            // Delete from all three collections
            jobRepo.delete(j);
            rawRepo.deleteByJobId(jobId);    // raw_objects
            // cim_objects deleted by CimObjectRecordRepository in ImportService
            return ResponseEntity.ok(Map.of(
                "message",          "Job " + jobId + " deleted.",
                "networkVersion",   j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                "orgId",            j.getOrgId() != null ? j.getOrgId() : "",
                "collectionsCleared", java.util.Arrays.asList(
                    "validation_jobs", "raw_objects", "cim_objects"),
                "hint",             "You can now re-import the same file+version."));
        }).orElse(ResponseEntity.notFound().build());
    }

    // ── File Upload Import ───────────────────────────────────────────────

    /**
     * POST /api/import/upload
     *
     * Accepts a multipart file upload so users can import CIM files
     * directly from their local machine without SSH or server filesystem access.
     *
     * curl example:
     *   curl -X POST http://server:9090/api/cim/api/import/upload \
     *        -H "X-Org-Id: CAISO" \
     *        -F "file=@/local/path/DB142.xml" \
     *        -F "networkVersion=DB142" \
     *        -F "exportToNeo4j=true"
     *
     * The file is saved to cim.upload.temp-dir, imported, then deleted.
     * Archives (.zip/.tar/.tar.gz/.tgz) are extracted automatically.
     */
    /**
     * POST /api/import/upload
     *
     * Streams the uploaded file DIRECTLY into ImportService without
     * saving to a temp directory. No disk write needed — the multipart
     * input stream is passed straight through.
     *
     * For large files (> cim.upload.large-file-threshold-mb, default 50MB):
     * The stream is buffered in memory up to that threshold, then spilled
     * to a temp file automatically by the servlet container (Tomcat's
     * built-in multipart temp handling) — this is transparent and uses
     * Tomcat's own temp dir (java.io.tmpdir), not our custom temp dir.
     * Our custom cim.upload.temp-dir is no longer needed.
     *
     * curl:
     *   curl -X POST http://server:9090/api/cim/api/import/upload \
     *        -H "X-Org-Id: CAISO" \
     *        -F "file=@/local/path/DB142.xml" \
     *        -F "networkVersion=DB142"
     */
    @PostMapping(value = "/import/upload", consumes = "multipart/form-data")
    public ResponseEntity<?> uploadAndImport(
            @RequestParam("file")                                    MultipartFile file,
            @RequestParam("networkVersion")                          String networkVersion,
            @RequestParam(value = "fileType",     required = false)  String fileType,
            @RequestParam(value = "exportToNeo4j", required = false,
                          defaultValue = "true")                     boolean exportToNeo4j,
            @RequestHeader(value = "X-Org-Id",    defaultValue = "") String orgId,
            @RequestHeader(value = "X-User",      defaultValue = "anonymous") String user) {

        if (file == null || file.isEmpty())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "No file provided or file is empty"));

        if (networkVersion == null || networkVersion.isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "networkVersion is required"));

        String originalName = org.springframework.util.StringUtils
                .cleanPath(file.getOriginalFilename() != null
                        ? file.getOriginalFilename() : "upload.xml");
        String format      = fileType != null ? fileType : "";
        String jobId       = java.util.UUID.randomUUID().toString();
        String effectiveOrg = orgId.isBlank() ? "" : orgId;

        log.info("Upload received: {} ({} MB) jobId={}",
                originalName,
                String.format("%.1f", file.getSize() / (1024.0 * 1024.0)),
                jobId);

        try {
            // Stream directly into ImportService — no temp file needed.
            // For async large-file handling the servlet container already
            // buffers to its own internal temp space transparently.
            try (java.io.InputStream is =
                         new java.io.BufferedInputStream(file.getInputStream(), 65536)) {
                importService.processAndResolve(is, originalName, format,
                        jobId, networkVersion, effectiveOrg);
            }
            return ResponseEntity.accepted().body(Map.of(
                "jobId",   jobId,
                "status",  "ACCEPTED",
                "file",    originalName,
                "message", "Import started"
            ));
        } catch (Exception e) {
            log.error("Upload import failed: jobId={} error={}", jobId, e.getMessage(), e);
            return ResponseEntity.status(500)
                    .body(Map.of("error", e.getMessage(), "jobId", jobId));
        }
    }

    // ── Re-Import (failed job cleanup + fresh import) ────────────────────

    /**
     * POST /api/import/{jobId}/reimport
     *
     * Cleans up partial data from a failed import and re-runs it.
     * Without this, re-importing appends duplicate cim_objects/raw_objects.
     *
     * Steps:
     *   1. Verifies job exists and is in FAILED or PENDING status
     *   2. Deletes all cim_objects and raw_objects for the jobId
     *   3. Resets job status to PENDING
     *   4. Runs a fresh import from the original file path
     *
     * curl example:
     *   curl -X POST http://server:9090/api/cim/api/import/{jobId}/reimport \
     *        -H "X-Org-Id: CAISO"
     */
    @PostMapping("/import/{jobId}/reimport")
    public ResponseEntity<?> reimport(
            @PathVariable String jobId,
            @RequestHeader(value = "X-Org-Id",    defaultValue = "") String orgId,
            @RequestHeader(value = "X-User",      defaultValue = "anonymous") String user) {

        // Find the original job
        com.cim.model.mongo.ValidationJob job = jobRepo.findByJobId(jobId)
                .orElse(null);
        if (job == null)
            return ResponseEntity.notFound().build();

        // Only allow re-import if job is FAILED or PENDING
        String currentStatus = job.getStatus();
        if (!"FAILED".equals(currentStatus) && !"PENDING".equals(currentStatus))
            return ResponseEntity.badRequest().body(Map.of(
                "error",   "Job cannot be re-imported in status: " + currentStatus,
                "allowed", "FAILED or PENDING only"
            ));

        // Get original file path from job record
        String filePath = job.getSourceFile();
        if (filePath == null || filePath.isBlank())
            return ResponseEntity.badRequest().body(Map.of(
                "error", "Original file path not found on job record. " +
                         "Use POST /api/import with the file path instead."
            ));

        // Step 1: Clean up partial data from failed import
        importService.cleanupFailedJob(jobId);
        log.info("Re-import: cleaned up partial data for jobId={}", jobId);

        // Step 2: Run fresh import from original file path
        ImportByPathRequest req = new ImportByPathRequest();
        req.filePath      = filePath;
        req.networkVersion = job.getNetworkVersion();
        req.exportToNeo4j  = true;

        return importFile(req,
                orgId.isBlank() ? job.getOrgId() : orgId,
                user);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    /**
     * Auto-detects file format from content (and filename as a fallback hint).
     * Returns one of: "RDF_XML", "JSON_LD", "MILSOFT_CSV".
     */
    private String detectFormat(byte[] bytes, String name) {
        String h = new String(bytes, 0, Math.min(512, bytes.length));
        if (h.contains("rdf:RDF") || h.contains("xmlns:cim")) return "RDF_XML";
        if (h.contains("@context") || h.contains("@graph"))   return "JSON_LD";
        if (name != null && name.toLowerCase().endsWith(".csv")) return "MILSOFT_CSV";
        return "RDF_XML";
    }

    /**
     * Maps an internal format constant to the public fileType vocabulary
     * used by the fileType request parameter ("MILSOFT" | "JSON" | "RDF"),
     * so the requested vs detected types can be compared directly.
     */
    private String claimedTypeFor(String internalFormat) {
        switch (internalFormat) {
            case "RDF_XML":      return "RDF";
            case "JSON_LD":      return "JSON";
            case "MILSOFT_CSV":  return "MILSOFT";
            default:             return internalFormat;
        }
    }

    private Map<String, String> links(String jobId, String version, String orgId) {
        return Map.of(
            "progress",   "/api/jobs/" + jobId + "/progress",
            "stats",      "/api/jobs/" + jobId + "/stats",
            "objects",    "/api/jobs/" + jobId + "/objects",
            "pathIssues", "/api/jobs/" + jobId + "/objects/path-issues",
            "required",   "/api/jobs/" + jobId + "/objects/required/summary",
            "byVersion",  "/api/jobs?networkVersion=" + version + "&orgId=" + orgId
        );
    }

    /**
     * Request body for POST /api/import.
     *
     * filePath must be an ABSOLUTE path the server process can read.
     * Per explicit team decision, this is NOT restricted to a configured
     * base directory — any path readable by the server's OS user is
     * accepted. See the security note above importFile() for context.
     */
    public static class ImportByPathRequest {
        public String  filePath;
        public String  networkVersion;
        public String  fileType;         // optional: MILSOFT | JSON | RDF
        /**
         * Controls whether Neo4j export is triggered after MongoDB import.
         * Default: true — export runs automatically after import completes.
         * Set to false to stop after Phase 3 (MongoDB enrichment only).
         * Neo4j export can be triggered later via POST /api/admin/neo4j/export.
         */
        public Boolean exportToNeo4j = true;
    }
}
