package com.cim.controller;

import com.cim.model.mongo.CimTypeFilterConfig;
import com.cim.service.CimObjectsRebuildService;
import com.cim.service.CimTypeFilterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST API for managing the CIM type filter and rebuilding cim_objects.
 *
 * FILTER MANAGEMENT:
 *   GET    /api/admin/cim-type-filter          — list all configs
 *   POST   /api/admin/cim-type-filter          — create new filter config
 *   PUT    /api/admin/cim-type-filter/{id}     — update filter config
 *   DELETE /api/admin/cim-type-filter/{id}     — delete filter config
 *   GET    /api/admin/cim-type-filter/resolve  — show resolved filter for an org
 *
 * REBUILD:
 *   POST   /api/admin/cim-objects/rebuild/{jobId}         — rebuild one job
 *   POST   /api/admin/cim-objects/rebuild?orgId=&version= — rebuild all jobs for org+version
 */
@RestController
@RequestMapping("/api/admin")
public class CimTypeFilterController {

    private static final Logger log = LoggerFactory.getLogger(CimTypeFilterController.class);

    private final CimTypeFilterService     filterService;
    private final CimObjectsRebuildService rebuildService;

    public CimTypeFilterController(CimTypeFilterService filterService,
                                    CimObjectsRebuildService rebuildService) {
        this.filterService  = filterService;
        this.rebuildService = rebuildService;
    }

    // ── Filter Config CRUD ────────────────────────────────────────────────

    /** List all CIM type filter configs */
    @GetMapping("/cim-type-filter")
    public ResponseEntity<?> listFilters() {
        return ResponseEntity.ok(filterService.findAll());
    }

    /**
     * Create a new filter config.
     *
     * Request body:
     * {
     *   "orgId":       "CAISO",           // null/blank = global
     *   "configName":  "CAISO Default",
     *   "allowedTypes":["ACLineSegment","Breaker","Disconnector",
     *                   "Substation","Terminal","ConnectivityNode",
     *                   "VoltageLevel","BaseVoltage","SubGeographicalRegion",
     *                   "GeographicalRegion","PowerTransformer",
     *                   "ShuntCompensator","SynchronousMachine",
     *                   "GeneratingUnit","BusbarSection","Fuse",
     *                   "SeriesCompensator","StaticVarCompensator",
     *                   "ConformLoad","NonConformLoad"],
     *   "enabled": true
     * }
     */
    @PostMapping("/cim-type-filter")
    public ResponseEntity<?> createFilter(@RequestBody CimTypeFilterConfig config) {
        if (config.getAllowedTypes() == null || config.getAllowedTypes().isEmpty())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "allowedTypes must not be empty. " +
                            "To allow all types, delete the filter config instead."));
        config.setId(null); // ensure new document
        CimTypeFilterConfig saved = filterService.save(config);
        log.info("CimTypeFilter created: id={} orgId={} types={}",
                saved.getId(), saved.getOrgId(), saved.getAllowedTypes().size());
        return ResponseEntity.ok(saved);
    }

    /** Update an existing filter config */
    @PutMapping("/cim-type-filter/{id}")
    public ResponseEntity<?> updateFilter(@PathVariable String id,
                                           @RequestBody CimTypeFilterConfig config) {
        return filterService.findById(id)
                .map(existing -> {
                    config.setId(id);
                    config.setCreatedAt(existing.getCreatedAt());
                    CimTypeFilterConfig saved = filterService.save(config);
                    return ResponseEntity.ok(saved);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /** Delete a filter config */
    @DeleteMapping("/cim-type-filter/{id}")
    public ResponseEntity<?> deleteFilter(@PathVariable String id) {
        filterService.delete(id);
        return ResponseEntity.ok(Map.of("deleted", id));
    }

    /**
     * Show the resolved filter for an org — useful to verify what
     * will be applied during the next import.
     *
     * GET /api/admin/cim-type-filter/resolve?orgId=CAISO
     */
    @GetMapping("/cim-type-filter/resolve")
    public ResponseEntity<?> resolveFilter(
            @RequestParam(value = "orgId", defaultValue = "") String orgId) {
        java.util.Set<String> types = filterService.getAllowedTypes(orgId);
        return ResponseEntity.ok(Map.of(
            "orgId",        orgId,
            "filterActive", !types.isEmpty(),
            "typeCount",    types.size(),
            "allowedTypes", types.isEmpty()
                    ? "ALL (no filter configured)"
                    : new java.util.TreeSet<>(types)
        ));
    }

    // ── Rebuild API ───────────────────────────────────────────────────────

    /**
     * Rebuild cim_objects for a single job from raw_objects.
     *
     * POST /api/admin/cim-objects/rebuild/{jobId}
     *
     * Steps:
     *   1. Delete all cim_objects for the jobId
     *   2. Re-read raw_objects for the jobId
     *   3. Apply current CimTypeFilterConfig for the job's orgId
     *   4. Write filtered results to cim_objects
     *
     * Use this after:
     *   - Changing the CimTypeFilterConfig (new types added/removed)
     *   - A failed import that left partial cim_objects
     *   - Manual data correction in raw_objects
     */
    @PostMapping("/cim-objects/rebuild/{jobId}")
    public ResponseEntity<?> rebuildByJobId(@PathVariable String jobId) {
        try {
            CimObjectsRebuildService.RebuildResult result =
                    rebuildService.rebuildByJobId(jobId);
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            log.error("Rebuild failed for jobId={}: {}", jobId, e.getMessage(), e);
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Rebuild cim_objects for ALL jobs matching org + version.
     *
     * POST /api/admin/cim-objects/rebuild?orgId=CAISO&version=DB142
     *
     * Returns a list of RebuildResult — one per matching job.
     * Jobs run sequentially to avoid overloading MongoDB.
     */
    @PostMapping("/cim-objects/rebuild")
    public ResponseEntity<?> rebuildByOrgAndVersion(
            @RequestParam("orgId")   String orgId,
            @RequestParam("version") String version) {
        if (orgId == null || orgId.isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "orgId is required"));
        if (version == null || version.isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "version is required"));
        try {
            List<CimObjectsRebuildService.RebuildResult> results =
                    rebuildService.rebuildByOrgAndVersion(orgId, version);
            long totalCim = results.stream().mapToLong(r -> r.cimObjectsWritten).sum();
            long totalRaw = results.stream().mapToLong(r -> r.rawObjectsRead).sum();
            return ResponseEntity.ok(Map.of(
                "jobs",               results,
                "totalJobsRebuilt",   results.size(),
                "totalRawRead",       totalRaw,
                "totalCimWritten",    totalCim
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            log.error("Bulk rebuild failed: orgId={} version={}: {}",
                    orgId, version, e.getMessage(), e);
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }
}
