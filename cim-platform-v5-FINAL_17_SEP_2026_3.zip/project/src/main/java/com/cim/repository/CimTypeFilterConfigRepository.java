package com.cim.repository;

import com.cim.model.mongo.CimTypeFilterConfig;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;
import java.util.Optional;

public interface CimTypeFilterConfigRepository
        extends MongoRepository<CimTypeFilterConfig, String> {

    /** Find active config for a specific org */
    Optional<CimTypeFilterConfig> findByOrgIdAndEnabledTrue(String orgId);

    /** Find global config (orgId is null) */
    Optional<CimTypeFilterConfig> findByOrgIdIsNullAndEnabledTrue();

    /** All configs for an org */
    List<CimTypeFilterConfig> findByOrgId(String orgId);

    /** All enabled configs */
    List<CimTypeFilterConfig> findByEnabledTrue();
}
