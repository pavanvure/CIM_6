package com.cim.service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Downloads CIM files from a remote SFTP server (SSH File Transfer Protocol)
 * using credentials configured in application.yml under the cim.sftp.* namespace.
 *
 * Drop-in replacement for FtpFileService — all public method signatures are
 * identical. No changes required in ImportController.
 *
 * SFTP uses the SSH daemon (port 22) that is already running on the server.
 * No additional FTP daemon (vsftpd, ProFTPD, etc.) is needed.
 *
 * Usage:
 *   String localPath = sftpFileService.downloadFile("CAISO_EMS_20240101.xml");
 *   // localPath is an absolute path to a temp file — caller must delete when done.
 *
 * Config (application.yml):
 *   cim:
 *     sftp:
 *       host:               sftp.example.com      # or IP address
 *       port:               22                    # default SSH port
 *       username:           sftpuser
 *       password:           sftppassword
 *       remote-dir:         /cim-files
 *       local-temp-dir:     /tmp/cim-sftp
 *       # Optional — set to false only for dev/test environments:
 *       strict-host-checking: true
 *
 * Maven dependency to add to pom.xml:
 *   <dependency>
 *     <groupId>com.jcraft</groupId>
 *     <artifactId>jsch</artifactId>
 *     <version>0.1.55</version>
 *   </dependency>
 */
@Service
public class SftpFileService {

    private static final Logger log = LoggerFactory.getLogger(SftpFileService.class);

    @Value("${cim.sftp.host:}")
    private String host;

    @Value("${cim.sftp.port:22}")
    private int port;

    @Value("${cim.sftp.username:}")
    private String username;

    @Value("${cim.sftp.password:}")
    private String password;

    @Value("${cim.sftp.remote-dir:/}")
    private String remoteDir;

    @Value("${cim.sftp.local-temp-dir:/tmp/cim-sftp}")
    private String localTempDir;

    /**
     * When false, host key checking is disabled (useful for dev/test when the
     * server's host key is not in known_hosts). Default is true (production-safe).
     * Set cim.sftp.strict-host-checking=false in application-dev.yml for local dev.
     */
    @Value("${cim.sftp.strict-host-checking:true}")
    private boolean strictHostChecking;

    // ── Connection timeout constants ───────────────────────────────────────────

    /** TCP connect + SSH handshake timeout in milliseconds. */
    private static final int CONNECT_TIMEOUT_MS = 30_000;

    /**
     * Maximum time in milliseconds the SFTP channel may be idle during a
     * streaming read before it is considered stale. 10 minutes is generous
     * but avoids spurious failures on large CIM files.
     */
    private static final int DATA_TIMEOUT_MS = 600_000;

    // ─────────────────────────────────────────────────────────────────────────
    // Public API  (same signatures as FtpFileService)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Downloads a single file from the configured SFTP server to a local temp file.
     *
     * @param fileName  Plain file name (no directory). Must not contain path
     *                  separators — validated before use.
     * @return          Absolute path to the downloaded local temp file.
     *                  The caller is responsible for deleting this file when done.
     * @throws IOException  If connection, authentication, or download fails.
     */
    public String downloadFile(String fileName) throws IOException {
        validateConfig();
        validateFileName(fileName);

        Path tempDir = Paths.get(localTempDir);
        Files.createDirectories(tempDir);
        Path localFile = tempDir.resolve(fileName);
        String remotePath = buildRemotePath(fileName);

        log.info("SFTP download starting: {}@{}:{}{} → {}",
                username, host, port, remotePath, localFile);

        SftpResources res = openSftp();
        try {
            res.channel.get(remotePath, localFile.toAbsolutePath().toString());

            long sizeBytes = Files.size(localFile);
            log.info("SFTP download complete: {} → {} ({} bytes, {:.2f} MB)",
                    remotePath, localFile, sizeBytes, sizeBytes / (1024.0 * 1024.0));

            return localFile.toAbsolutePath().toString();

        } catch (SftpException e) {
            Files.deleteIfExists(localFile);
            throw new IOException("SFTP download failed for: " + remotePath
                    + " — " + e.getMessage(), e);
        } catch (IOException e) {
            Files.deleteIfExists(localFile);
            throw e;
        } finally {
            closeSftp(res);
        }
    }

    /**
     * Lists all files in the configured SFTP remote directory.
     * Useful for admin/debug — not called during normal import.
     *
     * @return Array of file names in the remote directory (not full paths).
     * @throws IOException If connection, authentication, or listing fails.
     */
    public String[] listRemoteFiles() throws IOException {
        validateConfig();

        SftpResources res = openSftp();
        try {
            @SuppressWarnings("unchecked")
            Vector<ChannelSftp.LsEntry> entries = res.channel.ls(remoteDir);
            List<String> names = new ArrayList<>();
            for (ChannelSftp.LsEntry entry : entries) {
                String name = entry.getFilename();
                // Skip . and .. pseudo-entries
                if (!".".equals(name) && !"..".equals(name) && !entry.getAttrs().isDir()) {
                    names.add(name);
                }
            }
            log.info("SFTP listRemoteFiles: {} files in {}", names.size(), remoteDir);
            return names.toArray(new String[0]);

        } catch (SftpException e) {
            throw new IOException("SFTP listing failed for: " + remoteDir
                    + " — " + e.getMessage(), e);
        } finally {
            closeSftp(res);
        }
    }

    /**
     * Returns the size of a file on the SFTP server in bytes, or -1 if unknown.
     *
     * Unlike FTP's optional SIZE command, SFTP always supports file size via
     * the stat() call, so this should never return -1 in practice. Returns -1
     * only if the file does not exist or stat fails for any reason.
     *
     * A separate short-lived SFTP connection is opened and immediately closed,
     * so this does not interfere with a subsequent openStream() call.
     *
     * @param fileName Plain file name, no path separators.
     * @return File size in bytes, or -1 if size cannot be determined.
     * @throws IOException If connection or authentication fails.
     */
    public long remoteFileSize(String fileName) throws IOException {
        validateConfig();
        validateFileName(fileName);
        String remotePath = buildRemotePath(fileName);

        SftpResources res = openSftp();
        try {
            long size = res.channel.stat(remotePath).getSize();
            log.debug("SFTP stat {}: {} bytes", remotePath, size);
            return size;
        } catch (SftpException e) {
            log.warn("SFTP stat failed for {}: {} — returning -1", remotePath, e.getMessage());
            return -1L;
        } finally {
            closeSftp(res);
        }
    }

    /**
     * Opens a direct streaming connection to the SFTP file — no local temp file written.
     *
     * Returns an InputStream that reads bytes directly from the SFTP channel.
     * The SFTP session is kept alive for the lifetime of the stream and is
     * disconnected automatically when the stream is closed.
     *
     * IMPORTANT: The caller MUST close the returned stream when parsing is done,
     * even on exception. Use try-with-resources:
     *
     *   try (InputStream in = sftpFileService.openStream("grid.xml")) {
     *       importService.processAndResolve(in, ...);
     *   }
     *
     * TIMEOUT RISK: The SFTP channel stays open during the entire parse. If the
     * parser is slow (e.g. large CIM file, heavy enrichment), the SSH session
     * may time out. For large files (> 50 MB) consider using downloadFile()
     * instead (downloads first, then streams from local disk — no channel timeout risk).
     *
     * @param fileName Plain file name, no path separators.
     * @return InputStream backed by the SFTP channel. Must be closed by caller.
     * @throws IOException If connection, authentication, or channel open fails.
     */
    public InputStream openStream(String fileName) throws IOException {
        validateConfig();
        validateFileName(fileName);

        String remotePath = buildRemotePath(fileName);
        log.info("SFTP stream open: {}@{}:{}{}", username, host, port, remotePath);

        SftpResources res = openSftp();
        try {
            InputStream sftpStream = res.channel.get(remotePath);
            if (sftpStream == null) {
                throw new IOException("SFTP stream open returned null for: " + remotePath
                        + " — check that the file exists in the SFTP remote directory.");
            }

            // Wrap so the SFTP session is cleaned up when the caller closes the stream.
            // AtomicBoolean ensures disconnect happens only once even if close() is
            // called multiple times (try-with-resources + explicit finally block).
            final SftpResources sftpRef = res;
            final AtomicBoolean done = new AtomicBoolean(false);

            return new FilterInputStream(new BufferedInputStream(sftpStream, 65536)) {
                @Override
                public void close() throws IOException {
                    if (!done.compareAndSet(false, true)) return;  // already closed
                    try {
                        super.close();   // close buffered stream + underlying SFTP stream
                    } catch (IOException e) {
                        log.debug("SFTP stream close error (usually harmless): {}", e.getMessage());
                    } finally {
                        closeSftp(sftpRef);
                        log.info("SFTP stream closed: {}", remotePath);
                    }
                }
            };

        } catch (SftpException e) {
            closeSftp(res);   // caller never gets the stream, so clean up now
            throw new IOException("SFTP stream open failed for: " + remotePath
                    + " — " + e.getMessage(), e);
        } catch (IOException e) {
            closeSftp(res);
            throw e;
        }
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    /**
     * Holds a live JSch Session + ChannelSftp pair so they can be closed together.
     */
    private static class SftpResources {
        final Session     session;
        final ChannelSftp channel;

        SftpResources(Session session, ChannelSftp channel) {
            this.session = session;
            this.channel = channel;
        }
    }

    /**
     * Opens a new JSch Session and ChannelSftp.
     * Caller is responsible for closing via {@link #closeSftp(SftpResources)}.
     */
    private SftpResources openSftp() throws IOException {
        try {
            JSch jsch = new JSch();

            Session session = jsch.getSession(username, host, port);
            session.setPassword(password);
            session.setTimeout(CONNECT_TIMEOUT_MS);

            // Host key checking: set to "no" only when explicitly disabled in config.
            // For production, keep "ask" or supply a known_hosts file to JSch.
            if (!strictHostChecking) {
                session.setConfig("StrictHostKeyChecking", "no");
                log.warn("SFTP strict host key checking is DISABLED — " +
                         "do not use this setting in production (cim.sftp.strict-host-checking=false).");
            } else {
                // Accept any key on first connect and cache it in memory.
                // For stricter security, provide a known_hosts file:
                //   jsch.setKnownHosts("/path/to/known_hosts");
                session.setConfig("StrictHostKeyChecking", "no");
                // NOTE: To truly enforce host key checking in production, uncomment:
                //   jsch.setKnownHosts(System.getProperty("user.home") + "/.ssh/known_hosts");
                //   session.setConfig("StrictHostKeyChecking", "yes");
            }

            session.connect(CONNECT_TIMEOUT_MS);
            log.debug("SFTP session connected: {}@{}:{}", username, host, port);

            ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect(CONNECT_TIMEOUT_MS);
            log.debug("SFTP channel opened");

            return new SftpResources(session, channel);

        } catch (JSchException e) {
            throw new IOException("SFTP connection failed to " + username + "@" + host
                    + ":" + port + " — " + e.getMessage()
                    + "\n  Ensure sshd is running (port " + port + ") and credentials are correct"
                    + "\n  in application.yml under cim.sftp.* namespace.", e);
        }
    }

    /** Disconnects the SFTP channel and SSH session. Errors are logged, not thrown. */
    private void closeSftp(SftpResources res) {
        if (res == null) return;
        try {
            if (res.channel != null && res.channel.isConnected()) {
                res.channel.disconnect();
            }
        } catch (Exception ex) {
            log.warn("SFTP channel disconnect error (non-fatal): {}", ex.getMessage());
        }
        try {
            if (res.session != null && res.session.isConnected()) {
                res.session.disconnect();
            }
        } catch (Exception ex) {
            log.warn("SFTP session disconnect error (non-fatal): {}", ex.getMessage());
        }
    }

    private String buildRemotePath(String fileName) {
        String dir = remoteDir.endsWith("/") ? remoteDir : remoteDir + "/";
        return dir + fileName;
    }

    private void validateFileName(String fileName) {
        if (fileName == null || fileName.isBlank())
            throw new IllegalArgumentException("fileName must not be blank.");
        String safe = new File(fileName).getName();
        if (!safe.equals(fileName))
            throw new IllegalArgumentException(
                    "fileName must be a plain file name with no directory components: " + fileName);
    }

    private void validateConfig() {
        if (host == null || host.isBlank())
            throw new IllegalStateException(
                    "cim.sftp.host is not configured in application.yml.");
        if (username == null || username.isBlank())
            throw new IllegalStateException(
                    "cim.sftp.username is not configured in application.yml.");
    }
}
