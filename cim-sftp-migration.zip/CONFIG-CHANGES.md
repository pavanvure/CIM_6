# SFTP Migration — Configuration Changes

## 1. pom.xml — add JSch dependency

Replace (or remove) the commons-net FTP dependency and add JSch for SFTP:

```xml
<!-- REMOVE or keep if still used elsewhere -->
<!--
<dependency>
    <groupId>commons-net</groupId>
    <artifactId>commons-net</artifactId>
    <version>3.9.0</version>
</dependency>
-->

<!-- ADD: JSch — SSH/SFTP client library -->
<dependency>
    <groupId>com.jcraft</groupId>
    <artifactId>jsch</artifactId>
    <version>0.1.55</version>
</dependency>
```

## 2. application.yml — change cim.ftp.* → cim.sftp.*

```yaml
# REMOVE old FTP config:
# cim:
#   ftp:
#     host:           gry3devapps1.dev.oati.local
#     port:           21
#     username:       ftpuser
#     password:       ftppassword
#     remote-dir:     /cim-files
#     local-temp-dir: /tmp/cim-ftp

# ADD new SFTP config:
cim:
  sftp:
    host:                 gry3devapps1.dev.oati.local   # same server — sshd runs on port 22
    port:                 22
    username:             sftpuser                       # SSH/SFTP user (ask IT team)
    password:             sftppassword                   # SSH/SFTP password
    remote-dir:           /cim-files                     # absolute path on the server
    local-temp-dir:       /tmp/cim-sftp
    strict-host-checking: false                          # set true in prod with known_hosts
```

## 3. ImportController.java — rename injection

Change the injected service name from `ftpFileService` → `sftpFileService`
and change the type from `FtpFileService` → `SftpFileService`.

**Before:**
```java
@Autowired
private FtpFileService ftpFileService;
```

**After:**
```java
@Autowired
private SftpFileService sftpFileService;
```

Then replace all occurrences of `ftpFileService.` → `sftpFileService.` in the file.
All method calls (`downloadFile`, `listRemoteFiles`, `remoteFileSize`, `openStream`)
have identical signatures — no other code changes needed.

## 4. IT Team requirements

The IT team does NOT need to install any new software.
`sshd` is already running on port 22 on both cluster nodes.

Ask IT to:
1. Create an SSH user (e.g. `sftpuser`) or use an existing one.
2. Set the user's home/chroot to the directory where CIM files are placed
   (e.g. `/cim-files`).
3. Ensure the files are readable by that user.

## 5. Cluster note (gry3devapps1 + gry3devapps2)

Both nodes run sshd on port 22.
Point `cim.sftp.host` to whichever node holds the CIM files, OR use a
shared NFS/CIFS mount so both nodes see the same directory.
