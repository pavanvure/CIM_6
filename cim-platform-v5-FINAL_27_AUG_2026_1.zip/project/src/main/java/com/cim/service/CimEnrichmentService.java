package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Phase 3 post-import enrichment for cim_objects.
 *
 * Computes nominalVoltage_1, substationMrid_N/Name_N,
 * subGeographicalRegionMrid_N/Name_N, geographicalRegionMrid_N/Name_N
 * by walking resolvedRefIds chains in MongoDB.
 *
 * KEY DESIGN NOTE — MapKeySanitizer encoding:
 *   MongoDB does not allow dots in field keys. The codebase uses
 *   MapKeySanitizer which replaces "." with U+FF0E (fullwidth dot ．).
 *   So resolvedRefIds keys are stored as e.g. "Terminal．ConductingEquipment".
 *
 *   IMPORTANT: Do NOT use encoded keys in MongoDB field PATH expressions
 *   (projections like "resolvedRefIds.Terminal．ConductingEquipment" or
 *   Criteria.where("resolvedRefIds.key")) because MongoDB interprets
 *   the REAL dot in the path as a nested-object separator and the
 *   fullwidth-dot key inside confuses the path resolver.
 *
 *   CORRECT approach: fetch the WHOLE resolvedRefIds / attributes map
 *   ("include resolvedRefIds") and look up the encoded key in Java after
 *   Spring Data MongoDB deserializes the document. The Java Map.get()
 *   call handles the fullwidth-dot key perfectly.
 *
 * ORGANISATION GATE:
 *   Currently CAISO only. To enable for another org, add to
 *   ENRICHMENT_ENABLED_ORGS — one line, no other changes needed.
 */
@Service
public class CimEnrichmentService {

    private static final Logger log = LoggerFactory.getLogger(CimEnrichmentService.class);

    /**
     * ORGANISATION GATE.
     * To add another org, uncomment its line below — nothing else changes.
     */
    private static final Set<String> ENRICHMENT_ENABLED_ORGS =
            new HashSet<>(Arrays.asList(
                "CAISO"
                // "ERCOT",
                // "SPC",
                // "MILSOFT"
            ));

    private static final int PAGE_SIZE   = 500;
    private static final int WRITE_BATCH = 200;

    // Encoded ref keys (fullwidth dots) — match exactly what's in MongoDB
    private static final String KEY_BV_NOMINAL =
            MapKeySanitizer.encode("BaseVoltage.nominalVoltage");
    private static final String KEY_T_EQUIP =
            MapKeySanitizer.encode("Terminal.ConductingEquipment");
    private static final String KEY_T_CN =
            MapKeySanitizer.encode("Terminal.ConnectivityNode");
    private static final String KEY_CN_CONTAINER_1 =
            MapKeySanitizer.encode("ConnectivityNode.ConnectivityNodeContainer");
    private static final String KEY_CN_CONTAINER_2 =
            MapKeySanitizer.encode("ConnectivityNodeContainer");
    private static final String KEY_VL_SUBSTATION =
            MapKeySanitizer.encode("VoltageLevel.MemberOf_Substation");
    private static final String KEY_SUB_REGION =
            MapKeySanitizer.encode("Substation.Region");
    private static final String KEY_SGR_REGION =
            MapKeySanitizer.encode("SubGeographicalRegion.Region");
    private static final String KEY_ID_NAME =
            MapKeySanitizer.encode("IdentifiedObject.name");
    private static final String KEY_CE_BV =
            MapKeySanitizer.encode("ConductingEquipment.BaseVoltage");

    private final MongoTemplate mongo;

    public CimEnrichmentService(MongoTemplate mongo) {
        this.mongo = mongo;
    }

    // ── Public entry point ────────────────────────────────────────────────

    public boolean enrich(String jobId, String orgId) {
        if (!isEnrichmentEnabled(orgId)) {
            log.info("CimEnrichment skipped for org={} (not in ENRICHMENT_ENABLED_ORGS)", orgId);
            return false;
        }

        long start = System.currentTimeMillis();
        log.info("CimEnrichment Phase 3 starting: job={} org={}", jobId, orgId);

        // Build lookup maps — fetch WHOLE resolvedRefIds/attributes maps,
        // look up specific keys in Java (avoids MongoDB path issues with fullwidth dots)
        Map<String, String>       bvMap            = buildBaseVoltageMap(jobId);
        Map<String, List<String>> terminalsByEquip = buildTerminalsByEquipMap(jobId);
        Map<String, String>       cnByTerminal     = buildCnByTerminalMap(jobId);
        Map<String, String>       vlByCn           = buildVlByCnMap(jobId);
        Map<String, SubInfo>      subByVl          = buildSubByVlMap(jobId);
        enrichSubInfoWithRegions(jobId, subByVl);

        log.info("CimEnrichment maps built: bv={} termsByEquip={} cnByT={} vlByCn={} subByVl={}",
                bvMap.size(), terminalsByEquip.size(),
                cnByTerminal.size(), vlByCn.size(), subByVl.size());

        long voltageCount = 0, substationCount = 0;
        String lastId = null;

        while (true) {
            List<CimObjectRecord> page = fetchPage(jobId, lastId);
            if (page.isEmpty()) break;
            lastId = page.get(page.size() - 1).getId();

            List<Map<String, Object>> updates = new ArrayList<>();
            for (CimObjectRecord rec : page) {
                Map<String, String> enriched = new LinkedHashMap<>();
                computeNominalVoltage(rec, bvMap, enriched);
                computeSubstationsAndRegions(rec, terminalsByEquip, cnByTerminal,
                        vlByCn, subByVl, enriched);
                if (!enriched.isEmpty()) {
                    if (enriched.containsKey(KEY_CE_BV)) voltageCount++;
                    if (enriched.containsKey(
                            MapKeySanitizer.encode("substationMrid_1"))) substationCount++;
                    Map<String, Object> upd = new LinkedHashMap<>();
                    upd.put("id", rec.getId());
                    upd.put("enriched", enriched);
                    updates.add(upd);
                }
            }
            for (int from = 0; from < updates.size(); from += WRITE_BATCH)
                bulkWrite(updates.subList(from, Math.min(from + WRITE_BATCH, updates.size())));
        }

        log.info("CimEnrichment done: job={} org={} time={} nominalVoltage={} substation={}",
                jobId, orgId,
                com.cim.model.mongo.StageTimings.format(System.currentTimeMillis() - start),
                voltageCount, substationCount);
        return true;
    }

    // ── Organisation gate ─────────────────────────────────────────────────

    private boolean isEnrichmentEnabled(String orgId) {
        if (orgId == null) return false;
        return ENRICHMENT_ENABLED_ORGS.stream()
                .anyMatch(o -> o.equalsIgnoreCase(orgId.trim()));
    }

    // ── Lookup map builders ───────────────────────────────────────────────

    /**
     * BaseVoltage.rdfId → nominalVoltage string.
     * Fetches whole attributes map, looks up KEY_BV_NOMINAL in Java.
     */
    private Map<String, String> buildBaseVoltageMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("BaseVoltage"), lastId);
            // Fetch whole attributes map — NOT "attributes.KEY" path
            q.fields().include("rdfId").include("attributes");
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getAttributes() == null) continue;
                String val = r.getAttributes().get(KEY_BV_NOMINAL);
                if (val != null && !val.isBlank())
                    map.put(r.getRdfId(), val);
            }
        }
        log.debug("buildBaseVoltageMap: {} entries", map.size());
        return map;
    }

    /**
     * equipment.rdfId → List of Terminal rdfIds.
     * Fetches whole resolvedRefIds, looks up KEY_T_EQUIP in Java.
     */
    private Map<String, List<String>> buildTerminalsByEquipMap(String jobId) {
        Map<String, List<String>> map = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("Terminal"), lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String equipRdfId = r.getResolvedRefIds().get(KEY_T_EQUIP);
                if (equipRdfId == null || equipRdfId.isBlank()) continue;
                map.computeIfAbsent(equipRdfId, k -> new ArrayList<>()).add(r.getRdfId());
            }
        }
        log.debug("buildTerminalsByEquipMap: {} equipment entries", map.size());
        return map;
    }

    /**
     * Terminal.rdfId → ConnectivityNode.rdfId.
     */
    private Map<String, String> buildCnByTerminalMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("Terminal"), lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String cnRdfId = r.getResolvedRefIds().get(KEY_T_CN);
                if (cnRdfId != null && !cnRdfId.isBlank())
                    map.put(r.getRdfId(), cnRdfId);
            }
        }
        log.debug("buildCnByTerminalMap: {} entries", map.size());
        return map;
    }

    /**
     * ConnectivityNode.rdfId → VoltageLevel.rdfId.
     * Tries both ConnectivityNode.ConnectivityNodeContainer and ConnectivityNodeContainer.
     */
    private Map<String, String> buildVlByCnMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("ConnectivityNode"), lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String vlRdfId = r.getResolvedRefIds().get(KEY_CN_CONTAINER_1);
                if (vlRdfId == null || vlRdfId.isBlank())
                    vlRdfId = r.getResolvedRefIds().get(KEY_CN_CONTAINER_2);
                if (vlRdfId != null && !vlRdfId.isBlank())
                    map.put(r.getRdfId(), vlRdfId);
            }
        }
        log.debug("buildVlByCnMap: {} entries", map.size());
        return map;
    }

    /**
     * VoltageLevel.rdfId → SubInfo (substation mrid+name, rdfId for SGR lookup).
     */
    private Map<String, SubInfo> buildSubByVlMap(String jobId) {
        // Step A: VL → substationRdfId
        Map<String, String> subRdfByVl = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("VoltageLevel"), lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String subRdfId = r.getResolvedRefIds().get(KEY_VL_SUBSTATION);
                if (subRdfId != null && !subRdfId.isBlank())
                    subRdfByVl.put(r.getRdfId(), subRdfId);
            }
        }
        if (subRdfByVl.isEmpty()) return new HashMap<>();

        // Step B: fetch Substation mrid + name
        Set<String> subRdfIds = new HashSet<>(subRdfByVl.values());
        Map<String, SubInfo> subInfoByRdfId = new HashMap<>();
        Query subQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("Substation")
                .and("rdfId").in(subRdfIds));
        subQ.fields().include("rdfId").include("mrid").include("attributes");
        List<CimObjectRecord> subs = mongo.find(subQ, CimObjectRecord.class, "cim_objects");
        for (CimObjectRecord r : subs) {
            if (r.getRdfId() == null) continue;
            String name = r.getAttributes() != null
                    ? r.getAttributes().get(KEY_ID_NAME) : null;
            SubInfo si = new SubInfo(r.getRdfId(), r.getMrid(), name);
            subInfoByRdfId.put(r.getRdfId(), si);
        }

        // Step C: compose vlRdfId → SubInfo
        Map<String, SubInfo> result = new HashMap<>();
        for (Map.Entry<String, String> e : subRdfByVl.entrySet()) {
            SubInfo si = subInfoByRdfId.get(e.getValue());
            if (si != null) result.put(e.getKey(), si);
        }
        log.debug("buildSubByVlMap: {} vl→sub entries", result.size());
        return result;
    }

    /**
     * Enriches each SubInfo with SGR and GR mrid + name.
     * Chain: Substation.Region → SGR → SubGeographicalRegion.Region → GR
     */
    private void enrichSubInfoWithRegions(String jobId,
                                           Map<String, SubInfo> subByVl) {
        if (subByVl.isEmpty()) return;

        // Collect unique substationRdfIds
        Set<String> subRdfIds = new HashSet<>();
        for (SubInfo si : subByVl.values())
            if (si.rdfId != null) subRdfIds.add(si.rdfId);
        if (subRdfIds.isEmpty()) return;

        // Fetch Substation → SGR ref
        Map<String, String> sgrRdfBySubRdf = new HashMap<>();
        Query subQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("Substation")
                .and("rdfId").in(subRdfIds));
        subQ.fields().include("rdfId").include("resolvedRefIds");
        for (CimObjectRecord r : mongo.find(subQ, CimObjectRecord.class, "cim_objects")) {
            if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
            String sgrRdfId = r.getResolvedRefIds().get(KEY_SUB_REGION);
            if (sgrRdfId != null && !sgrRdfId.isBlank())
                sgrRdfBySubRdf.put(r.getRdfId(), sgrRdfId);
        }

        Set<String> sgrRdfIds = new HashSet<>(sgrRdfBySubRdf.values());
        if (sgrRdfIds.isEmpty()) return;

        // Fetch SGR mrid + name + GR ref
        Map<String, String[]> sgrInfoByRdf = new HashMap<>(); // rdfId→[mrid,name,grRdfId]
        Query sgrQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("SubGeographicalRegion")
                .and("rdfId").in(sgrRdfIds));
        sgrQ.fields().include("rdfId").include("mrid").include("attributes")
                     .include("resolvedRefIds");
        for (CimObjectRecord r : mongo.find(sgrQ, CimObjectRecord.class, "cim_objects")) {
            if (r.getRdfId() == null) continue;
            String name    = r.getAttributes() != null ? r.getAttributes().get(KEY_ID_NAME) : null;
            String grRdfId = r.getResolvedRefIds() != null
                    ? r.getResolvedRefIds().get(KEY_SGR_REGION) : null;
            sgrInfoByRdf.put(r.getRdfId(), new String[]{r.getMrid(), name, grRdfId});
        }

        // Collect GR rdfIds
        Set<String> grRdfIds = new HashSet<>();
        for (String[] v : sgrInfoByRdf.values())
            if (v[2] != null && !v[2].isBlank()) grRdfIds.add(v[2]);

        Map<String, String[]> grInfoByRdf = new HashMap<>(); // rdfId→[mrid,name]
        if (!grRdfIds.isEmpty()) {
            Query grQ = new Query(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("GeographicalRegion")
                    .and("rdfId").in(grRdfIds));
            grQ.fields().include("rdfId").include("mrid").include("attributes");
            for (CimObjectRecord r : mongo.find(grQ, CimObjectRecord.class, "cim_objects")) {
                if (r.getRdfId() == null) continue;
                String name = r.getAttributes() != null
                        ? r.getAttributes().get(KEY_ID_NAME) : null;
                grInfoByRdf.put(r.getRdfId(), new String[]{r.getMrid(), name});
            }
        }

        // Attach SGR + GR info to each SubInfo
        for (SubInfo si : subByVl.values()) {
            if (si.rdfId == null) continue;
            String sgrRdfId = sgrRdfBySubRdf.get(si.rdfId);
            if (sgrRdfId == null) continue;
            String[] sgrInfo = sgrInfoByRdf.get(sgrRdfId);
            if (sgrInfo == null) continue;
            si.sgrMrid = sgrInfo[0];
            si.sgrName = sgrInfo[1];
            if (sgrInfo[2] != null) {
                String[] grInfo = grInfoByRdf.get(sgrInfo[2]);
                if (grInfo != null) { si.grMrid = grInfo[0]; si.grName = grInfo[1]; }
            }
        }
        log.debug("enrichSubInfoWithRegions: enriched {} substation entries", subByVl.size());
    }

    // ── Per-object computation ─────────────────────────────────────────────

    private void computeNominalVoltage(CimObjectRecord rec,
                                        Map<String, String> bvMap,
                                        Map<String, String> enriched) {
        if (rec.getResolvedRefIds() == null) return;
        String bvRdfId = rec.getResolvedRefIds().get(KEY_CE_BV);
        if (bvRdfId == null || bvRdfId.isBlank()) return;
        String voltage = bvMap.get(bvRdfId);
        if (voltage == null || voltage.isBlank()) return;
        enriched.put(MapKeySanitizer.encode("nominalVoltage_1"), voltage);
    }

    private void computeSubstationsAndRegions(CimObjectRecord rec,
                                               Map<String, List<String>> terminalsByEquip,
                                               Map<String, String> cnByTerminal,
                                               Map<String, String> vlByCn,
                                               Map<String, SubInfo> subByVl,
                                               Map<String, String> enriched) {
        if (rec.getRdfId() == null) return;
        List<String> terminals = terminalsByEquip.get(rec.getRdfId());
        if (terminals == null || terminals.isEmpty()) return;

        // Walk each terminal → CN → VL → SubInfo, collect distinct substations
        LinkedHashMap<String, SubInfo> found = new LinkedHashMap<>();
        for (String tRdfId : terminals) {
            String cnRdfId = cnByTerminal.get(tRdfId);
            if (cnRdfId == null) continue;
            String vlRdfId = vlByCn.get(cnRdfId);
            if (vlRdfId == null) continue;
            SubInfo sub = subByVl.get(vlRdfId);
            if (sub == null) continue;
            String key = sub.mrid != null ? sub.mrid : sub.rdfId;
            if (key != null) found.put(key, sub);
        }
        if (found.isEmpty()) return;

        int idx = 1;
        for (SubInfo sub : found.values()) {
            // Substation
            if (sub.mrid != null && !sub.mrid.isBlank())
                enriched.put(MapKeySanitizer.encode("substationMrid_" + idx), sub.mrid);
            if (sub.name != null && !sub.name.isBlank())
                enriched.put(MapKeySanitizer.encode("substationName_" + idx), sub.name);
            // SubGeographicalRegion
            if (sub.sgrMrid != null && !sub.sgrMrid.isBlank())
                enriched.put(MapKeySanitizer.encode("subGeographicalRegionMrid_" + idx), sub.sgrMrid);
            if (sub.sgrName != null && !sub.sgrName.isBlank())
                enriched.put(MapKeySanitizer.encode("subGeographicalRegionName_" + idx), sub.sgrName);
            // GeographicalRegion
            if (sub.grMrid != null && !sub.grMrid.isBlank())
                enriched.put(MapKeySanitizer.encode("geographicalRegionMrid_" + idx), sub.grMrid);
            if (sub.grName != null && !sub.grName.isBlank())
                enriched.put(MapKeySanitizer.encode("geographicalRegionName_" + idx), sub.grName);
            idx++;
        }
    }

    // ── Write ──────────────────────────────────────────────────────────────

    /**
     * Writes enriched attributes onto cim_objects.
     * raw_objects are intentionally NOT touched.
     */
    private void bulkWrite(List<Map<String, Object>> updates) {
        for (Map<String, Object> upd : updates) {
            String id = (String) upd.get("id");
            @SuppressWarnings("unchecked")
            Map<String, String> enriched = (Map<String, String>) upd.get("enriched");
            if (enriched == null || enriched.isEmpty()) continue;
            Update update = new Update();
            for (Map.Entry<String, String> e : enriched.entrySet()) {
                update.set("attributes." + e.getKey(), e.getValue());
            }
            try {
                mongo.updateFirst(
                    new Query(Criteria.where("_id").is(
                            new org.bson.types.ObjectId(id))),
                    update, "cim_objects");
            } catch (Exception ex) {
                log.warn("bulkWrite error id={}: {}", id, ex.getMessage());
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<CimObjectRecord> fetchPage(String jobId, String lastId) {
        Criteria c = Criteria.where("jobId").is(jobId);
        if (lastId != null)
            c = new Criteria().andOperator(c,
                    Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));
        Query q = new Query(c).limit(PAGE_SIZE)
                .with(Sort.by(Sort.Direction.ASC, "_id"));
        q.fields().include("rdfId").include("cimType")
                  .include("resolvedRefIds").include("mrid");
        return mongo.find(q, CimObjectRecord.class, "cim_objects");
    }

    private Query pageQuery(Criteria base, String lastId) {
        Criteria c = lastId == null ? base :
                new Criteria().andOperator(base,
                        Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));
        return new Query(c).limit(PAGE_SIZE)
                .with(Sort.by(Sort.Direction.ASC, "_id"));
    }

    // ── Inner class ────────────────────────────────────────────────────────

    private static class SubInfo {
        final String rdfId; // needed to look up SGR via Substation.Region
        final String mrid;
        final String name;
        String sgrMrid; String sgrName;
        String grMrid;  String grName;

        SubInfo(String rdfId, String mrid, String name) {
            this.rdfId = rdfId;
            this.mrid  = mrid;
            this.name  = name;
        }
    }
}
