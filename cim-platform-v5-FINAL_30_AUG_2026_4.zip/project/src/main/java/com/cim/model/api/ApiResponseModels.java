package com.cim.model.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import java.util.Map;

/**
 * Springfox @ApiModel classes that match the ACTUAL response shapes returned
 * by controllers. Each class corresponds to one ResponseEntity.ok(...) shape.
 *
 * Using real POJOs (not Map<String,Object>) means Springfox can generate
 * accurate schemas in the live Swagger UI, fixing the "void" return type
 * problem caused by ResponseEntity<?> wildcards.
 *
 * Controllers are annotated with @ApiOperation(response = XxxResponse.class)
 * to tell Springfox which class to use for each endpoint.
 */
public class ApiResponseModels {

    // ── Import / Jobs ─────────────────────────────────────────────────────

    @ApiModel("ImportJobResponse")
    public static class ImportJobResponse {
        @ApiModelProperty("Import job UUID") public String jobId;
        @ApiModelProperty("PENDING | PROCESSING | RESOLVED | FAILED") public String status;
        @ApiModelProperty public String networkVersion;
        @ApiModelProperty public String orgId;
        @ApiModelProperty public String fileName;
        @ApiModelProperty("RDF_XML | JSON_LD | MILSOFT_CSV") public String format;
        @ApiModelProperty public long totalObjects;
        @ApiModelProperty public long physicalObjects;
        @ApiModelProperty public long logicalObjects;
        @ApiModelProperty public Object stageTimings;
        @ApiModelProperty public Map<String, String> links;
    }

    @ApiModel("AsyncImportResponse")
    public static class AsyncImportResponse {
        @ApiModelProperty public String jobId;
        @ApiModelProperty("Always PROCESSING for async jobs") public String status;
        @ApiModelProperty public String networkVersion;
        @ApiModelProperty public String orgId;
        @ApiModelProperty public String fileName;
        @ApiModelProperty public String fileSizeMb;
        @ApiModelProperty public Map<String, String> links;
    }

    @ApiModel("ArchiveImportResponse")
    public static class ArchiveImportResponse {
        @ApiModelProperty("Name of the archive file on the server") public String archiveFileName;
        @ApiModelProperty("Total number of files extracted from the archive") public int totalFiles;
        @ApiModelProperty("One entry per extracted file") public List<ArchiveEntryResult> results;

        @ApiModel("ArchiveEntryResult")
        public static class ArchiveEntryResult {
            @ApiModelProperty public String fileName;
            @ApiModelProperty("HTTP status that would have been returned for this file directly (200, 202, 400, 409)") public int httpStatus;
            @ApiModelProperty("Same response body a direct single-file import would have produced") public Object response;
        }
    }

    @ApiModel("JobListResponse")
    public static class JobListResponse {
        @ApiModelProperty public List<JobSummary> jobs;
        @ApiModelProperty public long total;
    }

    @ApiModel("JobSummary")
    public static class JobSummary {
        @ApiModelProperty public String jobId;
        @ApiModelProperty public String networkVersion;
        @ApiModelProperty public String orgId;
        @ApiModelProperty public String status;
        @ApiModelProperty public long totalObjects;
        @ApiModelProperty public long physicalObjects;
        @ApiModelProperty public long logicalObjects;
        @ApiModelProperty public String submittedAt;
        @ApiModelProperty public String completedAt;
        @ApiModelProperty public Object stageTimings;
    }

    @ApiModel("JobStatsResponse")
    public static class JobStatsResponse {
        @ApiModelProperty public String jobId;
        @ApiModelProperty public String networkVersion;
        @ApiModelProperty public String orgId;
        @ApiModelProperty public long totalObjects;
        @ApiModelProperty public long physicalObjects;
        @ApiModelProperty public long logicalObjects;
        @ApiModelProperty public long rawObjects;
        @ApiModelProperty("Objects with at least one pathIssue") public long objectsWithPathIssues;
        @ApiModelProperty public long pathIssueCount;
    }

    @ApiModel("ProgressResponse")
    public static class ProgressResponse {
        @ApiModelProperty public String jobId;
        @ApiModelProperty public String orgId;
        @ApiModelProperty public String networkVersion;
        @ApiModelProperty("STREAMING_PARSE | RESOLVING_REFERENCES") public String stage;
        @ApiModelProperty public long parsed;
        @ApiModelProperty public long saved;
        @ApiModelProperty public int percentSaved;
        @ApiModelProperty("e.g. '14m 22s'") public String elapsedFormatted;
        @ApiModelProperty public double parseRatePerSec;
        @ApiModelProperty public boolean finished;
        @ApiModelProperty public String detail;
        @ApiModelProperty public Object stageTimings;
    }

    @ApiModel("VersionListResponse")
    public static class VersionListResponse {
        @ApiModelProperty public String orgId;
        @ApiModelProperty public List<String> versions;
        @ApiModelProperty public int total;
    }

    // ── Query (cim_objects) ───────────────────────────────────────────────

    @ApiModel("PagedObjectsResponse")
    public static class PagedObjectsResponse {
        @ApiModelProperty("Array of CimObjectRecord items for this page") public List<Object> content;
        @ApiModelProperty public long totalElements;
        @ApiModelProperty public int totalPages;
        @ApiModelProperty public int page;
        @ApiModelProperty public int size;
    }

    @ApiModel("ObjectStatsResponse")
    public static class ObjectStatsResponse {
        @ApiModelProperty public String jobId;
        @ApiModelProperty public String networkVersion;
        @ApiModelProperty public String orgId;
        @ApiModelProperty public long total;
        @ApiModelProperty public long physical;
        @ApiModelProperty public long logical;
        @ApiModelProperty public long required;
        @ApiModelProperty public long notRequired;
        @ApiModelProperty public long withPathIssues;
        @ApiModelProperty("Count per cimType, e.g. {ACLineSegment: 452, Breaker: 188}") public Map<String, Long> byType;
    }

    @ApiModel("PathIssuesResponse")
    public static class PathIssuesResponse {
        @ApiModelProperty public String jobId;
        @ApiModelProperty public long total;
        @ApiModelProperty public int page;
        @ApiModelProperty public int size;
        @ApiModelProperty public List<Object> content;
    }

    @ApiModel("RequiredSummaryResponse")
    public static class RequiredSummaryResponse {
        @ApiModelProperty public String jobId;
        @ApiModelProperty public long total;
        @ApiModelProperty public long required;
        @ApiModelProperty public long notRequired;
        @ApiModelProperty("Breakdown of required counts by category (PHYSICAL/LOGICAL)") public Map<String, Object> breakdown;
    }

    @ApiModel("RevalidatePathsResponse")
    public static class RevalidatePathsResponse {
        @ApiModelProperty public String jobId;
        @ApiModelProperty public long rechecked;
        @ApiModelProperty public long invalidPaths;
        @ApiModelProperty public String message;
    }

    // ── Raw objects ───────────────────────────────────────────────────────

    @ApiModel("RawObjectStatsResponse")
    public static class RawObjectStatsResponse {
        @ApiModelProperty public String jobId;
        @ApiModelProperty public long total;
        @ApiModelProperty("Count per cimType") public Map<String, Long> byType;
    }

    @ApiModel("RawCompareResponse")
    public static class RawCompareResponse {
        @ApiModelProperty public String rdfId;
        @ApiModelProperty public String cimType;
        @ApiModelProperty("Keys present in raw_objects but absent or null in cim_objects") public List<String> filteredOutKeys;
        @ApiModelProperty public Object rawObject;
        @ApiModelProperty public Object cimObject;
    }

    // ── CIM Standard (Admin) ─────────────────────────────────────────────

    @ApiModel("CimStatsResponse")
    public static class CimStatsResponse {
        @ApiModelProperty public int totalClasses;
        @ApiModelProperty public int totalAttributes;
        @ApiModelProperty public String owlVersion;
        @ApiModelProperty("Count of classes per package/namespace") public Map<String, Integer> byPackage;
    }

    @ApiModel("CimClassResponse")
    public static class CimClassResponse {
        @ApiModelProperty public String className;
        @ApiModelProperty public String parentClass;
        @ApiModelProperty("true if this is the top-level root class") public boolean isRoot;
        @ApiModelProperty("All ancestor class names up to root") public List<String> ancestors;
        @ApiModelProperty("Attributes declared directly on this class (not inherited)") public List<String> ownAttributes;
        @ApiModelProperty("PHYSICAL | LOGICAL | UNKNOWN") public String category;
    }

    @ApiModel("CimChainResponse")
    public static class CimChainResponse {
        @ApiModelProperty public String className;
        @ApiModelProperty("Inheritance chain from requested class to root, leaf-first") public List<String> chain;
        @ApiModelProperty("chain.length - 1") public int depth;
    }

    @ApiModel("ValidatePathResponse")
    public static class ValidatePathResponse {
        @ApiModelProperty public String objectType;
        @ApiModelProperty public String attributeTag;
        @ApiModelProperty("VALID | INVALID_PATH | UNKNOWN_CLASS") public String status;
        @ApiModelProperty public boolean valid;
        @ApiModelProperty public String explanation;
        @ApiModelProperty public List<String> chain;
    }

    @ApiModel("OwlUploadResponse")
    public static class OwlUploadResponse {
        @ApiModelProperty public String message;
        @ApiModelProperty public int classesLoaded;
        @ApiModelProperty public String version;
    }

    // ── Neo4j Export ─────────────────────────────────────────────────────

    @ApiModel("ExportStartedResponse")
    public static class ExportStartedResponse {
        @ApiModelProperty public String exportId;
        @ApiModelProperty public String jobId;
        @ApiModelProperty("FULL | SANITISED | RATIONALISED | CUSTOM") public String versionType;
        @ApiModelProperty("e.g. DB140-1") public String neo4jVersion;
        @ApiModelProperty("RUNNING") public String status;
        @ApiModelProperty public Map<String, String> links;
    }

    @ApiModel("CleanupLabelsResponse")
    public static class CleanupLabelsResponse {
        @ApiModelProperty public long nodesUpdated;
        @ApiModelProperty public String message;
    }

    // ── Neo4j Export Config ───────────────────────────────────────────────

    @ApiModel("ExportConfigByNameResponse")
    public static class ExportConfigByNameResponse {
        @ApiModelProperty("MongoDB _id — use as configId in FROM_CONFIG exports") public String id;
        @ApiModelProperty public String configName;
        @ApiModelProperty public String orgId;
        @ApiModelProperty public boolean autoExport;
        @ApiModelProperty public boolean active;
        @ApiModelProperty("e.g. '16 types'") public String fullTypes;
        @ApiModelProperty public String sanitisedTypes;
        @ApiModelProperty public String rationalisedTypes;
        @ApiModelProperty("Convenience block showing how to call /api/admin/neo4j/export with this config") public Object useForExport;
    }

    // ── Namespace ─────────────────────────────────────────────────────────

    @ApiModel("NamespaceActionResponse")
    public static class NamespaceActionResponse {
        @ApiModelProperty public String message;
        @ApiModelProperty public String prefix;
        @ApiModelProperty public boolean enabled;
        @ApiModelProperty public String note;
    }

    @ApiModel("NamespaceRefreshResponse")
    public static class NamespaceRefreshResponse {
        @ApiModelProperty public String message;
        @ApiModelProperty public long total;
    }

    // ── Revalidation ─────────────────────────────────────────────────────

    @ApiModel("RevalidationStartedResponse")
    public static class RevalidationStartedResponse {
        @ApiModelProperty public String revalidationId;
        @ApiModelProperty public String jobId;
        @ApiModelProperty public String orgId;
        @ApiModelProperty public boolean triggerExport;
        @ApiModelProperty("RUNNING") public String status;
        @ApiModelProperty public String message;
        @ApiModelProperty public Map<String, String> links;
    }

    @ApiModel("RevalidationStatusResponse")
    public static class RevalidationStatusResponse {
        @ApiModelProperty public String revalidationId;
        @ApiModelProperty public String jobId;
        @ApiModelProperty public String orgId;
        @ApiModelProperty("RUNNING | DONE | FAILED") public String status;
        @ApiModelProperty public long objectsReprocessed;
        @ApiModelProperty public String startedAt;
        @ApiModelProperty public String completedAt;
        @ApiModelProperty public String errorMessage;
    }
}
