package com.cim.controller;

import com.cim.model.mongo.Neo4jExportConfig;
import com.cim.repository.Neo4jExportConfigRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.*;
import io.swagger.annotations.*;
import com.cim.model.api.ApiResponseModels.*;

/**
 * Neo4j Export Config REST API — Full CRUD
 *
 * Manages which CIM types are exported to Neo4j and when.
 * Configs with autoExport=true trigger automatically after every import.
 * Configs with autoExport=false are used only by on-demand export.
 *
 * ── CRUD ─────────────────────────────────────────────────────────────
 * POST   /api/admin/neo4j/configs              Create new config
 * GET    /api/admin/neo4j/configs              List all configs
 * GET    /api/admin/neo4j/configs/{id}         Get single config
 * PUT    /api/admin/neo4j/configs/{id}         Full update
 * PATCH  /api/admin/neo4j/configs/{id}         Partial update
 * DELETE /api/admin/neo4j/configs/{id}         Delete config
 *
 * ── Activation ───────────────────────────────────────────────────────
 * PUT    /api/admin/neo4j/configs/{id}/activate    Enable config
 * PUT    /api/admin/neo4j/configs/{id}/deactivate  Disable config
 * PUT    /api/admin/neo4j/configs/{id}/auto-export/enable
 * PUT    /api/admin/neo4j/configs/{id}/auto-export/disable
 *
 * ── Query ─────────────────────────────────────────────────────────────
 * GET    /api/admin/neo4j/configs/active           Active configs only
 * GET    /api/admin/neo4j/configs/auto-export      Auto-export configs
 *
 * Example config body:
 * {
 *   "configName":   "CAISO Physical Equipment",
 *   "description":  "Exports physical CIM types for CAISO grid topology",
 *   "orgId":        "CAISO",
 *   "exportMode":   "CUSTOM",
 *   "cimTypes":     ["ACLineSegment","Breaker","PowerTransformer","Fuse",
 *                    "Disconnector","EnergyConsumer","SynchronousMachine",
 *                    "Terminal","ConnectivityNode","VoltageLevel",
 *                    "Substation","BaseVoltage","Line","GeneratingUnit"],
 *   "clearFirst":   true,
 *   "autoExport":   true,
 *   "active":       true
 * }
 */
@RestController
@RequestMapping("/api/admin/neo4j/configs")
@CrossOrigin(origins = "*")
public class Neo4jExportConfigController {

    private final Neo4jExportConfigRepository repo;

    public Neo4jExportConfigController(Neo4jExportConfigRepository repo) {
        this.repo = repo;
    }

    // ── CREATE ────────────────────────────────────────────────────────────

    /**
     * POST /api/admin/neo4j/configs
     * Create a new export config.
     */
    @PostMapping
    public ResponseEntity<?> create(
            @RequestBody Neo4jExportConfig config,
            @RequestHeader(value="X-User", defaultValue="system") String user) {

        // Validate required fields
        if (config.getConfigName() == null || config.getConfigName().isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error","configName is required."));

        if (config.getExportMode() == null || config.getExportMode().isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error","exportMode is required.",
                                 "valid","ALL, PHYSICAL_ONLY, REQUIRED_ONLY, CUSTOM"));

        if ("CUSTOM".equalsIgnoreCase(config.getExportMode())
                && (config.getCimTypes() == null || config.getCimTypes().isEmpty()))
            return ResponseEntity.badRequest()
                    .body(Map.of("error","cimTypes required when exportMode=CUSTOM."));

        // Check duplicate name
        if (repo.findByConfigName(config.getConfigName().trim()).isPresent())
            return ResponseEntity.badRequest()
                    .body(Map.of("error","Config name '" + config.getConfigName()
                            + "' already exists."));

        config.setConfigName(config.getConfigName().trim());
        config.setExportMode(config.getExportMode().toUpperCase());
        config.setCreatedBy(user);
        config.setCreatedAt(Instant.now());
        config.setUpdatedAt(Instant.now());

        Neo4jExportConfig saved = repo.save(config);
        boolean hasVariants = (saved.getFullCimTypes() != null && !saved.getFullCimTypes().isEmpty())
                || (saved.getSanitisedCimTypes() != null && !saved.getSanitisedCimTypes().isEmpty())
                || (saved.getRationalisedCimTypes() != null && !saved.getRationalisedCimTypes().isEmpty());

        return ResponseEntity.ok(Map.of(
            "message",   "Export config created.",
            "config",    saved,
            "variants",  Map.of(
                "full_v0",      saved.getFullCimTypes() != null ? saved.getFullCimTypes().size() + " types" : "0 types",
                "sanitised_v1", saved.getSanitisedCimTypes() != null ? saved.getSanitisedCimTypes().size() + " types" : "0 types",
                "rationalised_v2", saved.getRationalisedCimTypes() != null ? saved.getRationalisedCimTypes().size() + " types" : "0 types"
            ),
            "note", saved.isAutoExport()
                ? "Will trigger " + (hasVariants ? "all configured variants" : "SANITISED variant")
                  + " automatically after each " + (saved.getOrgId() != null && !saved.getOrgId().isBlank()
                      ? saved.getOrgId() : "any org") + " import."
                : "On-demand only. Use POST /api/admin/neo4j/export to trigger."
        ));
    }

    // ── READ ALL ─────────────────────────────────────────────────────────

    /**
     * GET /api/admin/neo4j/configs
     * List all configs. Optional filter: ?orgId=CAISO&active=true
     */
    @GetMapping
    public ResponseEntity<?> listAll(
            @RequestParam(required=false) String orgId,
            @RequestParam(required=false) Boolean active,
            @RequestParam(required=false) Boolean autoExport) {

        List<Neo4jExportConfig> configs;

        if (active != null && active) {
            configs = repo.findByActiveTrue();
        } else {
            configs = repo.findAll();
        }

        // Apply optional filters
        if (orgId != null && !orgId.isBlank()) {
            String o = orgId.trim();
            configs = new ArrayList<>(configs);
            configs.removeIf(c -> c.getOrgId() != null
                    && !c.getOrgId().isBlank()
                    && !c.getOrgId().equals(o));
        }
        if (autoExport != null) {
            boolean ae = autoExport;
            configs = new ArrayList<>(configs);
            configs.removeIf(c -> c.isAutoExport() != ae);
        }

        return ResponseEntity.ok(Map.of(
            "total",       configs.size(),
            "configs",     configs,
            "autoExport",  configs.stream().filter(Neo4jExportConfig::isAutoExport).count(),
            "active",      configs.stream().filter(Neo4jExportConfig::isActive).count()
        ));
    }

    /** GET /api/admin/neo4j/configs/active */
    @ApiOperation(value = "List active export configs")
    @GetMapping("/active")
    public ResponseEntity<?> listActive(
            @RequestParam(required=false) String orgId) {
        List<Neo4jExportConfig> configs = orgId != null && !orgId.isBlank()
                ? repo.findByOrgIdAndActiveTrue(orgId.trim())
                : repo.findByActiveTrue();
        return ResponseEntity.ok(Map.of(
            "total",   configs.size(),
            "orgId",   orgId != null ? orgId : "ALL",
            "configs", configs));
    }

    /**
     * GET /api/admin/neo4j/configs/auto-export
     * Returns auto-export configs. Filter by orgId to see what will
     * trigger for a specific organisation's import.
     *
     * Add ?orgId=CAISO to see which configs fire after a CAISO import.
     */
    @ApiOperation(value = "List configs with autoExport enabled")
    @GetMapping("/auto-export")
    public ResponseEntity<?> listAutoExport(
            @RequestParam(required=false) String orgId) {
        List<Neo4jExportConfig> configs;
        if (orgId != null && !orgId.isBlank()) {
            // Same logic as triggerAutoExport: org-specific + global
            List<Neo4jExportConfig> specific =
                    repo.findByOrgIdAndAutoExportTrueAndActiveTrue(orgId.trim());
            List<Neo4jExportConfig> global =
                    repo.findByAutoExportTrueAndActiveTrue().stream()
                    .filter(c -> c.getOrgId() == null || c.getOrgId().isBlank())
                    .collect(java.util.stream.Collectors.toList());
            configs = new java.util.ArrayList<>(specific);
            global.stream().filter(g -> specific.stream()
                    .noneMatch(s -> s.getId().equals(g.getId())))
                    .forEach(configs::add);
        } else {
            configs = repo.findByAutoExportTrueAndActiveTrue();
        }

        // Summary of what each config will export
        List<Map<String,Object>> summaries = new java.util.ArrayList<>();
        for (Neo4jExportConfig cfg : configs) {
            Map<String,Object> s = new java.util.LinkedHashMap<>();
            s.put("id",           cfg.getId());
            s.put("configName",   cfg.getConfigName());
            s.put("orgId",        cfg.getOrgId() != null ? cfg.getOrgId() : "ALL orgs");
            s.put("clearFirst",   cfg.isClearFirst());
            // Show which variants are configured
            Map<String,Object> variants = new java.util.LinkedHashMap<>();
            variants.put("full_v0",      cfg.getFullCimTypes() != null && !cfg.getFullCimTypes().isEmpty()
                    ? cfg.getFullCimTypes().size() + " types → {version}-0" : "not configured");
            variants.put("sanitised_v1", cfg.getSanitisedCimTypes() != null && !cfg.getSanitisedCimTypes().isEmpty()
                    ? cfg.getSanitisedCimTypes().size() + " types → {version}-1" : "not configured");
            variants.put("rationalised_v2", cfg.getRationalisedCimTypes() != null && !cfg.getRationalisedCimTypes().isEmpty()
                    ? cfg.getRationalisedCimTypes().size() + " types → {version}-2" : "not configured");
            s.put("variants", variants);
            summaries.add(s);
        }

        return ResponseEntity.ok(Map.of(
            "total",    configs.size(),
            "orgId",    orgId != null ? orgId : "ALL",
            "note",     "These configs trigger automatically after import for orgId=" + (orgId != null ? orgId : "ALL"),
            "configs",  summaries
        ));
    }

    /**
     * GET /api/admin/neo4j/configs/by-org/{orgId}
     * All configs (active or not) for a specific organisation.
     */
    /**
     * GET /api/cim/admin/neo4j/configs/orgs/{orgId}/name/{configName}
     * Look up a config by org + name instead of MongoDB _id.
     * Returns the configId you need for FROM_CONFIG exports.
     */
    @ApiOperation(value = "Look up a config by org + name (returns configId for FROM_CONFIG export)", response = ExportConfigByNameResponse.class)
    @ApiResponses({@ApiResponse(code=200, message="Found", response=ExportConfigByNameResponse.class), @ApiResponse(code=404, message="Not found")})
    @GetMapping("/orgs/{orgId}/name/{configName}")
    public ResponseEntity<?> findByOrgAndName(
            @PathVariable String orgId,
            @PathVariable String configName) {
        return repo.findByConfigName(configName).map(cfg -> {
            java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
            r.put("id",              cfg.getId());
            r.put("configName",      cfg.getConfigName());
            r.put("orgId",           cfg.getOrgId());
            r.put("autoExport",      cfg.isAutoExport());
            r.put("active",          cfg.isActive());
            r.put("fullTypes",       cfg.getFullCimTypes().size() + " types");
            r.put("sanitisedTypes",  cfg.getSanitisedCimTypes().size() + " types");
            r.put("rationalisedTypes",  cfg.getRationalisedCimTypes().size() + " types");
            r.put("useForExport",    Map.of(
                "hint",        "Use 'id' as configId in POST /api/cim/admin/neo4j/export",
                "exampleBody", Map.of(
                    "mode",        "FROM_CONFIG",
                    "configId",    cfg.getId(),
                    "versionType", "SANITISED",
                    "clearFirst",  true)));
            return ResponseEntity.ok(r);
        }).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/by-org/{orgId}")
    public ResponseEntity<?> listByOrg(@PathVariable String orgId) {
        List<Neo4jExportConfig> configs = repo.findByOrgIdAndActiveTrue(orgId.trim());
        // Also include global configs (orgId blank)
        List<Neo4jExportConfig> global = repo.findByActiveTrue().stream()
                .filter(c -> c.getOrgId() == null || c.getOrgId().isBlank())
                .collect(java.util.stream.Collectors.toList());

        Map<String,Object> resp = new java.util.LinkedHashMap<>();
        resp.put("orgId",          orgId);
        resp.put("orgSpecific",    configs);
        resp.put("globalConfigs",  global);
        resp.put("totalApplicable",configs.size() + global.size());
        return ResponseEntity.ok(resp);
    }

    // ── READ ONE ─────────────────────────────────────────────────────────

    /** GET /api/admin/neo4j/configs/{id} */
    @ApiOperation(value = "Get a config by MongoDB id")
    @ApiResponses({@ApiResponse(code=200, message="OK"), @ApiResponse(code=404, message="Not found")})
    @GetMapping("/{id}")
    public ResponseEntity<?> getOne(@PathVariable String id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ── FULL UPDATE ───────────────────────────────────────────────────────

    /**
     * PUT /api/admin/neo4j/configs/{id}
     * Full replacement of the config.
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> update(
            @PathVariable String id,
            @RequestBody Neo4jExportConfig update,
            @RequestHeader(value="X-User", defaultValue="system") String user) {

        return repo.findById(id).map(existing -> {
            if (update.getConfigName() != null)
                existing.setConfigName(update.getConfigName().trim());
            if (update.getDescription() != null)
                existing.setDescription(update.getDescription());
            if (update.getOrgId() != null)
                existing.setOrgId(update.getOrgId().trim());
            if (update.getExportMode() != null)
                existing.setExportMode(update.getExportMode().toUpperCase());
            if (update.getCimTypes() != null)
                existing.setCimTypes(update.getCimTypes());
            existing.setClearFirst(update.isClearFirst());
            existing.setAutoExport(update.isAutoExport());
            existing.setActive(update.isActive());
            existing.setUpdatedAt(Instant.now());

            Neo4jExportConfig saved = repo.save(existing);
            return ResponseEntity.ok(Map.of(
                "message", "Config updated.",
                "config",  saved
            ));
        }).orElse(ResponseEntity.notFound().build());
    }

    // ── PARTIAL UPDATE ────────────────────────────────────────────────────

    /**
     * PATCH /api/admin/neo4j/configs/{id}
     * Update only provided fields.
     * Body can contain any subset of: configName, description, orgId,
     * exportMode, cimTypes, clearFirst, autoExport, active
     */
    @PatchMapping("/{id}")
    public ResponseEntity<?> patch(
            @PathVariable String id,
            @RequestBody Map<String, Object> fields) {

        return repo.findById(id).map(config -> {
            if (fields.containsKey("configName"))
                config.setConfigName(fields.get("configName").toString().trim());
            if (fields.containsKey("description"))
                config.setDescription(fields.get("description").toString());
            if (fields.containsKey("orgId"))
                config.setOrgId(fields.get("orgId").toString().trim());
            if (fields.containsKey("exportMode"))
                config.setExportMode(fields.get("exportMode").toString().toUpperCase());
            if (fields.containsKey("cimTypes")) {
                @SuppressWarnings("unchecked")
                List<String> types = (List<String>) fields.get("cimTypes");
                config.setCimTypes(types);
            }
            if (fields.containsKey("clearFirst"))
                config.setClearFirst(Boolean.parseBoolean(
                        fields.get("clearFirst").toString()));
            if (fields.containsKey("autoExport"))
                config.setAutoExport(Boolean.parseBoolean(
                        fields.get("autoExport").toString()));
            if (fields.containsKey("active"))
                config.setActive(Boolean.parseBoolean(
                        fields.get("active").toString()));

            config.setUpdatedAt(Instant.now());
            Neo4jExportConfig saved = repo.save(config);
            return ResponseEntity.ok(Map.of(
                "message",        "Config patched.",
                "config",         saved,
                "fieldsUpdated",  fields.keySet()
            ));
        }).orElse(ResponseEntity.notFound().build());
    }

    // ── DELETE ────────────────────────────────────────────────────────────

    /** DELETE /api/admin/neo4j/configs/{id} */
    @ApiOperation(value = "Delete a config")
    @ApiResponses({@ApiResponse(code=200, message="Deleted"), @ApiResponse(code=404, message="Not found")})
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable String id) {
        return repo.findById(id).map(config -> {
            repo.delete(config);
            return ResponseEntity.ok(Map.of(
                "message",    "Config deleted.",
                "configName", config.getConfigName(),
                "note",       "Existing Neo4j nodes from previous exports are NOT deleted."
            ));
        }).orElse(ResponseEntity.notFound().build());
    }

    // ── Activation shortcuts ──────────────────────────────────────────────

    /** PUT /api/admin/neo4j/configs/{id}/activate */
    @PutMapping("/{id}/activate")
    public ResponseEntity<?> activate(@PathVariable String id) {
        return setActive(id, true);
    }

    /** PUT /api/admin/neo4j/configs/{id}/deactivate */
    @PutMapping("/{id}/deactivate")
    public ResponseEntity<?> deactivate(@PathVariable String id) {
        return setActive(id, false);
    }

    /** PUT /api/admin/neo4j/configs/{id}/auto-export/enable */
    @PutMapping("/{id}/auto-export/enable")
    public ResponseEntity<?> enableAutoExport(@PathVariable String id) {
        return setAutoExport(id, true);
    }

    /** PUT /api/admin/neo4j/configs/{id}/auto-export/disable */
    @PutMapping("/{id}/auto-export/disable")
    public ResponseEntity<?> disableAutoExport(@PathVariable String id) {
        return setAutoExport(id, false);
    }

    // ── cimTypes management ───────────────────────────────────────────────

    /**
     * POST /api/admin/neo4j/configs/{id}/cimtypes
     * Add CIM types to existing list (no duplicates).
     * Body: ["ACLineSegment","Breaker"]
     */
    @PostMapping("/{id}/cimtypes")
    public ResponseEntity<?> addCimTypes(
            @PathVariable String id,
            @RequestBody List<String> typesToAdd) {
        return repo.findById(id).map(config -> {
            List<String> current = new ArrayList<>(
                    config.getCimTypes() != null ? config.getCimTypes() : new ArrayList<>());
            int added = 0;
            for (String t : typesToAdd) {
                if (t != null && !t.isBlank() && !current.contains(t.trim())) {
                    current.add(t.trim());
                    added++;
                }
            }
            config.setCimTypes(current);
            config.setUpdatedAt(Instant.now());
            Neo4jExportConfig saved = repo.save(config);
            return ResponseEntity.ok(Map.of(
                "message",     added + " type(s) added.",
                "totalTypes",  saved.getCimTypes().size(),
                "cimTypes",    saved.getCimTypes()
            ));
        }).orElse(ResponseEntity.notFound().build());
    }

    /**
     * DELETE /api/admin/neo4j/configs/{id}/cimtypes
     * Remove CIM types from existing list.
     * Body: ["ACLineSegment"]
     */
    @DeleteMapping("/{id}/cimtypes")
    public ResponseEntity<?> removeCimTypes(
            @PathVariable String id,
            @RequestBody List<String> typesToRemove) {
        return repo.findById(id).map(config -> {
            List<String> current = new ArrayList<>(
                    config.getCimTypes() != null ? config.getCimTypes() : new ArrayList<>());
            current.removeAll(typesToRemove);
            config.setCimTypes(current);
            config.setUpdatedAt(Instant.now());
            Neo4jExportConfig saved = repo.save(config);
            return ResponseEntity.ok(Map.of(
                "message",    "Types removed.",
                "totalTypes", saved.getCimTypes().size(),
                "cimTypes",   saved.getCimTypes()
            ));
        }).orElse(ResponseEntity.notFound().build());
    }

    /** GET /api/admin/neo4j/configs/{id}/cimtypes — list types in config */
    @GetMapping("/{id}/cimtypes")
    public ResponseEntity<?> getCimTypes(@PathVariable String id) {
        return repo.findById(id).map(config -> ResponseEntity.ok(Map.of(
            "configName", config.getConfigName(),
            "exportMode", config.getExportMode(),
            "totalTypes", config.getCimTypes() != null ? config.getCimTypes().size() : 0,
            "cimTypes",   config.getCimTypes() != null ? config.getCimTypes() : List.of()
        ))).orElse(ResponseEntity.notFound().build());
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private ResponseEntity<?> setActive(String id, boolean active) {
        return repo.findById(id).map(config -> {
            config.setActive(active);
            config.setUpdatedAt(Instant.now());
            repo.save(config);
            return ResponseEntity.ok(Map.of(
                "message",    "Config " + (active ? "activated" : "deactivated") + ".",
                "configName", config.getConfigName(),
                "active",     active
            ));
        }).orElse(ResponseEntity.notFound().build());
    }

    private ResponseEntity<?> setAutoExport(String id, boolean autoExport) {
        return repo.findById(id).map(config -> {
            config.setAutoExport(autoExport);
            config.setUpdatedAt(Instant.now());
            repo.save(config);
            return ResponseEntity.ok(Map.of(
                "message",    "Auto-export " + (autoExport ? "enabled" : "disabled") + ".",
                "configName", config.getConfigName(),
                "autoExport", autoExport,
                "note", autoExport
                    ? "Export will trigger automatically after next import."
                    : "Export is now on-demand only."
            ));
        }).orElse(ResponseEntity.notFound().build());
    }
}
