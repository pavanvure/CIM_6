package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Phase 3 post-import enrichment for cim_objects.
 *
 * CONFIRMED KEY FORMATS (from MongoDB data inspection):
 *
 *   resolvedRefIds → uses RAW dots (no MapKeySanitizer encoding):
 *     "ConductingEquipment.BaseVoltage"              → BaseVoltage rdfId
 *     "Terminal.ConductingEquipment"                 → Equipment rdfId
 *     "Terminal.ConnectivityNode"                    → ConnectivityNode rdfId
 *     "ConnectivityNode.ConnectivityNodeContainer"   → VoltageLevel rdfId
 *     "VoltageLevel.Substation"                      → Substation rdfId
 *     "Substation.Region"                            → SubGeographicalRegion rdfId
 *     "SubGeographicalRegion.Region"                 → GeographicalRegion rdfId
 *
 *   attributes → uses ENCODED fullwidth dots (MapKeySanitizer.encode()):
 *     "BaseVoltage.nominalVoltage" → numeric value
 *     "IdentifiedObject.name"      → string value
 *
 *   nominalVoltage is stored as a NUMBER (Double) in MongoDB, not a String.
 *   Safely converted via safeString() helper.
 *
 * ORGANISATION GATE:
 *   Currently CAISO only. Add to ENRICHMENT_ENABLED_ORGS to enable others.
 */
@Service
public class CimEnrichmentService {

    private static final Logger log = LoggerFactory.getLogger(CimEnrichmentService.class);

    /**
     * ORGANISATION GATE — add org IDs here to enable Phase 3 enrichment.
     * Case-insensitive. Nothing else needs to change when adding a new org.
     */
    private static final Set<String> ENRICHMENT_ENABLED_ORGS =
            new HashSet<>(Arrays.asList(
                "CAISO"
                // "ERCOT",
                // "SPC",
                // "MILSOFT"
            ));

    // ── resolvedRefIds keys — RAW dots, NO encoding ───────────────────────
    private static final String REF_CE_BASEVOLTAGE   = "ConductingEquipment.BaseVoltage";
    private static final String REF_T_EQUIP          = "Terminal.ConductingEquipment";
    private static final String REF_T_CN             = "Terminal.ConnectivityNode";
    private static final String REF_CN_CONTAINER     = "ConnectivityNode.ConnectivityNodeContainer";
    private static final String REF_VL_SUBSTATION    = "VoltageLevel.Substation";
    private static final String REF_SUB_REGION       = "Substation.Region";
    private static final String REF_SGR_REGION       = "SubGeographicalRegion.Region";

    // ── attributes keys — RAW dots (confirmed: your MongoDB uses raw dots in both maps)
    private static final String ATTR_NOMINAL_VOLTAGE = "BaseVoltage.nominalVoltage";
    private static final String ATTR_ID_NAME         = "IdentifiedObject.name";

    private static final int PAGE_SIZE   = 500;
    private static final int WRITE_BATCH = 200;

    private final MongoTemplate mongo;

    public CimEnrichmentService(MongoTemplate mongo) {
        this.mongo = mongo;
    }

    // ── Public entry point ────────────────────────────────────────────────

    public boolean enrich(String jobId, String orgId) {
        if (!isEnrichmentEnabled(orgId)) {
            log.info("CimEnrichment skipped for org={} (not in ENRICHMENT_ENABLED_ORGS)", orgId);
            return false;
        }

        long start = System.currentTimeMillis();
        log.info("CimEnrichment Phase 3 starting: job={} org={}", jobId, orgId);

        // Build lookup maps
        Map<String, String>       bvMap            = buildBaseVoltageMap(jobId);
        Map<String, List<String>> terminalsByEquip = buildTerminalsByEquipMap(jobId);
        Map<String, String>       cnByTerminal     = buildCnByTerminalMap(jobId);
        Map<String, String>       vlByCn           = buildVlByCnMap(jobId);
        Map<String, SubInfo>      subByVl          = buildSubByVlMap(jobId);
        enrichSubInfoWithRegions(jobId, subByVl);

        log.info("CimEnrichment maps: bv={} termsByEquip={} cnByT={} vlByCn={} subByVl={}",
                bvMap.size(), terminalsByEquip.size(),
                cnByTerminal.size(), vlByCn.size(), subByVl.size());

        long voltageCount = 0, substationCount = 0;
        String lastId = null;

        while (true) {
            List<CimObjectRecord> page = fetchPage(jobId, lastId);
            if (page.isEmpty()) break;
            lastId = page.get(page.size() - 1).getId();

            List<Map<String, Object>> updates = new ArrayList<>();
            for (CimObjectRecord rec : page) {
                Map<String, String> enriched = new LinkedHashMap<>();
                computeNominalVoltage(rec, bvMap, enriched);
                computeSubstationsAndRegions(rec, terminalsByEquip,
                        cnByTerminal, vlByCn, subByVl, enriched);
                if (!enriched.isEmpty()) {
                    if (enriched.containsKey("nominalVoltage_1")) voltageCount++;
                    if (enriched.containsKey("substationMrid_1")) substationCount++;
                    Map<String, Object> upd = new LinkedHashMap<>();
                    upd.put("id",      rec.getId());
                    upd.put("enriched", enriched);
                    updates.add(upd);
                }
            }
            for (int from = 0; from < updates.size(); from += WRITE_BATCH)
                bulkWrite(updates.subList(from,
                        Math.min(from + WRITE_BATCH, updates.size())));
        }

        log.info("CimEnrichment done: job={} org={} time={} nominalVoltage={} substation={}",
                jobId, orgId,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start),
                voltageCount, substationCount);
        return true;
    }

    private boolean isEnrichmentEnabled(String orgId) {
        if (orgId == null) return false;
        return ENRICHMENT_ENABLED_ORGS.stream()
                .anyMatch(o -> o.equalsIgnoreCase(orgId.trim()));
    }

    // ── Lookup map builders ───────────────────────────────────────────────

    /**
     * BaseVoltage.rdfId → nominalVoltage string.
     * Note: nominalVoltage stored as Number in MongoDB — converted via safeString().
     */
    private Map<String, String> buildBaseVoltageMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("BaseVoltage"), lastId);
            q.fields().include("rdfId").include("attributes");
            List<CimObjectRecord> batch =
                    mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getAttributes() == null) continue;
                Object val = r.getAttributes().get(ATTR_NOMINAL_VOLTAGE);
                String str = safeString(val);
                if (str != null) map.put(r.getRdfId(), str);
            }
        }
        log.info("buildBaseVoltageMap: {} BaseVoltage entries with nominalVoltage", map.size());
        return map;
    }

    /**
     * equipment.rdfId → List of Terminal rdfIds pointing to it.
     * resolvedRefIds key: "Terminal.ConductingEquipment" (raw dot).
     */
    private Map<String, List<String>> buildTerminalsByEquipMap(String jobId) {
        Map<String, List<String>> map = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("Terminal"), lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch =
                    mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String equipRdfId = r.getResolvedRefIds().get(REF_T_EQUIP);
                if (equipRdfId == null || equipRdfId.isBlank()) continue;
                map.computeIfAbsent(equipRdfId, k -> new ArrayList<>())
                   .add(r.getRdfId());
            }
        }
        log.info("buildTerminalsByEquipMap: {} equipment entries have Terminals", map.size());
        return map;
    }

    /**
     * Terminal.rdfId → ConnectivityNode.rdfId.
     * resolvedRefIds key: "Terminal.ConnectivityNode" (raw dot).
     */
    private Map<String, String> buildCnByTerminalMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("Terminal"), lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch =
                    mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String cnRdfId = r.getResolvedRefIds().get(REF_T_CN);
                if (cnRdfId != null && !cnRdfId.isBlank())
                    map.put(r.getRdfId(), cnRdfId);
            }
        }
        log.info("buildCnByTerminalMap: {} Terminal→ConnectivityNode entries", map.size());
        return map;
    }

    /**
     * ConnectivityNode.rdfId → VoltageLevel.rdfId.
     * resolvedRefIds key: "ConnectivityNode.ConnectivityNodeContainer" (raw dot).
     */
    private Map<String, String> buildVlByCnMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("ConnectivityNode"), lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch =
                    mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String vlRdfId = r.getResolvedRefIds().get(REF_CN_CONTAINER);
                if (vlRdfId != null && !vlRdfId.isBlank())
                    map.put(r.getRdfId(), vlRdfId);
            }
        }
        log.info("buildVlByCnMap: {} ConnectivityNode→VoltageLevel entries", map.size());
        return map;
    }

    /**
     * VoltageLevel.rdfId → SubInfo (substation rdfId, mrid, name).
     * resolvedRefIds key: "VoltageLevel.Substation" (confirmed from data).
     */
    private Map<String, SubInfo> buildSubByVlMap(String jobId) {
        // Step A: VL.rdfId → Substation.rdfId
        Map<String, String> subRdfByVl = new HashMap<>();
        String lastId = null;
        while (true) {
            Query q = pageQuery(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("VoltageLevel"), lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch =
                    mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String subRdfId = r.getResolvedRefIds().get(REF_VL_SUBSTATION);
                if (subRdfId != null && !subRdfId.isBlank())
                    subRdfByVl.put(r.getRdfId(), subRdfId);
            }
        }
        if (subRdfByVl.isEmpty()) return new HashMap<>();

        // Step B: fetch Substation mrid + name
        Set<String> subRdfIds = new HashSet<>(subRdfByVl.values());
        Map<String, SubInfo> subInfoByRdfId = new HashMap<>();
        Query subQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("Substation")
                .and("rdfId").in(subRdfIds));
        subQ.fields().include("rdfId").include("mrid").include("attributes");
        for (CimObjectRecord r : mongo.find(subQ, CimObjectRecord.class, "cim_objects")) {
            if (r.getRdfId() == null) continue;
            String name = r.getAttributes() != null
                    ? safeString(r.getAttributes().get(ATTR_ID_NAME)) : null;
            subInfoByRdfId.put(r.getRdfId(),
                    new SubInfo(r.getRdfId(), r.getMrid(), name));
        }

        // Step C: compose vlRdfId → SubInfo
        Map<String, SubInfo> result = new HashMap<>();
        for (Map.Entry<String, String> e : subRdfByVl.entrySet()) {
            SubInfo si = subInfoByRdfId.get(e.getValue());
            if (si != null) result.put(e.getKey(), si);
        }
        log.info("buildSubByVlMap: {} VoltageLevel→Substation entries", result.size());
        return result;
    }

    /**
     * Enriches SubInfo objects with SGR and GR mrid + name.
     * Substation.Region → SGR; SubGeographicalRegion.Region → GR.
     * All resolvedRefIds keys confirmed from your MongoDB data.
     */
    private void enrichSubInfoWithRegions(String jobId,
                                           Map<String, SubInfo> subByVl) {
        if (subByVl.isEmpty()) return;

        // Collect unique substation rdfIds
        Set<String> subRdfIds = new HashSet<>();
        for (SubInfo si : subByVl.values())
            if (si.rdfId != null) subRdfIds.add(si.rdfId);
        if (subRdfIds.isEmpty()) return;

        // Substation → SGR rdfId via "Substation.Region"
        Map<String, String> sgrRdfBySubRdf = new HashMap<>();
        Query subQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("Substation").and("rdfId").in(subRdfIds));
        subQ.fields().include("rdfId").include("resolvedRefIds");
        for (CimObjectRecord r : mongo.find(subQ, CimObjectRecord.class, "cim_objects")) {
            if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
            String sgrRdfId = r.getResolvedRefIds().get(REF_SUB_REGION);
            if (sgrRdfId != null && !sgrRdfId.isBlank())
                sgrRdfBySubRdf.put(r.getRdfId(), sgrRdfId);
        }

        Set<String> sgrRdfIds = new HashSet<>(sgrRdfBySubRdf.values());
        if (sgrRdfIds.isEmpty()) return;

        // SGR → mrid, name, GR rdfId via "SubGeographicalRegion.Region"
        Map<String, String[]> sgrInfoByRdf = new HashMap<>();
        Query sgrQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("SubGeographicalRegion")
                .and("rdfId").in(sgrRdfIds));
        sgrQ.fields().include("rdfId").include("mrid")
                     .include("attributes").include("resolvedRefIds");
        for (CimObjectRecord r : mongo.find(sgrQ, CimObjectRecord.class, "cim_objects")) {
            if (r.getRdfId() == null) continue;
            String name    = r.getAttributes() != null
                    ? safeString(r.getAttributes().get(ATTR_ID_NAME)) : null;
            String grRdfId = r.getResolvedRefIds() != null
                    ? r.getResolvedRefIds().get(REF_SGR_REGION) : null;
            sgrInfoByRdf.put(r.getRdfId(),
                    new String[]{r.getMrid(), name, grRdfId});
        }

        // GR → mrid, name
        Set<String> grRdfIds = new HashSet<>();
        for (String[] v : sgrInfoByRdf.values())
            if (v[2] != null && !v[2].isBlank()) grRdfIds.add(v[2]);

        Map<String, String[]> grInfoByRdf = new HashMap<>();
        if (!grRdfIds.isEmpty()) {
            Query grQ = new Query(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("GeographicalRegion")
                    .and("rdfId").in(grRdfIds));
            grQ.fields().include("rdfId").include("mrid").include("attributes");
            for (CimObjectRecord r : mongo.find(grQ, CimObjectRecord.class, "cim_objects")) {
                if (r.getRdfId() == null) continue;
                String name = r.getAttributes() != null
                        ? safeString(r.getAttributes().get(ATTR_ID_NAME)) : null;
                grInfoByRdf.put(r.getRdfId(), new String[]{r.getMrid(), name});
            }
        }

        // Attach SGR + GR to each SubInfo
        for (SubInfo si : subByVl.values()) {
            if (si.rdfId == null) continue;
            String sgrRdfId = sgrRdfBySubRdf.get(si.rdfId);
            if (sgrRdfId == null) continue;
            String[] sgrInfo = sgrInfoByRdf.get(sgrRdfId);
            if (sgrInfo == null) continue;
            si.sgrMrid = sgrInfo[0];
            si.sgrName = sgrInfo[1];
            if (sgrInfo[2] != null) {
                String[] grInfo = grInfoByRdf.get(sgrInfo[2]);
                if (grInfo != null) {
                    si.grMrid = grInfo[0];
                    si.grName = grInfo[1];
                }
            }
        }
        long withSgr = subByVl.values().stream().filter(s -> s.sgrMrid != null).count();
        long withGr  = subByVl.values().stream().filter(s -> s.grMrid  != null).count();
        log.info("enrichSubInfoWithRegions: {}/{} substations have SGR, {}/{} have GR",
                withSgr, subByVl.size(), withGr, subByVl.size());
    }

    // ── Per-object computation ─────────────────────────────────────────────

    private void computeNominalVoltage(CimObjectRecord rec,
                                        Map<String, String> bvMap,
                                        Map<String, String> enriched) {
        if (rec.getResolvedRefIds() == null) return;
        // resolvedRefIds key uses RAW dot — no encoding
        String bvRdfId = rec.getResolvedRefIds().get(REF_CE_BASEVOLTAGE);
        if (bvRdfId == null || bvRdfId.isBlank()) return;
        String voltage = bvMap.get(bvRdfId);
        if (voltage == null || voltage.isBlank()) return;
        // Write key uses encoded fullwidth dot for attributes map
        enriched.put("nominalVoltage_1", voltage);
    }

    private void computeSubstationsAndRegions(CimObjectRecord rec,
                                               Map<String, List<String>> terminalsByEquip,
                                               Map<String, String> cnByTerminal,
                                               Map<String, String> vlByCn,
                                               Map<String, SubInfo> subByVl,
                                               Map<String, String> enriched) {
        if (rec.getRdfId() == null) return;
        List<String> terminals = terminalsByEquip.get(rec.getRdfId());
        if (terminals == null || terminals.isEmpty()) return;

        // Walk each Terminal → CN → VL → SubInfo, collect distinct substations
        LinkedHashMap<String, SubInfo> found = new LinkedHashMap<>();
        for (String tRdfId : terminals) {
            String cnRdfId = cnByTerminal.get(tRdfId);
            if (cnRdfId == null) continue;
            String vlRdfId = vlByCn.get(cnRdfId);
            if (vlRdfId == null) continue;
            SubInfo sub = subByVl.get(vlRdfId);
            if (sub == null) continue;
            String dedupKey = sub.mrid != null ? sub.mrid : sub.rdfId;
            if (dedupKey != null) found.put(dedupKey, sub);
        }
        if (found.isEmpty()) return;


        // ── Write substation properties (one per distinct substation) ──────
        int subIdx = 1;
        // Build deduplicated SGR and GR maps (by mrid) across all substations.
        // A tie-line's two substations may share the same SGR/GR — store once.
        Map<String, String> sgrNameByMrid = new LinkedHashMap<>();
        Map<String, String> grNameByMrid  = new LinkedHashMap<>();

        for (SubInfo sub : found.values()) {
            // Substation — one entry per substation (no dedup, they are distinct)
            if (sub.mrid != null && !sub.mrid.isBlank())
                enriched.put("substationMrid_" + subIdx, sub.mrid);
            if (sub.name != null && !sub.name.isBlank())
                enriched.put("substationName_" + subIdx, sub.name);
            // Collect SGR + GR for deduplication
            if (sub.sgrMrid != null && !sub.sgrMrid.isBlank())
                sgrNameByMrid.putIfAbsent(sub.sgrMrid, sub.sgrName);
            if (sub.grMrid != null && !sub.grMrid.isBlank())
                grNameByMrid.putIfAbsent(sub.grMrid, sub.grName);
            subIdx++;
        }

        // SGR — deduplicated (same SGR for both ends of a tie-line → written once)
        int sgrIdx = 1;
        for (Map.Entry<String, String> e : sgrNameByMrid.entrySet()) {
            enriched.put("subGeographicalRegionMrid_" + sgrIdx, e.getKey());
            if (e.getValue() != null && !e.getValue().isBlank())
                enriched.put("subGeographicalRegionName_" + sgrIdx, e.getValue());
            sgrIdx++;
        }

        // GR — deduplicated
        int grIdx = 1;
        for (Map.Entry<String, String> e : grNameByMrid.entrySet()) {
            enriched.put("geographicalRegionMrid_" + grIdx, e.getKey());
            if (e.getValue() != null && !e.getValue().isBlank())
                enriched.put("geographicalRegionName_" + grIdx, e.getValue());
            grIdx++;
        }

    }

    // ── Write ──────────────────────────────────────────────────────────────

    /**
     * Writes enriched attributes to cim_objects.
     * raw_objects intentionally NOT touched.
     */
    private void bulkWrite(List<Map<String, Object>> updates) {
        for (Map<String, Object> upd : updates) {
            String id = (String) upd.get("id");
            @SuppressWarnings("unchecked")
            Map<String, String> enriched = (Map<String, String>) upd.get("enriched");
            if (enriched == null || enriched.isEmpty()) continue;
            Update update = new Update();
            for (Map.Entry<String, String> e : enriched.entrySet()) {
                update.set("attributes." + e.getKey(), e.getValue());
            }
            try {
                mongo.updateFirst(
                    new Query(Criteria.where("_id").is(
                            new org.bson.types.ObjectId(id))),
                    update, "cim_objects");
            } catch (Exception ex) {
                log.warn("bulkWrite error id={}: {}", id, ex.getMessage());
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<CimObjectRecord> fetchPage(String jobId, String lastId) {
        Criteria c = Criteria.where("jobId").is(jobId);
        if (lastId != null)
            c = new Criteria().andOperator(c,
                    Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));
        Query q = new Query(c).limit(PAGE_SIZE)
                .with(Sort.by(Sort.Direction.ASC, "_id"));
        q.fields().include("rdfId").include("cimType")
                  .include("resolvedRefIds").include("mrid");
        return mongo.find(q, CimObjectRecord.class, "cim_objects");
    }

    private Query pageQuery(Criteria base, String lastId) {
        Criteria c = lastId == null ? base :
                new Criteria().andOperator(base,
                        Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));
        return new Query(c).limit(PAGE_SIZE)
                .with(Sort.by(Sort.Direction.ASC, "_id"));
    }

    /**
     * Safely converts any MongoDB value (String, Double, Integer, Boolean)
     * to String. Returns null if value is null or blank.
     */
    private String safeString(Object val) {
        if (val == null) return null;
        String s = val.toString().trim();
        return s.isBlank() ? null : s;
    }

    // ── Inner class ────────────────────────────────────────────────────────

    private static class SubInfo {
        final String rdfId;
        final String mrid;
        final String name;
        String sgrMrid; String sgrName;
        String grMrid;  String grName;

        SubInfo(String rdfId, String mrid, String name) {
            this.rdfId = rdfId;
            this.mrid  = mrid;
            this.name  = name;
        }
    }
}
