package com.cim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class CIMPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(CIMPlatformApplication.class, args);
    }
}
