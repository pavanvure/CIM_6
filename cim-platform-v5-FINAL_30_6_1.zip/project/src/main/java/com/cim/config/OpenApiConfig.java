package com.cim.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.oas.annotations.EnableOpenApi;

/**
 * Springfox 3.0.0 configuration — replaces the previous springdoc-based
 * config. Springfox uses javax.* (not jakarta.*), so this project is
 * pinned to Spring Boot 2.7.3 to support it.
 *
 * Live endpoints once the app is running:
 *   Swagger UI:    http://localhost:8080/swagger-ui/index.html
 *   OpenAPI JSON:  http://localhost:8080/v3/api-docs   (springfox-boot-starter
 *                  exposes OAS3 JSON at this path when @EnableOpenApi is used)
 *
 * Auto-generates the spec from existing @RestController/@GetMapping/
 * @PostMapping annotations — never drifts out of sync with controller code.
 */
@Configuration
@EnableOpenApi
public class OpenApiConfig {

    @Bean
    public Docket cimPlatformApi() {
        return new Docket(DocumentationType.OAS_30)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.cim.controller"))
                .paths(PathSelectors.any())
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("CIM Network Data Import Platform API")
                .description(
                    "Imports IEC 61970/61968 CIM power system files (RDF/XML, " +
                    "JSON-LD, Milsoft CSV), validates against the CIM OWL " +
                    "hierarchy, stores results in MongoDB (raw_objects + " +
                    "cim_objects), and exports topology graphs to Neo4j with " +
                    "four version variants: FULL, SANITISED, RATIONALISED, CUSTOM.")
                .version("v5")
                .contact(new Contact("CIM Platform Team", "", "cim-platform@oati.com"))
                .license("Internal Use Only")
                .build();
    }
}
