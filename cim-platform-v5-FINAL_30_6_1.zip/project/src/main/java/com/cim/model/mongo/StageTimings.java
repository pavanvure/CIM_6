package com.cim.model.mongo;

/**
 * Per-stage processing times stored on ValidationJob.
 * REQ #7: Human-readable format alongside milliseconds.
 */
public class StageTimings {

    private Long   parseMs;
    private String parseFormatted;

    private Long   referenceMs;
    private String referenceFormatted;

    private Long   neo4jExportMs;
    private String neo4jExportFormatted;

    private Long   totalMs;
    private String totalFormatted;

    public StageTimings() {}

    // ── Setters that auto-compute formatted string ────────────────────────

    public void setParseMs(Long ms) {
        this.parseMs        = ms;
        this.parseFormatted = ms != null ? format(ms) : null;
    }

    public void setReferenceMs(Long ms) {
        this.referenceMs        = ms;
        this.referenceFormatted = ms != null ? format(ms) : null;
    }

    public void setNeo4jExportMs(Long ms) {
        this.neo4jExportMs        = ms;
        this.neo4jExportFormatted = ms != null ? format(ms) : null;
    }

    public void setTotalMs(Long ms) {
        this.totalMs        = ms;
        this.totalFormatted = ms != null ? format(ms) : null;
    }

    // ── Getters ───────────────────────────────────────────────────────────

    public Long   getParseMs()              { return parseMs; }
    public String getParseFormatted()       { return parseFormatted; }
    public Long   getReferenceMs()          { return referenceMs; }
    public String getReferenceFormatted()   { return referenceFormatted; }
    public Long   getNeo4jExportMs()        { return neo4jExportMs; }
    public String getNeo4jExportFormatted() { return neo4jExportFormatted; }
    public Long   getTotalMs()              { return totalMs; }
    public String getTotalFormatted()       { return totalFormatted; }

    /**
     * REQ #7 — Format milliseconds to human readable string.
     * Examples:
     *   673000  → "11m 13s"
     *   45000   → "45s"
     *   90000   → "1m 30s"
     *   3661000 → "1h 1m 1s"
     */
    public static String format(long ms) {
        if (ms < 0) return "n/a";
        long totalSec = ms / 1000;
        long hours    = totalSec / 3600;
        long mins     = (totalSec % 3600) / 60;
        long secs     = totalSec % 60;

        if (hours > 0) return hours + "h " + mins + "m " + secs + "s";
        if (mins  > 0) return mins  + "m " + secs + "s";
        if (secs  > 0) return secs  + "s";
        return ms + "ms";
    }
}
