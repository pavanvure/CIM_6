package com.cim.controller;

import com.cim.model.mongo.ExportRequest;
import com.cim.service.RevalidationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


/**
 * Revalidation REST API — Enhancement 2
 *
 * When namespace configs change, existing cim_objects have stale attributes.
 * These endpoints trigger re-processing of raw_objects → cim_objects
 * with the new namespace settings, and optionally re-export to Neo4j.
 *
 * POST /api/cim/admin/revalidate
 *   Start async revalidation for a job.
 *
 * GET /api/cim/admin/revalidate/{revalidationId}
 *   Poll revalidation status.
 */
@RestController
@RequestMapping("/api/cim/admin")
@CrossOrigin(origins = "*")
public class RevalidationController {

    private final RevalidationService revalidationService;

    public RevalidationController(RevalidationService revalidationService) {
        this.revalidationService = revalidationService;
    }

    /**
     * POST /api/cim/admin/revalidate
     *
     * Re-processes raw_objects → cim_objects with fresh namespace settings.
     * Use after enabling/disabling a namespace or changing validatePath.
     *
     * Body:
     * {
     *   "jobId":         "uuid",           required
     *   "orgId":         "CAISO",          required - determines which namespace configs apply
     *   "triggerExport": true,             optional - re-export to Neo4j after revalidation
     *   "exportRequest": {                 optional - specific export config
     *     "versionType": "SANITISED",
     *     "cimTypes":    ["ACLineSegment","Breaker","..."],
     *     "clearFirst":  true
     *   }
     * }
     *
     * Returns immediately with revalidationId.
     * Poll GET /api/cim/admin/revalidate/{id} for status.
     */
    /**
     * POST /api/cim/admin/revalidate
     * REQ 2: Uses RevalidationRequest POJO for clear Swagger UI.
     *
     * Example body:
     * {
     *   "jobId":         "5041c404-...",
     *   "orgId":         "CAISO",
     *   "triggerExport": true,
     *   "exportRequest": {
     *     "mode":       "FROM_CONFIG",
     *     "configId":   "6820f398...",
     *     "clearFirst": true
     *   }
     * }
     */
    @PostMapping("/revalidate")
    public ResponseEntity<?> startRevalidation(
            @RequestBody com.cim.model.mongo.RevalidationRequest req) {

        if (req.getJobId() == null || req.getJobId().isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "jobId is required."));
        if (req.getOrgId() == null || req.getOrgId().isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "orgId is required."));

        RevalidationService.RevalidationResult result =
                revalidationService.startRevalidation(
                        req.getJobId(), req.getOrgId(),
                        req.isTriggerExport(), req.getExportRequest());

        return ResponseEntity.accepted().body(Map.of(
            "revalidationId", result.revalidationId,
            "jobId",          req.getJobId(),
            "orgId",          req.getOrgId(),
            "triggerExport",  req.isTriggerExport(),
            "status",         "RUNNING",
            "message",        "Revalidation started for orgId=" + req.getOrgId(),
            "links", Map.of(
                "status", "/api/cim/admin/revalidate/" + result.revalidationId)
        ));
    }

    /**
     * GET /api/cim/admin/revalidate/{revalidationId}
     * Poll revalidation status.
     */
    @GetMapping("/revalidate/{revalidationId}")
    public ResponseEntity<?> getStatus(@PathVariable String revalidationId) {
        return revalidationService.getStatus(revalidationId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
