package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.RawCimObject;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.RawCimObjectRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.util.MapKeySanitizer;
import com.cim.validation.registry.CIMHierarchyRegistry;
import com.cim.validation.registry.PathValidationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Revalidation Service — Enhancement 2
 *
 * When namespace configs change (e.g. enabling caiso namespace after import),
 * previously stored cim_objects have stale/missing attributes.
 *
 * This service re-processes raw_objects → updates cim_objects with fresh
 * namespace filtering and path validation → optionally triggers Neo4j re-export.
 *
 * FLOW:
 *   PUT /admin/namespaces/{id}/enable
 *     → NamespaceController calls RevalidationService.revalidateJob(jobId, orgId)
 *
 *   RevalidationService:
 *     1. Load fresh namespace config for this org
 *     2. Iterate raw_objects in batches (cursor pagination)
 *     3. For each raw object: re-apply namespace filtering + path validation
 *     4. Update cim_objects (SET attributes, pathIssues) — upsert by jobId+rdfId
 *     5. If triggerExport=true: start Neo4j export with stored config
 */
@Service
public class RevalidationService {

    private static final Logger log = LoggerFactory.getLogger(RevalidationService.class);
    private static final int BATCH = 2000; // No parse overhead — can use larger batch than import

    private final RawCimObjectRepository     rawRepo;
    private final CimObjectRecordRepository  cimRepo;
    private final ValidationJobRepository    jobRepo;
    private final MongoTemplate              mongo;
    private final NamespaceService           namespaceService;
    private final CIMHierarchyRegistry       registry;
    private final Neo4jExportService                  neo4jExportService;
    private final com.cim.repository.Neo4jExportConfigRepository neo4jExportConfigRepo;
    private final Neo4jExportExecutor        neo4jExportExecutor;

    // Setter injection to avoid circular dependency
    // (RevalidationExecutor → RevalidationService → RevalidationExecutor)
    private RevalidationExecutor executor; // injected via setter — no circular dep

    @org.springframework.beans.factory.annotation.Autowired
    public void setExecutor(RevalidationExecutor executor) {
        this.executor = executor;
    }

    public RevalidationService(RawCimObjectRepository rawRepo,
                                CimObjectRecordRepository cimRepo,
                                ValidationJobRepository jobRepo,
                                MongoTemplate mongo,
                                NamespaceService namespaceService,
                                CIMHierarchyRegistry registry,
                                Neo4jExportService neo4jExportService,
                                Neo4jExportExecutor neo4jExportExecutor,
                                com.cim.repository.Neo4jExportConfigRepository neo4jExportConfigRepo) {
        this.rawRepo                = rawRepo;
        this.cimRepo                = cimRepo;
        this.jobRepo                = jobRepo;
        this.mongo                  = mongo;
        this.namespaceService       = namespaceService;
        this.registry               = registry;
        this.neo4jExportService     = neo4jExportService;
        this.neo4jExportExecutor    = neo4jExportExecutor;
        this.neo4jExportConfigRepo  = neo4jExportConfigRepo;
    }

    // ── Public API ────────────────────────────────────────────────────────

    /**
     * Result returned immediately to client (async processing continues).
     */
    public static class RevalidationResult {
        public final String  revalidationId;
        public final String  jobId;
        public final String  orgId;
        public final boolean triggerExport;
        public final String  status;

        public RevalidationResult(String revalidationId, String jobId,
                                   String orgId, boolean triggerExport) {
            this.revalidationId = revalidationId;
            this.jobId          = jobId;
            this.orgId          = orgId;
            this.triggerExport  = triggerExport;
            this.status         = "RUNNING";
        }
    }

    /**
     * Start async revalidation for a job.
     * Returns immediately — client polls /admin/revalidation/{id} for status.
     *
     * @param jobId         import job to revalidate
     * @param orgId         organisation (determines which namespace configs apply)
     * @param triggerExport if true, trigger Neo4j re-export after revalidation
     * @param exportRequest optional specific export config; null = use stored auto-export config
     */
    public RevalidationResult startRevalidation(String jobId, String orgId,
                                                 boolean triggerExport,
                                                 ExportRequest exportRequest) {
        String revalidationId = UUID.randomUUID().toString();
        RevalidationResult result =
                new RevalidationResult(revalidationId, jobId, orgId, triggerExport);

        // Store status in MongoDB
        org.bson.Document statusDoc = new org.bson.Document()
                .append("revalidationId", revalidationId)
                .append("jobId", jobId)
                .append("orgId", orgId)
                .append("triggerExport", triggerExport)
                .append("status", "RUNNING")
                .append("startedAt", Instant.now().toString())
                .append("objectsProcessed", 0L)
                .append("objectsUpdated", 0L);
        mongo.insert(statusDoc, "revalidation_jobs");

        // Pass lambda to executor — executor has no reference to this service.
        // Lambda captures all needed state in its closure.
        // executor.runAsync() is @Async on a separate bean → proxy intercepts
        // → runs on async thread pool → HTTP thread returns immediately.
        final String  fRevalId  = revalidationId;
        final String  fJobId    = jobId;
        final String  fOrgId    = orgId;
        final boolean fTrigger  = triggerExport;
        final com.cim.model.mongo.ExportRequest fExportReq = exportRequest;
        executor.runAsync(() -> runAsync(fRevalId, fJobId, fOrgId, fTrigger, fExportReq));
        return result;
    }

    public Optional<org.bson.Document> getStatus(String revalidationId) {
        return Optional.ofNullable(mongo.findOne(
                new Query(Criteria.where("revalidationId").is(revalidationId)),
                org.bson.Document.class, "revalidation_jobs"));
    }

    // ── Async processing ──────────────────────────────────────────────────

    // NOT @Async here — async is on RevalidationExecutor.runAsync()
    // This method does the actual work, called from the executor thread
    public CompletableFuture<Void> runAsync(String revalidationId, String jobId,
                                             String orgId, boolean triggerExport,
                                             ExportRequest exportRequest) {
        long processed = 0, updated = 0;
        try {
            log.info("Revalidation started: id={} job={} orgId={}", revalidationId, jobId, orgId);

            // Load fresh namespace config for this org
            namespaceService.loadForJob(revalidationId, orgId);

            // Cursor pagination through raw_objects
            String lastId = null;
            while (true) {
                Criteria criteria = Criteria.where("jobId").is(jobId);
                if (lastId != null)
                    criteria = new Criteria().andOperator(criteria,
                            Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));

                List<RawCimObject> batch = mongo.find(
                        new Query(criteria)
                                .limit(BATCH)
                                .with(org.springframework.data.domain.Sort.by(
                                        org.springframework.data.domain.Sort.Direction.ASC, "_id")),
                        RawCimObject.class, "raw_objects");

                if (batch.isEmpty()) break;

                List<RevalidationUpdate> updates = new ArrayList<>();
                for (RawCimObject raw : batch) {
                    updates.add(reprocessObject(raw, revalidationId, orgId));
                    processed++;
                    lastId = raw.getId();
                }
                updated += updates.size();

                // Bulk upsert — only writes attributes + pathIssues, no reads
                if (!updates.isEmpty()) bulkUpsert(updates, jobId);

                // Update progress
                if (processed % 5000 == 0) {
                    updateStatus(revalidationId, "RUNNING", processed, updated, null);
                    log.info("Revalidation progress: id={} processed={} updated={}",
                            revalidationId, processed, updated);
                }
            }

            namespaceService.clearAfterJob(revalidationId);

            // Mark done
            updateStatus(revalidationId, "DONE", processed, updated, null);
            log.info("Revalidation DONE: id={} processed={} updated={}", revalidationId, processed, updated);

            // Enhancement 2: trigger Neo4j export if requested
            if (triggerExport) {
                triggerNeo4jExport(jobId, orgId, exportRequest);
            }

        } catch (Exception e) {
            log.error("Revalidation FAILED: id={} error={}", revalidationId, e.getMessage(), e);
            namespaceService.clearAfterJob(revalidationId);
            updateStatus(revalidationId, "FAILED", processed, updated, e.getMessage());
        }
        return CompletableFuture.completedFuture(null);
    }

    // ── Re-process single object ──────────────────────────────────────────

    /**
     * Re-applies namespace filtering + path validation to a raw object.
     *
     * PERFORMANCE: Does NOT query cim_objects for existing record.
     *   Namespace changes only affect: attributes + pathIssues.
     *   Other fields (category, isRequired, mrid, name) are set at
     *   import time and unchanged by namespace updates.
     *   The bulkUpsert only SETs attributes + pathIssues — existing
     *   fields are preserved automatically by MongoDB $set.
     *
     *   Result: 0 MongoDB reads per object = orders of magnitude faster.
     */
    private RevalidationUpdate reprocessObject(RawCimObject raw,
                                                String jobId, String orgId) {
        Map<String, String> newAttributes = new LinkedHashMap<>();
        List<Map<String, String>> newPathIssues = new ArrayList<>();

        if (raw.getRawAttributes() != null) {
            Map<String, String> decoded = MapKeySanitizer.decodeKeys(raw.getRawAttributes());
            for (Map.Entry<String, String> e : decoded.entrySet()) {
                String tag    = e.getKey();
                String value  = e.getValue();
                String prefix = namespaceService.extractPrefix(tag);

                if (namespaceService.isEnabled(jobId, prefix)) {
                    if (value != null && !value.isBlank()) {
                        newAttributes.put(MapKeySanitizer.encode(tag), value);
                    }
                    if (namespaceService.shouldValidatePath(jobId, prefix)) {
                        PathValidationResult pvr =
                                registry.validateAttributePath(raw.getCimType(), tag);
                        if (pvr != null && pvr.isInvalid()) {
                            Map<String, String> issue = new LinkedHashMap<>();
                            issue.put("status", pvr.name());
                            issue.put("tag", tag);
                            issue.put("explanation",
                                    pvr.getExplanation(raw.getCimType(), tag));
                            newPathIssues.add(issue);
                        }
                    }
                } else {
                    Map<String, String> issue = new LinkedHashMap<>();
                    issue.put("status", "UNKNOWN_NAMESPACE");
                    issue.put("tag", tag);
                    issue.put("explanation",
                            "Namespace '" + prefix + "' not enabled for org '" + orgId + "'.");
                    newPathIssues.add(issue);
                }
            }
        }
        return new RevalidationUpdate(raw.getJobId(), raw.getRdfId(),
                newAttributes, newPathIssues);
    }

    /** Lightweight holder for the two fields we update — no MongoDB read needed. */
    private static class RevalidationUpdate {
        final String jobId;
        final String rdfId;
        final Map<String, String> attributes;
        final List<Map<String, String>> pathIssues;

        RevalidationUpdate(String jobId, String rdfId,
                           Map<String, String> attributes,
                           List<Map<String, String>> pathIssues) {
            this.jobId      = jobId;
            this.rdfId      = rdfId;
            this.attributes = attributes;
            this.pathIssues = pathIssues;
        }
    }

    // ── Bulk upsert updated records ───────────────────────────────────────

    /**
     * Bulk upsert: update ONLY attributes + pathIssues on each cim_objects document.
     * Uses MongoDB $set — all other fields (category, isRequired, mrid, name)
     * are left untouched. No read required — pure write operation.
     *
     * One bulk operation for the entire batch = one MongoDB round trip per 2000 objects.
     */
    private void bulkUpsert(List<RevalidationUpdate> updates, String jobId) {
        org.springframework.data.mongodb.core.BulkOperations bulk =
                mongo.bulkOps(
                        org.springframework.data.mongodb.core.BulkOperations.BulkMode.UNORDERED,
                        "cim_objects");

        for (RevalidationUpdate u : updates) {
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(
                            Criteria.where("jobId").is(u.jobId)
                                    .and("rdfId").is(u.rdfId));
            org.springframework.data.mongodb.core.query.Update upd =
                    new org.springframework.data.mongodb.core.query.Update()
                            .set("attributes", u.attributes)
                            .set("pathIssues", u.pathIssues);
            // upsert=true: creates document if not found (object filtered out at import)
            bulk.upsert(q, upd);
        }

        try {
            bulk.execute();
        } catch (Exception e) {
            log.warn("Bulk upsert error: {}", e.getMessage());
        }
    }

    // ── Trigger Neo4j export after revalidation ───────────────────────────

    /**
     * Trigger Neo4j export after revalidation completes.
     *
     * If exportRequest is provided by caller (via REST body):
     *   Use it as-is. If mode=FROM_CONFIG with no versionType → all variants.
     *   If mode=FROM_CONFIG with versionType set → only that variant.
     *
     * If exportRequest is null (caller just set triggerExport=true):
     *   Look up the auto-export config for this orgId.
     *   Use FROM_CONFIG with no versionType → triggers ALL configured variants.
     *   This is the common case — revalidate + re-export everything.
     */
    private void triggerNeo4jExport(String jobId, String orgId,
                                     ExportRequest exportRequest) {
        try {
            ExportRequest req;

            if (exportRequest != null) {
                // Caller provided specific export config
                req = exportRequest;
                req.setJobId(jobId);
                if (req.getOrgId() == null || req.getOrgId().isBlank())
                    req.setOrgId(orgId);
                // Do NOT set a default versionType — leave null so FROM_CONFIG
                // triggers all variants if no versionType was specified
            } else {
                // No export request provided — find auto-export config for this org
                req = new ExportRequest();
                req.setJobId(jobId);
                req.setOrgId(orgId);

                // Find the active auto-export config for this org
                List<com.cim.model.mongo.Neo4jExportConfig> configs =
                        neo4jExportConfigRepo.findByOrgIdAndAutoExportTrueAndActiveTrue(orgId);
                if (configs.isEmpty()) {
                    // Try global configs (orgId blank)
                    configs = neo4jExportConfigRepo.findByAutoExportTrueAndActiveTrue()
                            .stream()
                            .filter(c -> c.getOrgId() == null || c.getOrgId().isBlank())
                            .collect(java.util.stream.Collectors.toList());
                }

                if (!configs.isEmpty()) {
                    // Use FROM_CONFIG with no versionType → all configured variants
                    req.setMode(ExportRequest.ExportMode.FROM_CONFIG);
                    req.setConfigId(configs.get(0).getId());
                    // versionType intentionally null → triggers ALL variants
                    log.info("Auto-export after revalidation: config='{}' all variants",
                            configs.get(0).getConfigName());
                } else {
                    // No config found — export topology as SANITISED fallback
                    req.setMode(ExportRequest.ExportMode.TOPOLOGY);
                    req.setVersionType(ExportRequest.VersionType.SANITISED);
                    log.info("Auto-export after revalidation: no config found, using TOPOLOGY/SANITISED");
                }
            }

            req.setClearFirst(true); // always clear — we just updated cim_objects
            neo4jExportService.startExport(req);
            log.info("Neo4j export triggered after revalidation: job={} orgId={}", jobId, orgId);
        } catch (Exception e) {
            log.warn("Neo4j export trigger failed after revalidation: {}", e.getMessage());
        }
    }

    // ── Status update helper ──────────────────────────────────────────────

    private void updateStatus(String revalidationId, String status,
                               long processed, long updated, String error) {
        org.springframework.data.mongodb.core.query.Update u =
                new org.springframework.data.mongodb.core.query.Update()
                        .set("status", status)
                        .set("objectsProcessed", processed)
                        .set("objectsUpdated", updated)
                        .set("completedAt", Instant.now().toString());
        if (error != null) u.set("errorMessage", error);
        mongo.updateFirst(
                new Query(Criteria.where("revalidationId").is(revalidationId)),
                u, "revalidation_jobs");
    }
}
