package com.cim.service;

import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.Neo4jExportJob;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

/**
 * Async executor for Neo4j export — SEPARATE BEAN from Neo4jExportService.
 *
 * WHY A SEPARATE CLASS?
 * Spring @Async works via proxy. When Neo4jExportService calls its OWN
 * exportAsync() method internally (this.exportAsync()), Spring's proxy
 * is bypassed and the call runs SYNCHRONOUSLY — @Async has NO effect.
 *
 * The fix: move the @Async method to a DIFFERENT Spring bean.
 * Neo4jExportService calls Neo4jExportExecutor.runAsync() →
 * Spring proxy intercepts → runs on async thread pool → truly async.
 *
 * Flow:
 *   POST /api/admin/neo4j/export
 *     → AdminController
 *       → Neo4jExportService.startExport()   (saves job, returns immediately)
 *         → Neo4jExportExecutor.runAsync()   (Spring proxy → async thread)
 *           → Neo4jExportService.runExport() (actual work on separate thread)
 *   HTTP 202 Accepted returned immediately ← client polls /exports/{exportId}
 */
@Component
public class Neo4jExportExecutor {

    private final Neo4jExportService exportService;

    public Neo4jExportExecutor(Neo4jExportService exportService) {
        this.exportService = exportService;
    }

    /**
     * This method is called from Neo4jExportService.startExport().
     * Because it is on a DIFFERENT bean, Spring's proxy intercepts the call
     * and runs it on the async thread pool configured in @EnableAsync.
     *
     * Returns immediately — caller gets HTTP 202 Accepted.
     * Client polls GET /api/admin/neo4j/exports/{exportId} for status.
     */
    @Async
    public CompletableFuture<Void> runAsync(ExportRequest req, Neo4jExportJob job) {
        exportService.runExport(req, job);
        return CompletableFuture.completedFuture(null);
    }
}
