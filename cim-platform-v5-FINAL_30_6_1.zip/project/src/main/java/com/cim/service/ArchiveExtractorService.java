package com.cim.service;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Extracts compressed archives (.zip, .tar, .tar.gz, .tgz, .taz) into their
 * individual file entries, so each one can be imported as its own job.
 *
 * SUPPORTED ARCHIVE TYPES:
 *   .zip            → java.util.zip.ZipInputStream (built-in JDK support)
 *   .tar            → Apache Commons Compress TarArchiveInputStream
 *   .tar.gz / .tgz  → GZIPInputStream wrapping TarArchiveInputStream
 *   .taz            → older synonym for .tar.gz — same handling
 *
 * Plain (non-archive) files are NOT handled here — the caller checks
 * isArchive() first and only calls extract() when true.
 *
 * Each extracted entry is fully read into memory as a byte[] before being
 * returned. This is fine for typical CIM file sizes (single-digit to low
 * double-digit MB per file); if archives ever need to hold very large
 * individual files, this would need to switch to a temp-file-backed
 * extraction instead of in-memory.
 */
@Service
public class ArchiveExtractorService {

    private static final Logger log = LoggerFactory.getLogger(ArchiveExtractorService.class);

    /** One extracted file: its name (within the archive) and raw content. */
    public static class ExtractedFile {
        public final String name;
        public final byte[] content;
        public ExtractedFile(String name, byte[] content) {
            this.name    = name;
            this.content = content;
        }
    }

    /**
     * Returns true if the filename indicates a supported archive format.
     * Detection is by extension only (not magic bytes) — sufficient here
     * since the caller already has the original filename from the upload.
     */
    public boolean isArchive(String filename) {
        if (filename == null) return false;
        String lower = filename.toLowerCase();
        return lower.endsWith(".zip")
            || lower.endsWith(".tar")
            || lower.endsWith(".tar.gz")
            || lower.endsWith(".tgz")
            || lower.endsWith(".taz");
    }

    /**
     * Extracts all file entries from the archive. Skips directory entries
     * and any entry with an empty name or zero-length content.
     *
     * @param bytes    raw archive content
     * @param filename original filename — used to pick the right extractor
     * @return list of extracted files (name + content); empty if archive
     *         contains no usable entries
     */
    public List<ExtractedFile> extract(byte[] bytes, String filename) throws IOException {
        String lower = filename.toLowerCase();

        if (lower.endsWith(".zip")) {
            return extractZip(bytes);
        }
        if (lower.endsWith(".tar")) {
            return extractTar(new ByteArrayInputStream(bytes));
        }
        if (lower.endsWith(".tar.gz") || lower.endsWith(".tgz") || lower.endsWith(".taz")) {
            try (GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(bytes))) {
                return extractTar(gzip);
            }
        }
        throw new IOException("Unsupported archive type: " + filename);
    }

    private List<ExtractedFile> extractZip(byte[] bytes) throws IOException {
        List<ExtractedFile> out = new ArrayList<>();
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                byte[] content = readAllBytes(zis);
                if (content.length == 0) continue;
                String name = baseName(entry.getName());
                if (name.isBlank()) continue;
                out.add(new ExtractedFile(name, content));
                log.debug("Extracted from zip: {} ({} bytes)", name, content.length);
            }
        }
        return out;
    }

    private List<ExtractedFile> extractTar(InputStream rawIn) throws IOException {
        List<ExtractedFile> out = new ArrayList<>();
        try (TarArchiveInputStream tis = new TarArchiveInputStream(rawIn)) {
            TarArchiveEntry entry;
            while ((entry = tis.getNextTarEntry()) != null) {
                if (entry.isDirectory()) continue;
                byte[] content = readAllBytes(tis);
                if (content.length == 0) continue;
                String name = baseName(entry.getName());
                if (name.isBlank()) continue;
                out.add(new ExtractedFile(name, content));
                log.debug("Extracted from tar: {} ({} bytes)", name, content.length);
            }
        }
        return out;
    }

    /** Strips any directory prefix from an archive entry name. */
    private String baseName(String entryName) {
        if (entryName == null) return "";
        String normalized = entryName.replace('\\', '/');
        int idx = normalized.lastIndexOf('/');
        return idx >= 0 ? normalized.substring(idx + 1) : normalized;
    }

    private byte[] readAllBytes(InputStream in) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] tmp = new byte[8192];
        int n;
        while ((n = in.read(tmp)) != -1) {
            buffer.write(tmp, 0, n);
        }
        return buffer.toByteArray();
    }
}
