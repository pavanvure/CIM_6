package com.cim.validation.registry;

import com.cim.model.mongo.CimClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory CIM class hierarchy registry.
 *
 * ALL category and isRequired decisions are driven by OWL data stored here.
 * No hardcoded class lists anywhere in the application.
 *
 * Populated at startup from cim_standard_owl MongoDB collection
 * (or via admin OWL upload endpoint).
 *
 * Key methods used by ImportService:
 *   getCategory(cimType)   → "PHYSICAL" or "LOGICAL" from OWL
 *   isRequired(cimType)    → true/false from OWL (used as default)
 *
 * Key methods used by path validation:
 *   validateAttributePath(objectType, tag) → VALID/INVALID/VENDOR/UNKNOWN
 */
@Component
public class CIMHierarchyRegistry {

    private static final Logger log = LoggerFactory.getLogger(CIMHierarchyRegistry.class);

    private final Map<String, CimClassDefinition> byName = new ConcurrentHashMap<>();

    // ── Loading ──────────────────────────────────────────────────────────

    public void load(List<CimClassDefinition> definitions) {
        byName.clear();
        definitions.forEach(d -> byName.put(d.getClassName(), d));
        log.info("Registry loaded: {} classes ({} PHYSICAL, {} LOGICAL)",
                byName.size(),
                byName.values().stream().filter(d -> "PHYSICAL".equals(d.getCategory())).count(),
                byName.values().stream().filter(d -> "LOGICAL".equals(d.getCategory())).count());
    }

    public boolean isLoaded()  { return !byName.isEmpty(); }
    public int     size()      { return byName.size(); }

    // ── Category — from OWL ONLY ─────────────────────────────────────────

    /**
     * Returns the OWL-derived category for a CIM type.
     * Returns "UNKNOWN" if type not in registry (vendor extension).
     * NEVER falls back to hardcoded logic.
     */
    public String getCategory(String cimType) {
        if (cimType == null) return "UNKNOWN";
        CimClassDefinition def = byName.get(cimType);
        if (def == null) return "UNKNOWN";
        return def.getCategory() != null ? def.getCategory() : "UNKNOWN";
    }

    /**
     * Returns the OWL-derived isRequired default for a CIM type.
     * PHYSICAL classes → true (required in the model)
     * LOGICAL classes  → false (optional model constructs)
     * Unknown types    → false (safe default)
     */
    public boolean getDefaultRequired(String cimType) {
        if (cimType == null) return false;
        CimClassDefinition def = byName.get(cimType);
        return def != null && def.isRequired();
    }

    public boolean isKnownClass(String cimType) {
        return cimType != null && byName.containsKey(cimType);
    }

    public CimClassDefinition getDefinition(String cimType) {
        return byName.get(cimType);
    }

    // ── Inheritance chain queries ─────────────────────────────────────────

    /**
     * Returns [className, parent, grandparent, ...] up to root.
     */
    public List<String> getFullChain(String cimType) {
        List<String> chain = new ArrayList<>();
        chain.add(cimType);
        CimClassDefinition def = byName.get(cimType);
        if (def != null) chain.addAll(def.getAncestors());
        return chain;
    }

    /**
     * Returns true if declaringClass is in the inheritance chain of objectType.
     * E.g. isInChain("ACLineSegment","ConductingEquipment") → true
     */
    public boolean isInChain(String objectType, String declaringClass) {
        if (objectType == null || declaringClass == null) return false;
        if (objectType.equals(declaringClass)) return true;
        CimClassDefinition def = byName.get(objectType);
        return def != null && def.getAncestors().contains(declaringClass);
    }

    // ── Path validation ───────────────────────────────────────────────────

    /**
     * Validates that attributeTag (e.g. "ConductingEquipment.BaseVoltage")
     * is a valid attribute for objectType (e.g. "ACLineSegment").
     *
     * Rules:
     *   1. Tag has no "." → treat as simple name, accept as VALID
     *   2. declaringClass has vendor namespace (":" or "/") → VENDOR_EXTENSION
     *   3. objectType not in registry → UNKNOWN_TYPE
     *   4. declaringClass in inheritance chain → VALID
     *   5. Otherwise → INVALID
     */
    public PathValidationResult validateAttributePath(String objectType,
                                                       String attributeTag) {
        if (objectType == null || attributeTag == null)
            return PathValidationResult.unknownType(objectType, attributeTag);

        // No dot in tag — simple attribute name, no declaring class to check
        int dot = attributeTag.lastIndexOf('.');
        if (dot < 0) return PathValidationResult.valid(objectType, attributeTag, objectType);

        String declaringClass = attributeTag.substring(0, dot);
        String attrName       = attributeTag.substring(dot + 1);

        // Vendor extension namespace
        if (declaringClass.contains(":") || declaringClass.contains("/")
                || declaringClass.contains("\\"))
            return PathValidationResult.vendorExtension(objectType, attributeTag);

        // Type not registered
        if (!isKnownClass(objectType))
            return PathValidationResult.unknownType(objectType, attributeTag);

        // Check inheritance chain
        if (isInChain(objectType, declaringClass))
            return PathValidationResult.valid(objectType, attributeTag, declaringClass);

        return PathValidationResult.invalid(objectType, attributeTag, declaringClass);
    }

    // ── Summary stats ─────────────────────────────────────────────────────

    public Map<String, Object> getStats() {
        long physical = byName.values().stream()
                .filter(d -> "PHYSICAL".equals(d.getCategory())).count();
        long logical  = byName.values().stream()
                .filter(d -> "LOGICAL".equals(d.getCategory())).count();
        long withAttrs = byName.values().stream()
                .filter(d -> !d.getOwnAttributes().isEmpty()).count();
        return Map.of(
            "totalClasses", byName.size(),
            "physical", physical, "logical", logical,
            "withAttributes", withAttrs,
            "loaded", isLoaded()
        );
    }
}
