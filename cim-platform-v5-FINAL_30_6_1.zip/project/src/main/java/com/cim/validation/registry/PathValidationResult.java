package com.cim.validation.registry;

public class PathValidationResult {
    public enum Status { VALID, INVALID, VENDOR_EXTENSION, UNKNOWN_TYPE }

    private final Status status;
    private final String explanation;

    private PathValidationResult(Status s, String e) { status=s; explanation=e; }

    public Status  getStatus()      { return status; }
    public String  getExplanation() { return explanation; }
    public boolean isValid()        { return status == Status.VALID; }
    public boolean isInvalid()      { return status == Status.INVALID; }

    public static PathValidationResult valid(String t, String tag, String dc) {
        return new PathValidationResult(Status.VALID,
                "'"+dc+"' is in the ancestry chain of '"+t+"'");
    }
    public static PathValidationResult invalid(String t, String tag, String dc) {
        return new PathValidationResult(Status.INVALID,
                "'"+dc+"' is NOT in the ancestry chain of '"+t+"'");
    }
    public static PathValidationResult vendorExtension(String t, String tag) {
        return new PathValidationResult(Status.VENDOR_EXTENSION,
                "'"+tag+"' uses a vendor-specific namespace — not in CIM standard");
    }
    public static PathValidationResult unknownType(String t, String tag) {
        return new PathValidationResult(Status.UNKNOWN_TYPE,
                "'"+t+"' is not registered in the CIM OWL hierarchy");
    }
}
