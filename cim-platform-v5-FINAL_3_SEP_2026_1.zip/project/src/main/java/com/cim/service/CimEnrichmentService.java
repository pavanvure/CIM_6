package com.cim.service;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Phase 3 post-import enrichment for cim_objects.
 *
 * ROOT CAUSE FIX — why Map<String,String> failed:
 *   Spring Data MongoDB cannot deserialize Map<String,String> when:
 *   a) Keys contain dots (e.g. "Terminal.ConductingEquipment") — it tries
 *      to interpret them as nested-object path separators → empty map
 *   b) Values are non-String types (e.g. nominalVoltage stored as Double 21.6)
 *      → silently dropped, returns null
 *
 *   FIX: Use raw org.bson.Document for ALL MongoDB reads.
 *   doc.get("resolvedRefIds", Document.class) and doc.get("attributes", Document.class)
 *   return the raw BSON document with dot-containing keys and mixed value types
 *   fully preserved. safeString() converts any value type to String.
 *
 * CONFIRMED KEY NAMES (from your MongoDB data):
 *   resolvedRefIds — raw dots:
 *     "ConductingEquipment.BaseVoltage"              → BaseVoltage rdfId
 *     "Terminal.ConductingEquipment"                 → Equipment rdfId
 *     "Terminal.ConnectivityNode"                    → ConnectivityNode rdfId
 *     "ConnectivityNode.ConnectivityNodeContainer"   → VoltageLevel rdfId
 *     "VoltageLevel.Substation"                      → Substation rdfId
 *     "Substation.Region"                            → SGR rdfId
 *     "SubGeographicalRegion.Region"                 → GR rdfId (some docs use "Substation.Region")
 *   attributes — raw dots (no MapKeySanitizer encoding in your version):
 *     "BaseVoltage.nominalVoltage"  → Double (e.g. 21.6)
 *     "IdentifiedObject.name"       → String
 *
 * ORGANISATION GATE:
 *   Currently CAISO only. Add to ENRICHMENT_ENABLED_ORGS to enable others.
 */
@Service
public class CimEnrichmentService {

    private static final Logger log = LoggerFactory.getLogger(CimEnrichmentService.class);

    private static final Set<String> ENRICHMENT_ENABLED_ORGS =
            new HashSet<>(Arrays.asList(
                "CAISO"
                // "ERCOT",
                // "SPC",
            ));

    // resolvedRefIds keys — raw dots
    private static final String REF_CE_BV      = "ConductingEquipment.BaseVoltage";
    private static final String REF_T_EQUIP    = "Terminal.ConductingEquipment";
    private static final String REF_T_CN       = "Terminal.ConnectivityNode";
    private static final String REF_CN_VL      = "ConnectivityNode.ConnectivityNodeContainer";
    private static final String REF_VL_SUB     = "VoltageLevel.Substation";
    private static final String REF_SUB_REGION = "Substation.Region";
    private static final String REF_SGR_REGION = "SubGeographicalRegion.Region";
    private static final String REF_SGR_ALT    = "Substation.Region"; // some SGR docs use this

    // attributes keys — raw dots (no encoding in your MongoDB version)
    private static final String ATTR_VOLTAGE = "BaseVoltage.nominalVoltage";
    private static final String ATTR_NAME    = "IdentifiedObject.name";

    private static final int PAGE = 500;

    private final MongoTemplate mongo;

    public CimEnrichmentService(MongoTemplate mongo) {
        this.mongo = mongo;
    }

    // ── Entry point ───────────────────────────────────────────────────────

    public boolean enrich(String jobId, String orgId) {
        if (!isEnabled(orgId)) {
            log.info("CimEnrichment skipped: org={} not in ENRICHMENT_ENABLED_ORGS", orgId);
            return false;
        }
        long start = System.currentTimeMillis();
        log.info("CimEnrichment starting: job={} org={}", jobId, orgId);

        Map<String, String>       bvMap   = buildBvMap(jobId);
        Map<String, List<String>> tByEquip = buildTerminalsByEquip(jobId);
        Map<String, String>       cnByT   = buildCnByTerminal(jobId);
        Map<String, String>       vlByCn  = buildVlByCn(jobId);
        Map<String, SubInfo>      subByVl = buildSubByVl(jobId);
        enrichWithRegions(jobId, subByVl);

        log.info("Maps: bv={} tByEquip={} cnByT={} vlByCn={} subByVl={}",
                bvMap.size(), tByEquip.size(), cnByT.size(), vlByCn.size(), subByVl.size());

        long voltageCount = 0, substationCount = 0;
        String lastId = null;

        while (true) {
            List<Document> page = fetchPage(jobId, lastId);
            if (page.isEmpty()) break;
            lastId = page.get(page.size() - 1).getObjectId("_id").toHexString();

            List<Map<String, Object>> updates = new ArrayList<>();
            for (Document doc : page) {
                Map<String, String> enriched = new LinkedHashMap<>();
                computeVoltage(doc, bvMap, enriched);
                computeSubstations(doc, tByEquip, cnByT, vlByCn, subByVl, enriched);
                if (!enriched.isEmpty()) {
                    if (enriched.containsKey("nominalVoltage")) voltageCount++;
                    if (enriched.containsKey("substationMrid")) substationCount++;
                    Map<String, Object> upd = new LinkedHashMap<>();
                    upd.put("id", lastId.equals(
                            page.get(page.size()-1).getObjectId("_id").toHexString())
                            ? doc.getObjectId("_id").toHexString()
                            : doc.getObjectId("_id").toHexString());
                    upd.put("id", doc.getObjectId("_id").toHexString());
                    upd.put("enriched", enriched);
                    updates.add(upd);
                }
            }
            bulkWrite(updates);
        }

        log.info("CimEnrichment done: job={} org={} elapsed={} nominalVoltage={} substation={}",
                jobId, orgId,
                com.cim.model.mongo.StageTimings.format(System.currentTimeMillis() - start),
                voltageCount, substationCount);
        return true;
    }

    private boolean isEnabled(String orgId) {
        if (orgId == null) return false;
        return ENRICHMENT_ENABLED_ORGS.stream()
                .anyMatch(o -> o.equalsIgnoreCase(orgId.trim()));
    }

    // ── Lookup maps — all use raw Document ───────────────────────────────

    /** BaseVoltage.rdfId → nominalVoltage string (handles numeric BSON value). */
    private Map<String, String> buildBvMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            List<Document> batch = findDocs(jobId, "BaseVoltage", lastId);
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size()-1).getObjectId("_id").toHexString();
            for (Document doc : batch) {
                Document attrs = doc.get("attributes", Document.class);
                if (attrs == null) continue;
                String val = safeString(attrs.get(ATTR_VOLTAGE));
                if (val == null) continue;
                putBoth(map, doc.getString("rdfId"), doc.getString("mrid"), val);
            }
        }
        log.info("buildBvMap: {} entries", map.size());
        return map;
    }

    /** equipmentRdfId → list of Terminal rdfIds. */
    private Map<String, List<String>> buildTerminalsByEquip(String jobId) {
        Map<String, List<String>> map = new HashMap<>();
        String lastId = null;
        while (true) {
            List<Document> batch = findDocs(jobId, "Terminal", lastId);
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size()-1).getObjectId("_id").toHexString();
            for (Document doc : batch) {
                String rdfId = doc.getString("rdfId");
                Document refs = doc.get("resolvedRefIds", Document.class);
                if (rdfId == null || refs == null) continue;
                String equipId = (String) refs.get(REF_T_EQUIP);
                if (equipId != null && !equipId.isBlank())
                    map.computeIfAbsent(equipId, k -> new ArrayList<>()).add(rdfId);
            }
        }
        log.info("buildTerminalsByEquip: {} entries", map.size());
        return map;
    }

    /** Terminal.rdfId → ConnectivityNode.rdfId. */
    private Map<String, String> buildCnByTerminal(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            List<Document> batch = findDocs(jobId, "Terminal", lastId);
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size()-1).getObjectId("_id").toHexString();
            for (Document doc : batch) {
                String rdfId = doc.getString("rdfId");
                Document refs = doc.get("resolvedRefIds", Document.class);
                if (rdfId == null || refs == null) continue;
                String cnId = (String) refs.get(REF_T_CN);
                if (cnId != null && !cnId.isBlank()) map.put(rdfId, cnId);
            }
        }
        log.info("buildCnByTerminal: {} entries", map.size());
        return map;
    }

    /** ConnectivityNode.rdfId → VoltageLevel.rdfId. */
    private Map<String, String> buildVlByCn(String jobId) {
        Map<String, String> map = new HashMap<>();
        String lastId = null;
        while (true) {
            List<Document> batch = findDocs(jobId, "ConnectivityNode", lastId);
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size()-1).getObjectId("_id").toHexString();
            for (Document doc : batch) {
                String rdfId = doc.getString("rdfId");
                Document refs = doc.get("resolvedRefIds", Document.class);
                if (rdfId == null || refs == null) continue;
                String vlId = (String) refs.get(REF_CN_VL);
                if (vlId != null && !vlId.isBlank()) map.put(rdfId, vlId);
            }
        }
        log.info("buildVlByCn: {} entries", map.size());
        return map;
    }

    /** VoltageLevel.rdfId → SubInfo (rdfId, mrid, name). */
    private Map<String, SubInfo> buildSubByVl(String jobId) {
        // Step A: VL → substation rdfId
        Map<String, String> subRdfByVl = new HashMap<>();
        String lastId = null;
        while (true) {
            List<Document> batch = findDocs(jobId, "VoltageLevel", lastId);
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size()-1).getObjectId("_id").toHexString();
            for (Document doc : batch) {
                String rdfId = doc.getString("rdfId");
                Document refs = doc.get("resolvedRefIds", Document.class);
                if (rdfId == null || refs == null) continue;
                String subId = (String) refs.get(REF_VL_SUB);
                if (subId != null && !subId.isBlank()) subRdfByVl.put(rdfId, subId);
            }
        }
        if (subRdfByVl.isEmpty()) return new HashMap<>();

        // Step B: fetch Substation mrid + name
        Map<String, SubInfo> subByRdfId = new HashMap<>();
        Set<String> subRdfIds = new HashSet<>(subRdfByVl.values());
        // VoltageLevel.Substation ref may point to Substation's rdfId or mrid
        Query q = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("Substation")
                .orOperator(
                    Criteria.where("rdfId").in(subRdfIds),
                    Criteria.where("mrid").in(subRdfIds)
                ));
        AtomicBoolean logged = new AtomicBoolean(false);
        for (Document doc : mongo.find(q, Document.class, "cim_objects")) {
            String rdfId = doc.getString("rdfId");
            if (rdfId == null) continue;
            Document attrs = doc.get("attributes", Document.class);
            String name = attrs != null ? safeString(attrs.get(ATTR_NAME)) : null;
            if (logged.compareAndSet(false, true))
                log.info("Substation sample: rdfId={} name={}", rdfId, name);
            String mrid = doc.getString("mrid");
            // Use mrid as primary rdfId for SubInfo so sgrRdfBySub lookup works
            // (Substation.Region ref stores the mrid value, not the rdfId)
            SubInfo si = new SubInfo(mrid != null ? mrid : rdfId, mrid, name);
            putBothSubInfo(subByRdfId, rdfId, mrid, si);
        }

        // Step C: vlRdfId → SubInfo
        Map<String, SubInfo> result = new HashMap<>();
        for (Map.Entry<String, String> e : subRdfByVl.entrySet()) {
            SubInfo si = subByRdfId.get(e.getValue());
            if (si != null) result.put(e.getKey(), si);
        }
        log.info("buildSubByVl: {} entries", result.size());
        return result;
    }

    /** Enriches each SubInfo with SGR mrid/name and GR mrid/name. */
    private void enrichWithRegions(String jobId, Map<String, SubInfo> subByVl) {
        if (subByVl.isEmpty()) return;

        // Collect unique Substation identifiers (si.rdfId = mrid after buildSubByVl fix)
        Set<String> subMrids = subByVl.values().stream()
                .filter(s -> s.rdfId != null).map(s -> s.rdfId).collect(Collectors.toSet());

        // Substation → sgrRef via "Substation.Region"
        // Key sgrRdfBySub by mrid so the SubInfo lookup matches
        Map<String, String> sgrRdfBySub = new HashMap<>();
        Query subQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("Substation")
                .orOperator(
                    Criteria.where("rdfId").in(subMrids),
                    Criteria.where("mrid").in(subMrids)
                ));
        for (Document doc : mongo.find(subQ, Document.class, "cim_objects")) {
            Document refs = doc.get("resolvedRefIds", Document.class);
            if (refs == null) continue;
            String sgrId = (String) refs.get(REF_SUB_REGION);
            if (sgrId == null || sgrId.isBlank()) continue;
            // Store by both rdfId and mrid so lookup matches either
            String rdfId = doc.getString("rdfId");
            String mrid  = doc.getString("mrid");
            if (rdfId != null) sgrRdfBySub.put(rdfId, sgrId);
            if (mrid  != null && !mrid.equals(rdfId)) sgrRdfBySub.put(mrid, sgrId);
        }

        Set<String> sgrRdfIds = new HashSet<>(sgrRdfBySub.values());
        if (sgrRdfIds.isEmpty()) return;

        // SGR → mrid, name, grRdfId
        // NOTE: Substation.Region ref value = SGR's MRID (not rdfId).
        // SGR documents store the string identifier in "mrid" field.
        // Query by mrid, not rdfId.
        Map<String, String[]> sgrInfo = new HashMap<>();
        Query sgrQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("SubGeographicalRegion").and("mrid").in(sgrRdfIds));
        AtomicBoolean sgrLogged = new AtomicBoolean(false);
        for (Document doc : mongo.find(sgrQ, Document.class, "cim_objects")) {
            // Key by mrid — that is what Substation.Region refs point to
            String mrid = doc.getString("mrid");
            if (mrid == null) continue;
            Document attrs = doc.get("attributes", Document.class);
            Document refs  = doc.get("resolvedRefIds", Document.class);
            String name    = attrs != null ? safeString(attrs.get(ATTR_NAME)) : null;
            String grId    = refs  != null ? (String) refs.get(REF_SGR_REGION) : null;
            if (grId == null && refs != null) grId = (String) refs.get(REF_SGR_ALT);
            if (sgrLogged.compareAndSet(false, true))
                log.info("SGR sample: mrid={} name={} grRef={}", mrid, name, grId);
            // Store by mrid as primary key
            String[] entry = {mrid, name, grId};
            sgrInfo.put(mrid, entry);
            // Also store by rdfId if different, as fallback
            String rdfId = doc.getString("rdfId");
            if (rdfId != null && !rdfId.equals(mrid)) sgrInfo.put(rdfId, entry);
        }

        // GR → mrid, name
        Set<String> grRdfIds = sgrInfo.values().stream()
                .filter(v -> v[2] != null && !v[2].isBlank())
                .map(v -> v[2]).collect(Collectors.toSet());
        Map<String, String[]> grInfo = new HashMap<>();
        if (!grRdfIds.isEmpty()) {
            // GR: SubGeographicalRegion.Region ref value may be GR's mrid
            // Query by mrid OR rdfId — use $or to handle both cases
            Query grQ = new Query(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("GeographicalRegion")
                    .orOperator(
                        Criteria.where("rdfId").in(grRdfIds),
                        Criteria.where("mrid").in(grRdfIds)
                    ));
            AtomicBoolean grLogged = new AtomicBoolean(false);
            for (Document doc : mongo.find(grQ, Document.class, "cim_objects")) {
                Document attrs = doc.get("attributes", Document.class);
                String name  = attrs != null ? safeString(attrs.get(ATTR_NAME)) : null;
                String rdfId = doc.getString("rdfId");
                String mrid  = doc.getString("mrid");
                if (grLogged.compareAndSet(false, true))
                    log.info("GR sample: rdfId={} mrid={} name={}", rdfId, mrid, name);
                // Key by BOTH rdfId and mrid so we match however the ref was stored
                String[] entry = {mrid, name};
                if (rdfId != null) grInfo.put(rdfId, entry);
                if (mrid  != null && !mrid.equals(rdfId)) grInfo.put(mrid, entry);
            }
        }

        // Attach SGR + GR to each SubInfo
        long withSgr = 0, withGr = 0;
        for (SubInfo si : subByVl.values()) {
            // Try si.rdfId first (which is set to mrid in buildSubByVl), then si.mrid
            String sgrId = si.rdfId != null ? sgrRdfBySub.get(si.rdfId) : null;
            if (sgrId == null && si.mrid != null) sgrId = sgrRdfBySub.get(si.mrid);
            if (sgrId == null) continue;
            String[] sgr = sgrInfo.get(sgrId);
            if (sgr == null) continue;
            si.sgrMrid = sgr[0]; si.sgrName = sgr[1];
            withSgr++;
            if (sgr[2] != null) {
                String[] gr = grInfo.get(sgr[2]);
                if (gr != null) { si.grMrid = gr[0]; si.grName = gr[1]; withGr++; }
            }
        }
        log.info("enrichWithRegions: {}/{} have SGR, {}/{} have GR",
                withSgr, subByVl.size(), withGr, subByVl.size());
    }

    // ── Per-object computation ─────────────────────────────────────────────

    private void computeVoltage(Document doc,
                                 Map<String, String> bvMap,
                                 Map<String, String> enriched) {
        Document refs = doc.get("resolvedRefIds", Document.class);
        if (refs == null) return;
        String bvId = (String) refs.get(REF_CE_BV);
        if (bvId == null || bvId.isBlank()) return;
        String voltage = bvMap.get(bvId);
        if (voltage == null || voltage.isBlank()) return;
        enriched.put("nominalVoltage", voltage);
    }

    // CIM types that span multiple substations — skip substation/SGR/GR for these
    private static final Set<String> SKIP_SUBSTATION_TYPES =
            new HashSet<>(Arrays.asList("ACLineSegment", "PowerTransformer"));

    private void computeSubstations(Document doc,
                                     Map<String, List<String>> tByEquip,
                                     Map<String, String> cnByT,
                                     Map<String, String> vlByCn,
                                     Map<String, SubInfo> subByVl,
                                     Map<String, String> enriched) {
        // Skip ACLineSegment and PowerTransformer — they span multiple substations
        // so a single substation value would be misleading
        String cimType = doc.getString("cimType");
        if (cimType != null && SKIP_SUBSTATION_TYPES.contains(cimType)) return;

        String rdfId = doc.getString("rdfId");
        if (rdfId == null) return;
        List<String> terminals = tByEquip.get(rdfId);
        if (terminals == null || terminals.isEmpty()) return;

        LinkedHashMap<String, SubInfo> found = new LinkedHashMap<>();
        for (String tId : terminals) {
            String cnId = cnByT.get(tId);    if (cnId == null) continue;
            String vlId = vlByCn.get(cnId);  if (vlId == null) continue;
            SubInfo sub = subByVl.get(vlId); if (sub == null) continue;
            String key = sub.mrid != null ? sub.mrid : sub.rdfId;
            if (key != null) found.put(key, sub);
        }
        if (found.isEmpty()) return;

        // Naming convention (manager requirement):
        //   First instance  : no suffix  → substationMrid, substationName
        //   Second instance : suffix "B" → substationMridB, substationNameB
        //   Third instance  : suffix "C" → substationMridC, substationNameC
        //   ... and so on through the alphabet
        //
        // Same pattern for subGeographicalRegion and geographicalRegion.
        // GeographicalRegion is deduplicated — written once even if multiple
        // substations share the same GR.

        // Build deduplicated SGR and GR maps preserving insertion order
        java.util.LinkedHashMap<String, String> sgrNameByMrid = new java.util.LinkedHashMap<>();
        java.util.LinkedHashMap<String, String> grNameByMrid  = new java.util.LinkedHashMap<>();

        int idx = 0;
        for (SubInfo sub : found.values()) {
            // suffix: idx=0 → "", idx=1 → "B", idx=2 → "C", ...
            String suffix = idx == 0 ? "" : String.valueOf((char) ('B' + idx - 1));

            if (sub.mrid != null) enriched.put("substationMrid" + suffix, sub.mrid);
            if (sub.name != null) enriched.put("substationName" + suffix, sub.name);

            // Collect SGR/GR for deduplication
            if (sub.sgrMrid != null && !sub.sgrMrid.isBlank())
                sgrNameByMrid.merge(sub.sgrMrid,
                        sub.sgrName != null ? sub.sgrName : "",
                        (a, b) -> a.isEmpty() ? b : a);
            if (sub.grMrid != null && !sub.grMrid.isBlank())
                grNameByMrid.merge(sub.grMrid,
                        sub.grName != null ? sub.grName : "",
                        (a, b) -> a.isEmpty() ? b : a);
            idx++;
        }

        // Write deduplicated SGR with same A/B/C suffix pattern
        int sgrIdx = 0;
        for (java.util.Map.Entry<String, String> e : sgrNameByMrid.entrySet()) {
            if (e.getKey().isBlank()) { sgrIdx++; continue; }
            String suffix = sgrIdx == 0 ? "" : String.valueOf((char) ('B' + sgrIdx - 1));
            enriched.put("subGeographicalRegionMrid" + suffix, e.getKey());
            if (!e.getValue().isBlank())
                enriched.put("subGeographicalRegionName" + suffix, e.getValue());
            sgrIdx++;
        }

        // Write deduplicated GR with same A/B/C suffix pattern
        int grIdx = 0;
        for (java.util.Map.Entry<String, String> e : grNameByMrid.entrySet()) {
            if (e.getKey().isBlank()) { grIdx++; continue; }
            String suffix = grIdx == 0 ? "" : String.valueOf((char) ('B' + grIdx - 1));
            enriched.put("geographicalRegionMrid" + suffix, e.getKey());
            if (!e.getValue().isBlank())
                enriched.put("geographicalRegionName" + suffix, e.getValue());
            grIdx++;
        }
    }

    // ── Write ──────────────────────────────────────────────────────────────

    private void bulkWrite(List<Map<String, Object>> updates) {
        for (Map<String, Object> upd : updates) {
            String id = (String) upd.get("id");
            @SuppressWarnings("unchecked")
            Map<String, String> enriched = (Map<String, String>) upd.get("enriched");
            if (enriched == null || enriched.isEmpty()) continue;
            Update update = new Update();
            for (Map.Entry<String, String> e : enriched.entrySet())
                update.set("attributes." + e.getKey(), e.getValue());
            try {
                mongo.updateFirst(
                    new Query(Criteria.where("_id").is(new org.bson.types.ObjectId(id))),
                    update, "cim_objects");
            } catch (Exception ex) {
                log.warn("bulkWrite error id={}: {}", id, ex.getMessage());
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<Document> fetchPage(String jobId, String lastId) {
        Criteria c = Criteria.where("jobId").is(jobId);
        if (lastId != null)
            c = new Criteria().andOperator(c,
                    Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));
        return mongo.find(new Query(c).limit(PAGE)
                .with(Sort.by(Sort.Direction.ASC, "_id")),
                Document.class, "cim_objects");
    }

    private List<Document> findDocs(String jobId, String cimType, String lastId) {
        Criteria c = Criteria.where("jobId").is(jobId).and("cimType").is(cimType);
        if (lastId != null)
            c = new Criteria().andOperator(c,
                    Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));
        return mongo.find(new Query(c).limit(PAGE)
                .with(Sort.by(Sort.Direction.ASC, "_id")),
                Document.class, "cim_objects");
    }

    private void putBoth(Map<String, String> map, String rdfId, String mrid, String val) {
        if (rdfId != null && !rdfId.isBlank()) map.put(rdfId, val);
        if (mrid != null && !mrid.isBlank() && !mrid.equals(rdfId)) map.put(mrid, val);
    }

    private void putBothSubInfo(Map<String, SubInfo> map, String rdfId, String mrid, SubInfo si) {
        if (rdfId != null && !rdfId.isBlank()) map.put(rdfId, si);
        if (mrid != null && !mrid.isBlank() && !mrid.equals(rdfId)) map.put(mrid, si);
    }

    /** Converts any BSON value (String, Double, Integer, Boolean) to String. */
    private String safeString(Object val) {
        if (val == null) return null;
        String s = val.toString().trim();
        return s.isBlank() ? null : s;
    }

    private static class SubInfo {
        final String rdfId, mrid, name;
        String sgrMrid, sgrName, grMrid, grName;
        SubInfo(String rdfId, String mrid, String name) {
            this.rdfId = rdfId; this.mrid = mrid; this.name = name;
        }
    }
}
