// ─────────────────────────────────────────────────────────────────────────────
// ADD THIS METHOD to your existing ImportService.java
//
// Also add these imports at the top of ImportService.java if not already present:
//   import org.springframework.scheduling.annotation.Async;
//   import com.cim.service.FtpFileService;
//
// Also ensure @EnableAsync is on your Spring Boot main class or a @Configuration class.
// ─────────────────────────────────────────────────────────────────────────────

    /**
     * Downloads a large SFTP/FTP file to a local temp path and imports it —
     * all in a background thread. The HTTP thread has already returned 202.
     *
     * Phase history recorded in validation_jobs.phaseHistory:
     *   FTP_SIZE_CHECK   — result of the remote file size check (skipped if not called before this)
     *   FTP_DOWNLOAD     — time and bytes for the actual download
     *   (STREAMING_PARSE, RESOLVING_REFERENCES, ENRICHMENT, NEO4J_EXPORT* follow via processAndResolveFromPath)
     *
     * Flow:
     *   1. Record FTP_DOWNLOAD start
     *   2. Download file via FtpFileService.downloadFile() → temp file
     *   3. Record FTP_DOWNLOAD COMPLETED (with bytes and duration)
     *   4. Detect format from first 512 bytes
     *   5. Update the already-saved job record with the detected format
     *   6. Run processAndResolveFromPath() which handles parse + Neo4j export
     *   7. Delete the temp file (always, even on failure)
     *   8. On failure: record FTP_DOWNLOAD FAILED + update job status to FAILED
     *
     * The caller can poll GET /api/jobs/{jobId} or GET /api/jobs/{jobId}/progress
     * to track the status and progress.
     *
     * @param ftpFileService  FTP/SFTP service used to download the file
     * @param fileName        Plain file name on the remote server (no directory)
     * @param jobId           Already-saved job ID — status starts as PROCESSING
     * @param networkVersion  CIM network version label
     * @param orgId           Organisation ID (e.g. "CAISO")
     * @param exportToNeo4j   Whether to run Neo4j export after MongoDB import
     */
    @org.springframework.scheduling.annotation.Async
    public void downloadAndImportAsync(
            com.cim.service.FtpFileService ftpFileService,
            String fileName,
            String jobId,
            String networkVersion,
            String orgId,
            boolean exportToNeo4j) {

        String tempFile = null;
        Instant downloadStartedAt = Instant.now();
        try {
            log.info("Async FTP/SFTP download starting: jobId={} fileName={}", jobId, fileName);

            // ── Phase: FTP_DOWNLOAD ───────────────────────────────────────────
            // Mark download as in-progress in phaseHistory so operators
            // can see the job is actively downloading (not stuck/forgotten).
            recordPhase(jobId, "FTP_DOWNLOAD",
                    downloadStartedAt, downloadStartedAt, 0, "RUNNING",
                    null,
                    "Downloading " + fileName + " from FTP/SFTP server...");

            // ── Step 1: Download to temp file ─────────────────────────────────
            long downloadStart = System.currentTimeMillis();
            tempFile = ftpFileService.downloadFile(fileName);
            long downloadMs  = System.currentTimeMillis() - downloadStart;

            long fileSizeBytes = new java.io.File(tempFile).length();
            double fileSizeMb  = fileSizeBytes / (1024.0 * 1024.0);
            Instant downloadDone = Instant.now();

            log.info("Async FTP/SFTP download complete: jobId={} file={} size={:.2f}MB time={}ms",
                    jobId, fileName, fileSizeMb, downloadMs);

            // Record FTP_DOWNLOAD as COMPLETED with file size and duration
            recordPhase(jobId, "FTP_DOWNLOAD",
                    downloadStartedAt, downloadDone,
                    fileSizeBytes, "COMPLETED",
                    null,
                    String.format("Downloaded %s from FTP/SFTP: %.2f MB in %s",
                            fileName, fileSizeMb,
                            com.cim.model.mongo.StageTimings.format(downloadMs)));

            // ── Step 2: Detect format from file header ────────────────────────
            java.io.File f = new java.io.File(tempFile);
            byte[] header = new byte[512];
            int n = 0;
            try (java.io.FileInputStream fis = new java.io.FileInputStream(f)) {
                n = fis.read(header, 0, 512);
            }
            String h = new String(header, 0, Math.max(n, 0));
            String format;
            if (h.contains("rdf:RDF") || h.contains("xmlns:cim")) format = "RDF_XML";
            else if (h.contains("@context") || h.contains("@graph")) format = "JSON_LD";
            else if (fileName.toLowerCase().endsWith(".csv")) format = "MILSOFT_CSV";
            else format = "RDF_XML";

            // ── Step 3: Patch job record with detected format ─────────────────
            jobRepo.findByJobId(jobId).ifPresent(j -> {
                j.setFormat(format);
                jobRepo.save(j);
            });

            // ── Step 4: Run import (parse → MongoDB → Neo4j) ─────────────────
            processAndResolveFromPath(
                    tempFile, fileName, format, jobId, networkVersion, orgId, exportToNeo4j);

        } catch (Exception e) {
            log.error("Async FTP/SFTP import failed: jobId={} fileName={} error={}",
                    jobId, fileName, e.getMessage(), e);

            // Record FTP_DOWNLOAD as FAILED in phaseHistory
            recordPhase(jobId, "FTP_DOWNLOAD",
                    downloadStartedAt, Instant.now(), 0, "FAILED",
                    e.getMessage(),
                    "FTP/SFTP download failed for " + fileName + ": " + e.getMessage());

            // Mark job as FAILED so the caller sees a terminal status when polling
            jobRepo.findByJobId(jobId).ifPresent(j -> {
                j.setStatus("FAILED");
                j.setErrorMessage("FTP/SFTP download/import failed: " + e.getMessage());
                j.setCompletedAt(Instant.now());
                jobRepo.save(j);
            });
        } finally {
            // ── Step 5: Always delete the temp file ───────────────────────────
            if (tempFile != null) {
                try {
                    boolean deleted = new java.io.File(tempFile).delete();
                    log.info("Async FTP/SFTP temp file {}: {}",
                            tempFile, deleted ? "deleted" : "could not delete");
                } catch (Exception ex) {
                    log.warn("Could not delete FTP/SFTP temp file {}: {}", tempFile, ex.getMessage());
                }
            }
        }
    }
