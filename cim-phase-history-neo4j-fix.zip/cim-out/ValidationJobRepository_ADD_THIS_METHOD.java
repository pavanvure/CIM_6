// ─────────────────────────────────────────────────────────────────────────────
// ADD THIS METHOD to your existing ValidationJobRepository.java (Spring Data interface)
//
// Used for fast duplicate pre-check by fileName + networkVersion BEFORE
// starting an SFTP download — avoids downloading a large file that will
// be rejected as duplicate anyway.
//
// "sourceFile" is the field on ValidationJob that stores the original file name.
// If your field is named differently (e.g. "fileName", "originalFileName"),
// change "SourceFile" in the method name to match.
// ─────────────────────────────────────────────────────────────────────────────

    /**
     * Find existing jobs for the same file name + network version that are
     * in an active or completed state. Used as a fast pre-flight duplicate
     * check before starting a large SFTP download.
     *
     * Statuses to pass: ["PENDING", "RUNNING", "RESOLVED", "PROCESSING"]
     */
    List<com.cim.model.mongo.ValidationJob> findBySourceFileAndNetworkVersionAndStatusIn(
            String sourceFile,
            String networkVersion,
            List<String> statuses);
