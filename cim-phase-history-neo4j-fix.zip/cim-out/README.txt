CIM SFTP ASYNC + PHASE HISTORY + NEO4J EXPORT FIX
==================================================

Changes to apply:
─────────────────

1. ImportController.java  (REPLACE the existing file)
   - Large SFTP files (>50MB): now returns 202 IMMEDIATELY instead of blocking
     the HTTP thread during download. Download + import runs in background.
   - Duplicate pre-check: before starting any SFTP download (large OR small),
     checks by fileName+networkVersion if an active job already exists.
     Returns 409 instantly without touching the SFTP server.

2. ImportService_downloadAndImportAsync_ADD_THIS_METHOD.java
   - Add the downloadAndImportAsync() method to your ImportService.java.
   - NEW in this version: records FTP_DOWNLOAD phase in validation_jobs.phaseHistory:
       FTP_DOWNLOAD (RUNNING)   → pushed immediately when download begins
       FTP_DOWNLOAD (COMPLETED) → updated with file size in bytes, duration in ms
       FTP_DOWNLOAD (FAILED)    → pushed if download throws, with error message
   - Also detects format, patches job record, runs import, deletes temp file.

3. ValidationJobRepository_ADD_THIS_METHOD.java
   - Add findBySourceFileAndNetworkVersionAndStatusIn() to your
     ValidationJobRepository interface (Spring Data — no implementation needed).

4. Neo4jExportService.java  (REPLACE the existing file)
   - FIX A: NEO4J_EXPORT phase no longer shows "RUNNING" after export completes.
     Root cause: a NEO4J_EXPORT_STARTED("RUNNING") entry was pushed at the start
     of runExport() and never updated. A separate NEO4J_EXPORT("COMPLETED") was
     pushed at the end — but the RUNNING entry stayed in phaseHistory forever.
     Fix: removed the NEO4J_EXPORT_STARTED entry. Now a single NEO4J_EXPORT entry
     is pushed only at the end, as COMPLETED or FAILED. Same pattern as all other
     phases (STREAMING_PARSE, ENRICHMENT etc.).
   - FIX B: Removed duplicate variable declaration
       ExportRequest.VersionType vType = req.getVersionType();
     that appeared twice in twoPassExport() and caused a compile error.

Required: @EnableAsync
──────────────────────
Add @EnableAsync to your Spring Boot main class or a @Configuration class
so that @Async on downloadAndImportAsync() actually runs in a thread pool:

    @SpringBootApplication
    @EnableAsync   // ← add this
    public class CimApplication { ... }

Phase history in validation_jobs (after all fixes):
────────────────────────────────────────────────────

  For SFTP/FTP large file import (new flow):
    FTP_DOWNLOAD          RUNNING   ← pushed when download starts
    FTP_DOWNLOAD          COMPLETED ← file size + duration recorded
    STREAMING_PARSE       COMPLETED
    RESOLVING_REFERENCES  COMPLETED
    ENRICHMENT            COMPLETED  (if enrichment enabled for org)
    NEO4J_EXPORT_TRIGGERED COMPLETED (if exportToNeo4j=true)
    NEO4J_EXPORT          COMPLETED  ← single entry, no more stuck RUNNING

  For SFTP/FTP small file (stream path, unchanged):
    STREAMING_PARSE       COMPLETED
    RESOLVING_REFERENCES  COMPLETED
    ...

  For Neo4j export triggered manually or auto:
    NEO4J_EXPORT          COMPLETED  (nodes/rels count, version, mode, duration)
    NEO4J_EXPORT          FAILED     (if export throws, with error message)

neo4j_exports collection:
──────────────────────────
  status field lifecycle (unchanged): PENDING → RUNNING → DONE / FAILED
  The fix above ensures phaseHistory in validation_jobs matches this correctly.

How the async flow works after fixes:
──────────────────────────────────────

  fileName = "BigFile.xml" (300 MB on SFTP)

  Before fix:
    POST /api/import ──► [waits 3–5 min for download] ──► 202
    Phase history: (nothing until download complete)

  After fix:
    POST /api/import ──► 202 immediately (< 1 second)
    Background:
      phaseHistory: FTP_DOWNLOAD(RUNNING) pushed
      [download ...]
      phaseHistory: FTP_DOWNLOAD(COMPLETED, 300MB, 3m24s)
      [parse → resolve → enrich → neo4j export]
      phaseHistory: STREAMING_PARSE(COMPLETED), RESOLVING_REFERENCES(COMPLETED), ...
      phaseHistory: NEO4J_EXPORT(COMPLETED)   ← no more stuck RUNNING entry
    GET /api/jobs/{jobId}/progress ──► poll for live progress

  Duplicate (same fileName + version, already RESOLVED):
    POST /api/import ──► 409 (< 1 second, no SFTP connection opened)
