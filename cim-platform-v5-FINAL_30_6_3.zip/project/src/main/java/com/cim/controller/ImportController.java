package com.cim.controller;

import com.cim.model.mongo.ValidationJob;
import com.cim.repository.ValidationJobRepository;
import com.cim.service.ImportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * Import REST API
 *
 * All endpoints accept version and orgId:
 *   version → X-Network-Version header or ?version= param
 *   orgId   → X-Org-Id header
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ImportController {

    private static final long LARGE = 50L * 1024 * 1024;

    private final ImportService                              importService;
    private final ValidationJobRepository                    jobRepo;
    private final com.cim.repository.RawCimObjectRepository  rawRepo;
    private final com.cim.repository.CimObjectRecordRepository objectRepo;
    private final com.cim.service.ArchiveExtractorService     archiveExtractor;

    public ImportController(ImportService importService,
                              ValidationJobRepository jobRepo,
                              com.cim.repository.RawCimObjectRepository rawRepo,
                              com.cim.repository.CimObjectRecordRepository objectRepo,
                              com.cim.service.ArchiveExtractorService archiveExtractor) {
        this.importService   = importService;
        this.jobRepo         = jobRepo;
        this.rawRepo          = rawRepo;
        this.objectRepo      = objectRepo;
        this.archiveExtractor = archiveExtractor;
    }

    // ─────────────────────────────────────────────────────────────────
    // POST /api/import
    //
    // Headers:
    //   X-Org-Id:          CAISO, ERCOT, SPC  (required)
    //   X-User:            who is importing
    //
    // Params (JSON body):
    //   filePath          ABSOLUTE path to a file on the server's own
    //                      filesystem (or a mounted network/shared drive
    //                      visible to the server process). The server
    //                      reads this file directly — no upload bytes
    //                      are sent over HTTP. Can point to a plain CIM
    //                      file (RDF/JSON/CSV) OR an archive (.zip,
    //                      .tar, .tar.gz, .tgz, .taz).
    //   networkVersion    version label e.g. "DB140-1", "2024-Q1"
    //   fileType          OPTIONAL — "MILSOFT" | "JSON" | "RDF".
    //                     If provided, must match the auto-detected
    //                     format of the file content, or the request
    //                     is rejected with 400 "Invalid file type."
    //
    // SECURITY NOTE (explicit team decision — no base-directory
    // restriction applied): filePath is used as-is to open a file on
    // the server's filesystem. Any path the application process's OS
    // user can read is fair game. This is acceptable ONLY because this
    // platform runs on internal, access-controlled infrastructure and
    // is not exposed as a public API. If this ever changes (e.g. this
    // becomes reachable from outside a trusted network), filePath
    // should be validated against a configured base directory before
    // this method reads anything.
    //
    // ARCHIVE HANDLING:
    //   If filePath points to a supported archive, it is extracted and
    //   EVERY file entry inside it is imported as its OWN separate job
    //   — each gets its own jobId, duplicate-check, and response entry.
    //   A normal (non-archive) file is processed exactly as before.
    //
    // MULTIPART UPLOAD REMOVED:
    //   Browser-based file upload (MultipartFile) is no longer
    //   supported on this endpoint — this was a deliberate replacement,
    //   not an addition, per team request: deployments running on
    //   servers need to trigger imports by pointing at a file already
    //   present on disk (e.g. dropped there by an upstream system),
    //   not by uploading bytes through an HTTP form.
    // ─────────────────────────────────────────────────────────────────
    @PostMapping("/import")
    public ResponseEntity<?> importFile(@RequestBody ImportByPathRequest req,
            @RequestHeader(value="X-Org-Id",      defaultValue="")   String orgId,
            @RequestHeader(value="X-User",         defaultValue="anonymous") String user) {

        String filePath       = req.filePath;
        String networkVersion = req.networkVersion;
        String fileType       = req.fileType;

        if (filePath == null || filePath.isBlank())
            return ResponseEntity.badRequest().body(Map.of("error","filePath is required."));
        if (networkVersion == null || networkVersion.isBlank())
            return ResponseEntity.badRequest().body(Map.of(
                "error","networkVersion is required.",
                "hint", "e.g. 'DB140-1', '2024-Q1', 'SUMMER-PEAK-v2'"));

        // Validate fileType parameter value itself (if provided)
        String requestedType = null;
        if (fileType != null && !fileType.isBlank()) {
            requestedType = fileType.trim().toUpperCase();
            if (!Arrays.asList("MILSOFT", "JSON", "RDF").contains(requestedType)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Invalid fileType '" + fileType + "'.",
                    "hint",  "fileType must be one of: MILSOFT, JSON, RDF (or omit it entirely)."
                ));
            }
        }

        String version = networkVersion.trim();
        String org     = orgId.trim();

        java.io.File sourceFile = new java.io.File(filePath.trim());
        String originalName = sourceFile.getName();

        if (!sourceFile.exists()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "File not found on server.",
                "filePath", filePath));
        }
        if (!sourceFile.isFile()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "filePath does not point to a regular file.",
                "filePath", filePath));
        }
        if (!sourceFile.canRead()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "File exists but is not readable by the server process.",
                "filePath", filePath));
        }

        byte[] rawBytes;
        try {
            rawBytes = java.nio.file.Files.readAllBytes(sourceFile.toPath());
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error","Cannot read file: " + e.getMessage(),
                                 "filePath", filePath));
        }
        if (rawBytes.length == 0)
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "File is empty.",
                "filePath", filePath));

        // ── Archive support: extract and import every entry separately ──
        if (archiveExtractor.isArchive(originalName)) {
            List<com.cim.service.ArchiveExtractorService.ExtractedFile> entries;
            try {
                entries = archiveExtractor.extract(rawBytes, originalName);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Failed to extract archive '" + originalName + "': " + e.getMessage()));
            }
            if (entries.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Archive '" + originalName + "' contains no usable files."));
            }

            List<Map<String, Object>> results = new ArrayList<>();
            for (com.cim.service.ArchiveExtractorService.ExtractedFile entry : entries) {
                ResponseEntity<?> r = importSingleFile(
                        entry.content, entry.name, version, org, user, requestedType);
                Map<String, Object> resultEntry = new LinkedHashMap<>();
                resultEntry.put("fileName", entry.name);
                resultEntry.put("httpStatus", r.getStatusCodeValue());
                resultEntry.put("response", r.getBody());
                results.add(resultEntry);
            }

            return ResponseEntity.ok(Map.of(
                "archiveFileName", originalName,
                "totalFiles",      entries.size(),
                "results",         results
            ));
        }

        // ── Normal (non-archive) file — single import, as before ────────
        return importSingleFile(rawBytes, originalName, version, org, user, requestedType);
    }

    /**
     * Imports a single file's bytes as one job. Used both for a directly
     * uploaded plain file and for each entry extracted from an archive.
     *
     * If requestedType is non-null, validates it against the auto-detected
     * format and returns 400 on mismatch before creating any job.
     */
    private ResponseEntity<?> importSingleFile(byte[] bytes, String fileName,
                                                String version, String org,
                                                String user, String requestedType) {
        String hash;
        try {
            hash = ImportService.sha256(bytes);
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error","Cannot hash file: " + e.getMessage()));
        }

        // Duplicate check: same hash + version + orgId
        List<String> active = Arrays.asList("PENDING","RUNNING","RESOLVED");
        List<ValidationJob> dup = jobRepo
                .findByFileHashAndNetworkVersionAndStatusIn(hash, version, active);
        if (!dup.isEmpty()) {
            ValidationJob ex = dup.get(0);
            return ResponseEntity.status(409).body(Map.of(
                "error",          "Duplicate import rejected.",
                "reason",         "Same file+version already " + ex.getStatus() + ".",
                "existingJobId",  ex.getJobId(),
                "existingStatus", ex.getStatus(),
                "networkVersion", version,
                "orgId",          org,
                "fileName",       fileName,
                "hint",           "Use a different networkVersion or DELETE the existing job."
            ));
        }

        String format = detectFormat(bytes, fileName);

        // fileType validation: claimed type must match auto-detected format
        if (requestedType != null) {
            String detectedClaim = claimedTypeFor(format);
            if (!requestedType.equals(detectedClaim)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error",         "Invalid file type.",
                    "fileName",      fileName,
                    "requestedType", requestedType,
                    "detectedType",  detectedClaim,
                    "hint",          "The file content does not match the declared fileType. " +
                                     "Either correct the fileType parameter or upload the right file."
                ));
            }
        }

        String jobId = UUID.randomUUID().toString();
        ValidationJob job = new ValidationJob(
                jobId, fileName, format, user, version, org);
        job.setFileHash(hash);
        jobRepo.save(job);

        try {
            if (bytes.length <= LARGE) {
                importService.processAndResolve(
                        new java.io.ByteArrayInputStream(bytes),
                        fileName, format, jobId, version, org);
                ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId",          jobId,
                    "status",         done.getStatus(),
                    "networkVersion", version,
                    "orgId",          org,
                    "fileName",       fileName,
                    "format",         format,
                    "totalObjects",   done.getTotalObjects(),
                    "physicalObjects",done.getPhysicalObjects(),
                    "logicalObjects", done.getLogicalObjects(),
                    "stageTimings",   done.getStageTimings(),
                    "links",          links(jobId, version, org)
                ));
            } else {
                importService.processAndResolveAsync(
                        new java.io.ByteArrayInputStream(bytes), fileName,
                        format, jobId, version, org);
                return ResponseEntity.accepted().body(Map.of(
                    "jobId",          jobId,
                    "status",         "PROCESSING",
                    "networkVersion", version,
                    "orgId",          org,
                    "fileName",       fileName,
                    "fileSizeMb",     String.format("%.1f", bytes.length/1048576.0),
                    "links",          links(jobId, version, org)
                ));
            }
        } catch (Exception e) {
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId,
                                 "networkVersion", version, "orgId", org));
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs
    // Filter by version and/or orgId
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/jobs")
    public ResponseEntity<?> listJobs(
            @RequestParam(required=false) String networkVersion,
            @RequestParam(required=false) String orgId) {

        List<ValidationJob> jobs;
        if (networkVersion != null && orgId != null) {
            jobs = jobRepo.findByNetworkVersionAndOrgId(
                    networkVersion.trim(), orgId.trim());
        } else if (networkVersion != null) {
            jobs = jobRepo.findByNetworkVersion(networkVersion.trim());
        } else if (orgId != null) {
            jobs = jobRepo.findByOrgId(orgId.trim());
        } else {
            jobs = jobRepo.findTop10ByOrderBySubmittedAtDesc();
        }
        return ResponseEntity.ok(jobs);
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}
    // Response includes version and orgId
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<?> getJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/progress
    // Response always includes version, orgId, percentSaved
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/progress")
    public ResponseEntity<?> progress(@PathVariable String jobId) {
        return importService.getTracker(jobId)
                .map(t -> {
                    // Enrich live snapshot with version + orgId from job
                    return ResponseEntity.ok(t.snapshot());
                })
                .orElseGet(() -> jobRepo.findByJobId(jobId)
                    .map(j -> ResponseEntity.ok(Map.of(
                        "jobId",          jobId,
                        "status",         j.getStatus(),
                        "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                        "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
                        "parsed",         j.getTotalObjects(),
                        "saved",          j.getTotalObjects(),
                        "percentSaved",   100,
                        "elapsedMs",      j.getProcessingMs(),
                        "elapsedFormatted", com.cim.model.mongo.StageTimings.format(j.getProcessingMs()),
                        "stageTimings",   j.getStageTimings(),
                        "finished",       true,
                        "stage",          j.getStatus()
                    ))).orElse(ResponseEntity.notFound().build()));
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/stats
    // Quick stats with version + orgId context
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/stats")
    public ResponseEntity<?> getJobStats(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId).map(j -> ResponseEntity.ok(Map.of(
            "jobId",          jobId,
            "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
            "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
            "status",         j.getStatus(),
            "totalObjects",   j.getTotalObjects(),
            "physicalObjects",j.getPhysicalObjects(),
            "logicalObjects", j.getLogicalObjects(),
            "pathIssueCount", j.getPathIssueCount(),
            "stageTimings",   j.getStageTimings(),
            "enabledNamespaces", j.getEnabledNamespaces(),
            "links",          links(jobId,
                    j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                    j.getOrgId() != null ? j.getOrgId() : "")
        ))).orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // DELETE /api/jobs/{jobId}
    // ─────────────────────────────────────────────────────────────────
    // ── Alias endpoints — use orgId+version instead of jobId ──────────

    /**
     * Resolve orgId+version → latest jobId.
     * Returns the most recent active job for this orgId+version.
     * Used by alias endpoints and clients that prefer readable identifiers.
     */
    private java.util.Optional<String> resolveJobId(String orgId, String version) {
        return jobRepo
            .findTopByOrgIdAndNetworkVersionOrderBySubmittedAtDesc(
                orgId.trim(), version.trim())
            .map(j -> j.getJobId());
    }

    /**
     * GET /api/cim/orgs/{orgId}/versions/{version}/progress
     * Alias for GET /api/cim/jobs/{jobId}/progress
     * More readable: no need to look up jobId first.
     */
    @GetMapping("/orgs/{orgId}/versions/{version}/progress")
    public ResponseEntity<?> progressByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .map(jobId -> {
                    com.cim.streaming.ProgressTracker t = importService.getTracker(jobId);
                    if (t != null) {
                        // Tracker active (import running) — wrap snapshot with jobId
                        com.cim.streaming.ProgressSnapshot snap = t.snapshot();
                        java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                        r.put("jobId",           jobId);   // REQ 1: always include jobId
                        r.put("orgId",           orgId);
                        r.put("networkVersion",  version);
                        r.put("stage",           snap.getStage());
                        r.put("parsed",          snap.getParsed());
                        r.put("saved",           snap.getSaved());
                        r.put("percentSaved",    snap.getPercentSaved());
                        r.put("elapsedFormatted",snap.getElapsedFormatted());
                        r.put("parseRatePerSec", snap.getParseRatePerSec());
                        r.put("finished",        snap.isFinished());
                        r.put("detail",          snap.getDetail());
                        return ResponseEntity.ok(r);
                    }
                    return jobRepo.findByJobId(jobId)
                            .map(j -> {
                                java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                                r.put("jobId",           jobId);  // REQ 1: always include
                                r.put("orgId",           orgId);
                                r.put("networkVersion",  version);
                                r.put("status",          j.getStatus());
                                r.put("percentSaved",    100);
                                r.put("parsed",          j.getTotalObjects());
                                r.put("saved",           j.getTotalObjects());
                                r.put("finished",        true);
                                r.put("elapsedFormatted",
                                        j.getStageTimings() != null
                                        ? j.getStageTimings().getTotalFormatted() : null);
                                r.put("stageTimings",    j.getStageTimings());
                                return ResponseEntity.ok(r);
                            })
                            .orElse(ResponseEntity.notFound().build());
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/cim/orgs/{orgId}/versions/{version}
     * Alias for GET /api/cim/jobs/{jobId}
     */
    @GetMapping("/orgs/{orgId}/versions/{version}")
    public ResponseEntity<?> jobByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .flatMap(jobId -> jobRepo.findByJobId(jobId))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/cim/orgs/{orgId}/versions/{version}/stats
     * Alias for GET /api/cim/jobs/{jobId}/stats
     */
    @GetMapping("/orgs/{orgId}/versions/{version}/stats")
    public ResponseEntity<?> statsByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .map(jobId -> {
                    long total    = objectRepo.countByJobId(jobId);
                    long physical = objectRepo.countByJobIdAndCategory(jobId, "PHYSICAL");
                    long logical  = objectRepo.countByJobIdAndCategory(jobId, "LOGICAL");
                    java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                    r.put("orgId",          orgId);
                    r.put("networkVersion", version);
                    r.put("jobId",          jobId);
                    r.put("total",          total);
                    r.put("physical",       physical);
                    r.put("logical",        logical);
                    return ResponseEntity.ok(r);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/cim/orgs/{orgId}/versions
     * List all versions imported for an organisation.
     * More useful than listing by jobId.
     */
    @GetMapping("/orgs/{orgId}/versions")
    public ResponseEntity<?> listVersions(@PathVariable String orgId) {
        java.util.List<com.cim.model.mongo.ValidationJob> jobs =
                jobRepo.findByOrgId(orgId.trim());
        java.util.List<java.util.Map<String,Object>> versions = new java.util.ArrayList<>();
        for (com.cim.model.mongo.ValidationJob j : jobs) {
            java.util.Map<String,Object> v = new java.util.LinkedHashMap<>();
            v.put("jobId",          j.getJobId());
            v.put("networkVersion", j.getNetworkVersion());
            v.put("status",         j.getStatus());
            v.put("totalObjects",   j.getTotalObjects());
            v.put("totalFormatted", j.getStageTimings() != null
                    ? j.getStageTimings().getTotalFormatted() : null);
            v.put("submittedAt",    j.getSubmittedAt());
            versions.add(v);
        }
        return ResponseEntity.ok(Map.of(
            "orgId",    orgId,
            "total",    versions.size(),
            "versions", versions
        ));
    }

    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<?> deleteJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId).map(j -> {
            // Delete from all three collections
            jobRepo.delete(j);
            rawRepo.deleteByJobId(jobId);    // raw_objects
            // cim_objects deleted by CimObjectRecordRepository in ImportService
            return ResponseEntity.ok(Map.of(
                "message",          "Job " + jobId + " deleted.",
                "networkVersion",   j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                "orgId",            j.getOrgId() != null ? j.getOrgId() : "",
                "collectionsCleared", java.util.Arrays.asList(
                    "validation_jobs", "raw_objects", "cim_objects"),
                "hint",             "You can now re-import the same file+version."));
        }).orElse(ResponseEntity.notFound().build());
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    /**
     * Auto-detects file format from content (and filename as a fallback hint).
     * Returns one of: "RDF_XML", "JSON_LD", "MILSOFT_CSV".
     */
    private String detectFormat(byte[] bytes, String name) {
        String h = new String(bytes, 0, Math.min(512, bytes.length));
        if (h.contains("rdf:RDF") || h.contains("xmlns:cim")) return "RDF_XML";
        if (h.contains("@context") || h.contains("@graph"))   return "JSON_LD";
        if (name != null && name.toLowerCase().endsWith(".csv")) return "MILSOFT_CSV";
        return "RDF_XML";
    }

    /**
     * Maps an internal format constant to the public fileType vocabulary
     * used by the fileType request parameter ("MILSOFT" | "JSON" | "RDF"),
     * so the requested vs detected types can be compared directly.
     */
    private String claimedTypeFor(String internalFormat) {
        switch (internalFormat) {
            case "RDF_XML":      return "RDF";
            case "JSON_LD":      return "JSON";
            case "MILSOFT_CSV":  return "MILSOFT";
            default:             return internalFormat;
        }
    }

    private Map<String, String> links(String jobId, String version, String orgId) {
        return Map.of(
            "progress",   "/api/jobs/" + jobId + "/progress",
            "stats",      "/api/jobs/" + jobId + "/stats",
            "objects",    "/api/jobs/" + jobId + "/objects",
            "pathIssues", "/api/jobs/" + jobId + "/objects/path-issues",
            "required",   "/api/jobs/" + jobId + "/objects/required/summary",
            "byVersion",  "/api/jobs?networkVersion=" + version + "&orgId=" + orgId
        );
    }

    /**
     * Request body for POST /api/import.
     *
     * filePath must be an ABSOLUTE path the server process can read.
     * Per explicit team decision, this is NOT restricted to a configured
     * base directory — any path readable by the server's OS user is
     * accepted. See the security note above importFile() for context.
     */
    public static class ImportByPathRequest {
        public String filePath;
        public String networkVersion;
        public String fileType; // optional: MILSOFT | JSON | RDF
    }
}
