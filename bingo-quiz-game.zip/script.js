// ---------------------------------------------------------
// QUESTION DATA (25 questions, one per tile)
// Each question: { text, options: [4], correctIndex }
// ---------------------------------------------------------
const questions = [
  { text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit?", options: ["Sed do eiusmod", "Tempor incididunt", "Ut labore et dolore", "Magna aliqua"], correctIndex: 2 },
  { text: "Ut enim ad minim veniam, quis nostrud exercitation?", options: ["Ullamco laboris", "Nisi ut aliquip", "Ex ea commodo", "Consequat duis"], correctIndex: 1 },
  { text: "Duis aute irure dolor in reprehenderit in voluptate?", options: ["Velit esse cillum", "Dolore eu fugiat", "Nulla pariatur", "Excepteur sint"], correctIndex: 0 },
  { text: "Occaecat cupidatat non proident, sunt in culpa qui?", options: ["Officia deserunt", "Mollit anim id", "Est laborum sed", "Perspiciatis unde"], correctIndex: 3 },
  { text: "Sed ut perspiciatis unde omnis iste natus error sit?", options: ["Voluptatem accusantium", "Doloremque laudantium", "Totam rem aperiam", "Eaque ipsa quae"], correctIndex: 2 },
  { text: "Ab illo inventore veritatis et quasi architecto beatae?", options: ["Vitae dicta sunt", "Explicabo nemo enim", "Ipsam voluptatem quia", "Voluptas sit aspernatur"], correctIndex: 0 },
  { text: "Aut odit aut fugit, sed quia consequuntur magni dolores?", options: ["Eos qui ratione", "Voluptatem sequi nesciunt", "Neque porro quisquam", "Est qui dolorem"], correctIndex: 3 },
  { text: "Ipsum quia dolor sit amet consectetur adipisci velit?", options: ["Sed quia non numquam", "Eius modi tempora", "Incidunt ut labore", "Dolore magnam aliquam"], correctIndex: 1 },
  { text: "Quis autem vel eum iure reprehenderit qui in ea?", options: ["Voluptate velit esse", "Quam nihil molestiae", "Consequatur vel illum", "Qui dolorem eum fugiat"], correctIndex: 2 },
  { text: "At vero eos et accusamus et iusto odio dignissimos?", options: ["Ducimus qui blanditiis", "Praesentium voluptatum", "Deleniti atque corrupti", "Quos dolores et quas"], correctIndex: 0 },
  { text: "Molestias excepturi sint occaecati cupiditate non provident?", options: ["Similique sunt in culpa", "Qui officia deserunt", "Mollitia animi id est", "Laborum et dolorum fuga"], correctIndex: 3 },
  { text: "Et harum quidem rerum facilis est et expedita distinctio?", options: ["Nam libero tempore", "Cum soluta nobis", "Est eligendi optio", "Cumque nihil impedit"], correctIndex: 1 },
  { text: "Quo minus id quod maxime placeat facere possimus?", options: ["Omnis voluptas assumenda", "Est omnis dolor repellendus", "Temporibus autem quibusdam", "Officiis debitis aut"], correctIndex: 2 },
  { text: "Rerum necessitatibus saepe eveniet ut et voluptates?", options: ["Repudiandae sint et molestiae", "Non recusandae itaque earum", "Rerum hic tenetur a", "Sapiente delectus ut aut"], correctIndex: 0 },
  { text: "Reiciendis voluptatibus maiores alias consequatur aut?", options: ["Perferendis doloribus asperiores", "Repellat minus nam est", "Suscipit laboriosam nisi", "Aliquid ex ea commodi"], correctIndex: 3 },
  { text: "Consequatur quis autem vel eum iure reprehenderit?", options: ["Qui in ea voluptate", "Velit esse quam nihil", "Molestiae consequatur vel", "Illum qui dolorem"], correctIndex: 1 },
  { text: "Eum fugiat quo voluptas nulla pariatur at vero?", options: ["Eos et accusamus", "Et iusto odio dignissimos", "Ducimus qui blanditiis", "Praesentium voluptatum deleniti"], correctIndex: 2 },
  { text: "Atque corrupti quos dolores et quas molestias?", options: ["Excepturi sint occaecati", "Cupiditate non provident", "Similique sunt in culpa", "Qui officia deserunt mollitia"], correctIndex: 0 },
  { text: "Animi id est laborum et dolorum fuga et harum?", options: ["Quidem rerum facilis est", "Expedita distinctio nam libero", "Tempore cum soluta nobis", "Est eligendi optio cumque"], correctIndex: 3 },
  { text: "Nihil impedit quo minus id quod maxime placeat?", options: ["Facere possimus omnis", "Voluptas assumenda est omnis", "Dolor repellendus temporibus", "Autem quibusdam et aut"], correctIndex: 1 },
  { text: "Officiis debitis aut rerum necessitatibus saepe eveniet?", options: ["Ut et voluptates repudiandae", "Sint et molestiae non", "Recusandae itaque earum rerum", "Hic tenetur a sapiente"], correctIndex: 2 },
  { text: "Delectus ut aut reiciendis voluptatibus maiores alias?", options: ["Consequatur aut perferendis", "Doloribus asperiores repellat", "Minus nam est suscipit", "Laboriosam nisi aliquid ex"], correctIndex: 0 },
  { text: "Ea commodi consequatur quis autem vel eum iure?", options: ["Reprehenderit qui in ea", "Voluptate velit esse quam", "Nihil molestiae consequatur", "Vel illum qui dolorem"], correctIndex: 3 },
  { text: "Eum fugiat quo voluptas nulla pariatur excepteur sint?", options: ["Occaecat cupidatat non proident", "Sunt in culpa qui", "Officia deserunt mollit anim", "Id est laborum sed"], correctIndex: 1 },
  { text: "Perspiciatis unde omnis iste natus error voluptatem?", options: ["Accusantium doloremque laudantium", "Totam rem aperiam eaque", "Ipsa quae ab illo", "Inventore veritatis et quasi"], correctIndex: 2 }
];

const LETTERS = ["B", "I", "N", "G", "O"];

// tile state: null = unanswered, true = correct(green), false = incorrect(red)
const tileState = new Array(25).fill(null);
let selectedTile = null;
const completedLines = new Set(); // stores identifiers of lines already struck
let strikeCount = 0;
let gameWon = false;

const gridEl = document.getElementById("grid");
const questionArea = document.getElementById("questionArea");
const winMessage = document.getElementById("winMessage");

// ---------------------------------------------------------
// BUILD GRID
// ---------------------------------------------------------
function buildGrid() {
  gridEl.innerHTML = "";
  for (let i = 0; i < 25; i++) {
    const tile = document.createElement("div");
    tile.classList.add("tile");
    tile.dataset.index = i;
    tile.textContent = i + 1;
    tile.addEventListener("click", () => onTileClick(i));
    gridEl.appendChild(tile);
  }
}

function onTileClick(index) {
  if (tileState[index] !== null || gameWon) return; // locked tile, or game over
  selectedTile = index;
  renderQuestion(index);
  highlightSelected(index);
}

function highlightSelected(index) {
  document.querySelectorAll(".tile").forEach(t => t.classList.remove("selected"));
  const el = gridEl.querySelector(`[data-index="${index}"]`);
  if (el) el.classList.add("selected");
}

// ---------------------------------------------------------
// RENDER QUESTION PANEL
// ---------------------------------------------------------
function renderQuestion(index) {
  const q = questions[index];

  const optionsHtml = q.options.map((opt, i) => `
    <div class="option-row">
      <label>
        <input type="radio" name="option" value="${i}">
        ${opt}
      </label>
    </div>
  `).join("");

  questionArea.innerHTML = `
    <h2>Tile ${index + 1}</h2>
    <p>${q.text}</p>
    ${optionsHtml}
    <button class="submit-btn" id="submitBtn">Submit</button>
    <div id="resultMsg"></div>
  `;

  document.getElementById("submitBtn").addEventListener("click", () => submitAnswer(index));
}

// ---------------------------------------------------------
// HANDLE SUBMISSION
// ---------------------------------------------------------
function submitAnswer(index) {
  const selected = document.querySelector('input[name="option"]:checked');
  if (!selected) {
    alert("Please select an option before submitting.");
    return;
  }

  const chosenIndex = parseInt(selected.value, 10);
  const q = questions[index];
  const isCorrect = chosenIndex === q.correctIndex;

  tileState[index] = isCorrect;

  // update tile visual + lock it
  const tileEl = gridEl.querySelector(`[data-index="${index}"]`);
  tileEl.classList.remove("selected");
  tileEl.classList.add(isCorrect ? "correct" : "incorrect");

  // disable inputs and submit button
  document.querySelectorAll('input[name="option"]').forEach(inp => inp.disabled = true);
  document.getElementById("submitBtn").disabled = true;

  const resultMsg = document.getElementById("resultMsg");
  resultMsg.innerHTML = `
    <p class="result-msg ${isCorrect ? "correct-text" : "incorrect-text"}">
      ${isCorrect ? "Correct!" : "Incorrect."}
    </p>
    <p class="correct-answer-note">Correct answer: ${q.options[q.correctIndex]}</p>
  `;

  if (isCorrect) {
    checkForNewLines();
  }
}

// ---------------------------------------------------------
// LINE CHECKING (rows, columns, diagonals)
// ---------------------------------------------------------
function getAllLines() {
  const lines = [];

  // rows
  for (let r = 0; r < 5; r++) {
    const cells = [];
    for (let c = 0; c < 5; c++) cells.push(r * 5 + c);
    lines.push({ id: `row-${r}`, cells });
  }

  // columns
  for (let c = 0; c < 5; c++) {
    const cells = [];
    for (let r = 0; r < 5; r++) cells.push(r * 5 + c);
    lines.push({ id: `col-${c}`, cells });
  }

  // diagonal top-left -> bottom-right
  lines.push({ id: "diag-main", cells: [0, 6, 12, 18, 24] });

  // diagonal top-right -> bottom-left
  lines.push({ id: "diag-anti", cells: [4, 8, 12, 16, 20] });

  return lines;
}

function checkForNewLines() {
  if (gameWon) return;

  const lines = getAllLines();

  for (const line of lines) {
    if (completedLines.has(line.id)) continue; // already struck earlier

    const allGreen = line.cells.every(idx => tileState[idx] === true);
    if (allGreen) {
      completedLines.add(line.id);
      strikeNextLetter();
      if (gameWon) break; // stop once won
    }
  }
}

function strikeNextLetter() {
  if (strikeCount >= 5) return;

  const letter = LETTERS[strikeCount];
  const letterEl = document.querySelector(`.letter[data-letter="${letter}"]`);
  if (letterEl) letterEl.classList.add("struck");

  strikeCount++;

  if (strikeCount === 5) {
    gameWon = true;
    winMessage.classList.remove("hidden");
  }
}

// ---------------------------------------------------------
// INIT
// ---------------------------------------------------------
buildGrid();
