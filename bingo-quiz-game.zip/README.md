# BINGO Quiz Game

A simple HTML/CSS/vanilla JavaScript BINGO quiz game built per the assignment spec.

## Files
- `index.html` — page structure (left panel: BINGO grid, right panel: question/answer area)
- `style.css` — basic functional styling
- `script.js` — game logic: 25 questions, tile locking, correct/incorrect coloring, BINGO line detection, letter-strike sequencing

## How it works
- Click any of the 25 tiles to load its question in the right panel.
- Pick an option and hit Submit — the tile locks, turns green (correct) or red (incorrect), and the correct answer is shown for reference.
- Only green tiles count toward BINGO lines (rows, columns, both diagonals).
- Each time a *new* line is completed, the next letter (B → I → N → G → O) is struck.
- Once all five letters are struck, a win message appears.

## GenAI usage disclosure

*(Fill in with your actual prompts/process before submitting — this is a template.)*

| Prompt(s) Used | What did you verify manually before shipping GenAI-assisted work? | What did GenAI do poorly or incorrectly, and how did you correct it? |
| --- | --- | --- |
| e.g. "Build an HTML/CSS/JS BINGO quiz game with 25 tiles, per this spec..." | Manually clicked through all 25 tiles, tested every row/column/diagonal combination, confirmed letters strike only once per line, confirmed win condition fires at 5 lines. | e.g. Note any logic bugs you found and fixed, edge cases the AI missed, or styling tweaks you made. |
