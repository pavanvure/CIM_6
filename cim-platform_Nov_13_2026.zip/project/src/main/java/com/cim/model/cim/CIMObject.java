package com.cim.model.cim;

import java.util.*;

/**
 * Universal CIM object — format-agnostic common model.
 * Populated by all parsers (RDF/XML, JSON-LD, CSV).
 */
public class CIMObject {
    private String cimType;
    private String rdfId;
    private String mrid;
    private String name;
    private String sourceFormat;
    private String sourceFile;
    private String orgId;

    private final Map<String, String>    attributes = new LinkedHashMap<>();
    private final Map<String, String>    references = new LinkedHashMap<>();
    private final Map<String, CIMObject> resolved   = new LinkedHashMap<>();

    public CIMObject(String cimType, String rdfId) {
        this.cimType = cimType;
        this.rdfId   = rdfId;
        this.mrid    = rdfId;
    }

    public void setAttribute(String key, String value) {
        if (key == null || value == null) return;
        attributes.put(key, value);
        if ("IdentifiedObject.name".equals(key)) this.name = value;
        if ("mRID".equalsIgnoreCase(key) || "IdentifiedObject.mRID".equals(key)) this.mrid = value;
    }

    public void addReference(String key, String targetRdfId) {
        if (key != null && targetRdfId != null) references.put(key, targetRdfId);
    }

    public void addResolved(String key, CIMObject target) {
        if (key != null && target != null) resolved.put(key, target);
    }

    public boolean hasResolved(String key)   { return resolved.containsKey(key); }
    public CIMObject getResolved(String key) { return resolved.get(key); }
    public boolean hasReferences()           { return !references.isEmpty(); }
    public String getAttribute(String key)   { return attributes.get(key); }

    public String getCimType()              { return cimType; }
    public String getRdfId()                { return rdfId; }
    public String getMrid()                 { return mrid; }
    public void   setMrid(String v)         { this.mrid = v; }
    public String getName()                 { return name != null ? name : mrid; }
    public String getSourceFormat()         { return sourceFormat; }
    public void   setSourceFormat(String v) { this.sourceFormat = v; }
    public String getSourceFile()           { return sourceFile; }
    public void   setSourceFile(String v)   { this.sourceFile = v; }
    public String getOrgId()                { return orgId; }
    public void   setOrgId(String v)        { this.orgId = v; }
    public Map<String, String>    getAttributes() { return attributes; }
    public Map<String, String>    getReferences() { return references; }
    public Map<String, CIMObject> getResolved()   { return resolved; }

    /**
     * Releases the attribute, reference, and resolved-object maps after the
     * records have been built from this object.
     *
     * Call this immediately after {@code toRecord()} and {@code toRawObject()}
     * are done with the object. The maps are typically the largest part of heap
     * during streaming — clearing them lets the GC reclaim memory before the
     * next batch is built, cutting peak heap by ~40–60% on large CIM files.
     *
     * After calling this the object must NOT be used further.
     */
    public void clearMaps() {
        attributes.clear();
        references.clear();
        resolved.clear();
    }
}
