package com.cim.controller;

import com.cim.model.mongo.ValidationJob;
import com.cim.repository.ValidationJobRepository;
import com.cim.service.ImportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.core.env.Environment;

import java.util.*;
import io.swagger.annotations.*;
import com.cim.model.api.ApiResponseModels.*;

/**
 * Import REST API
 *
 * All endpoints accept version and orgId:
 *   version → X-Network-Version header or ?version= param
 *   orgId   → X-Org-Id header
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ImportController {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(ImportController.class);

    private static final long LARGE = 50L * 1024 * 1024;

    private final ImportService                              importService;
    private final ValidationJobRepository                    jobRepo;
    private final com.cim.repository.RawCimObjectRepository  rawRepo;
    private final com.cim.repository.CimObjectRecordRepository objectRepo;
    private final com.cim.service.ArchiveExtractorService     archiveExtractor;
    private final com.cim.service.FtpFileService              ftpFileService;
    private final Environment                                 env;

    public ImportController(ImportService importService,
                              ValidationJobRepository jobRepo,
                              com.cim.repository.RawCimObjectRepository rawRepo,
                              com.cim.repository.CimObjectRecordRepository objectRepo,
                              com.cim.service.ArchiveExtractorService archiveExtractor,
                              com.cim.service.FtpFileService ftpFileService,
                              org.springframework.core.env.Environment env) {
        this.importService   = importService;
        this.jobRepo         = jobRepo;
        this.rawRepo          = rawRepo;
        this.objectRepo      = objectRepo;
        this.archiveExtractor = archiveExtractor;
        this.ftpFileService  = ftpFileService;
        this.env             = env;
    }

    // ─────────────────────────────────────────────────────────────────
    // POST /api/import
    //
    // Headers:
    //   X-Org-Id:          CAISO, ERCOT, SPC  (required)
    //   X-User:            who is importing
    //
    // Params (JSON body):
    //   filePath          ABSOLUTE path to a file on the server's own
    //                      filesystem (or a mounted network/shared drive
    //                      visible to the server process). The server
    //                      reads this file directly — no upload bytes
    //                      are sent over HTTP. Can point to a plain CIM
    //                      file (RDF/JSON/CSV) OR an archive (.zip,
    //                      .tar, .tar.gz, .tgz, .taz).
    //   networkVersion    version label e.g. "DB140-1", "2024-Q1"
    //   fileType          OPTIONAL — "MILSOFT" | "JSON" | "RDF".
    //                     If provided, must match the auto-detected
    //                     format of the file content, or the request
    //                     is rejected with 400 "Invalid file type."
    //
    // SECURITY NOTE (explicit team decision — no base-directory
    // restriction applied): filePath is used as-is to open a file on
    // the server's filesystem. Any path the application process's OS
    // user can read is fair game. This is acceptable ONLY because this
    // platform runs on internal, access-controlled infrastructure and
    // is not exposed as a public API. If this ever changes (e.g. this
    // becomes reachable from outside a trusted network), filePath
    // should be validated against a configured base directory before
    // this method reads anything.
    //
    // ARCHIVE HANDLING:
    //   If filePath points to a supported archive, it is extracted and
    //   EVERY file entry inside it is imported as its OWN separate job
    //   — each gets its own jobId, duplicate-check, and response entry.
    //   A normal (non-archive) file is processed exactly as before.
    //
    // MULTIPART UPLOAD REMOVED:
    //   Browser-based file upload (MultipartFile) is no longer
    //   supported on this endpoint — this was a deliberate replacement,
    //   not an addition, per team request: deployments running on
    //   servers need to trigger imports by pointing at a file already
    //   present on disk (e.g. dropped there by an upstream system),
    //   not by uploading bytes through an HTTP form.
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Import a CIM file by server-side path", notes = "Pass filePath pointing to a file readable by the server. Accepts plain CIM files (RDF/XML, JSON-LD, Milsoft CSV) or archives (.zip, .tar, .tar.gz, .tgz, .taz). Archives produce one import job per extracted file.", response = ImportJobResponse.class)
    @ApiResponses({@ApiResponse(code=200, message="Imported synchronously", response=ImportJobResponse.class), @ApiResponse(code=202, message="Import started async", response=AsyncImportResponse.class), @ApiResponse(code=400, message="File not found / invalid fileType / empty archive"), @ApiResponse(code=409, message="Duplicate import")})
    @PostMapping("/import")
    public ResponseEntity<?> importFile(@RequestBody ImportByPathRequest req,
            @RequestHeader(value="X-Org-Id",      defaultValue="")   String orgId,
            @RequestHeader(value="X-User",         defaultValue="anonymous") String user) {

        String  networkVersion = req.networkVersion;
        String  fileType       = req.fileType;
        boolean exportToNeo4j  = req.exportToNeo4j == null || req.exportToNeo4j;

        // Resolve filePath:
        //   1. filePath given explicitly → use as-is (absolute server path, backward compat)
        //   2. fileName given → stream or download from FTP/SFTP server using cim.ftp.* config
        //      • For files ≤ LARGE (50 MB): stream directly from FTP — no temp file, no disk write.
        //        The FTP socket stays open while ImportService parses. Quick and memory-efficient.
        //      • For files > LARGE (50 MB): fire async download + import, return 202 IMMEDIATELY.
        //        Caller polls GET /api/jobs/{jobId} for status.
        //        Before starting download, a fast duplicate pre-check by fileName+version is done
        //        to avoid downloading a file that will be rejected as duplicate anyway.
        String filePath    = req.filePath;
        String ftpTempFile = null;   // non-null only for large FTP files that were downloaded
        boolean ftpStream  = false;  // true when we will stream directly (small file path)

        if ((filePath == null || filePath.isBlank()) && req.fileName != null && !req.fileName.isBlank()) {
            String name = req.fileName.trim();
            try {
                // Query the FTP/SFTP server for the remote file size.
                long remoteSize = ftpFileService.remoteFileSize(name);
                log.info("FTP fileName={} remoteSize={} bytes", name, remoteSize);

                if (remoteSize >= 0 && remoteSize <= LARGE) {
                    // Small file — safe to stream directly
                    ftpStream = true;
                    filePath = "ftp://" + name;   // placeholder — used only by the stream block below
                } else {
                    // ── Large file (or unknown size): async download + import ──────────────
                    // Return 202 immediately. Download and import run in a background thread.
                    // The caller polls GET /api/jobs/{jobId} for progress and final status.

                    String fVersion = networkVersion != null ? networkVersion.trim() : "";
                    String fOrg     = orgId != null ? orgId.trim() : "";
                    final boolean fExport = req.exportToNeo4j == null || req.exportToNeo4j;

                    // ── Fast duplicate pre-check ──────────────────────────────────────────
                    // We don't have the file hash yet (requires reading the full file),
                    // so we check by fileName + networkVersion as a quick guard.
                    // This avoids downloading a large file only to reject it as duplicate.
                    if (!fVersion.isBlank()) {
                        List<ValidationJob> existing = jobRepo
                            .findBySourceFileAndNetworkVersionAndStatusIn(
                                name, fVersion,
                                Arrays.asList("PENDING", "RUNNING", "RESOLVED", "PROCESSING"));
                        if (!existing.isEmpty()) {
                            ValidationJob ex = existing.get(0);
                            return ResponseEntity.status(409).body(Map.of(
                                "error",          "Duplicate import rejected.",
                                "reason",         "Same fileName+version already " + ex.getStatus() + ".",
                                "existingJobId",  ex.getJobId(),
                                "existingStatus", ex.getStatus(),
                                "networkVersion", fVersion,
                                "orgId",          fOrg,
                                "fileName",       name,
                                "hint",           "Use a different networkVersion or DELETE the existing job."
                            ));
                        }
                    }

                    // ── fileType validation + extension pre-check (before download) ──────
                    // Step 1: validate the fileType param value itself
                    String rt = null;
                    if (fileType != null && !fileType.isBlank()) {
                        rt = fileType.trim().toUpperCase();
                        if (!Arrays.asList("MILSOFT", "JSON", "RDF").contains(rt)) {
                            return ResponseEntity.badRequest().body(Map.of(
                                "error", "Invalid fileType '" + fileType + "'.",
                                "hint",  "fileType must be one of: MILSOFT, JSON, RDF (or omit it entirely)."));
                        }
                    }
                    // Step 2: if fileType was provided, cross-check against the file extension.
                    // We cannot read the file content yet (it's still on the FTP server and
                    // may be hundreds of MB). The extension is a cheap early guard — it catches
                    // obvious mismatches (e.g. fileType=MILSOFT but file is DB135.xml) before
                    // we spin up a background thread and start a multi-minute download.
                    // The async thread does a definitive content-based check after download.
                    if (rt != null) {
                        String extFromName = detectFormatFromExtensionOnly(name);
                        String extClaimed  = claimedTypeFor(extFromName);
                        if (!rt.equals(extClaimed)) {
                            return ResponseEntity.badRequest().body(Map.of(
                                "error",         "fileType mismatch (extension pre-check).",
                                "fileName",      name,
                                "requestedType", rt,
                                "detectedFromExtension", extClaimed,
                                "hint", "The file extension of '" + name + "' suggests " + extClaimed
                                      + " but fileType=" + rt + " was declared. "
                                      + "Either correct fileType or verify you are importing the right file. "
                                      + "Note: the async thread will also verify file content after download."));
                        }
                    }
                    final String resolvedFileType = rt; // pass into async thread

                    // Save job record immediately — status PROCESSING so caller can poll
                    String jobId = java.util.UUID.randomUUID().toString();
                    // Use extension-detected format as initial guess; async thread will correct it
                    String initialFormat = detectFormat(new byte[0], name);
                    ValidationJob job = new ValidationJob(jobId, name, initialFormat, user, fVersion, fOrg);
                    job.setStatus("PROCESSING");
                    jobRepo.save(job);

                    log.info("FTP fileName={}: size {}MB — async download+import started jobId={}",
                            name,
                            remoteSize < 0 ? "unknown" : String.format("%.1f", remoteSize / 1048576.0),
                            jobId);

                    // Fire background download + import — HTTP thread returns now
                    importService.downloadAndImportAsync(
                            ftpFileService, name, jobId, fVersion, fOrg, fExport, resolvedFileType);

                    return ResponseEntity.accepted().body(Map.of(
                        "jobId",          jobId,
                        "status",         "PROCESSING",
                        "networkVersion", fVersion,
                        "orgId",          fOrg,
                        "fileName",       name,
                        "fileSizeMb",     remoteSize < 0 ? "unknown"
                                            : String.format("%.1f", remoteSize / 1048576.0),
                        "message",        "Large file download started in background. Poll links.progress for status.",
                        "links",          links(jobId, fVersion, fOrg)
                    ));
                }
            } catch (IllegalStateException e) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "FTP not configured: " + e.getMessage(),
                    "hint",  "Set cim.ftp.host, cim.ftp.username, cim.ftp.password, cim.ftp.remote-dir in application.yml"));
            } catch (IllegalArgumentException e) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", e.getMessage(), "fileName", name));
            } catch (java.io.IOException e) {
                log.error("FTP error for fileName={}: {}", name, e.getMessage());
                return ResponseEntity.status(502).body(Map.of(
                    "error",    "FTP error: " + e.getMessage(),
                    "fileName", name));
            }
        }

        if (filePath == null || filePath.isBlank())
            return ResponseEntity.badRequest().body(Map.of(
                "error", "Either filePath or fileName is required.",
                "hint",  "Use filePath for an absolute server path, or fileName to stream/download from the configured FTP server."));
        if (networkVersion == null || networkVersion.isBlank())
            return ResponseEntity.badRequest().body(Map.of(
                "error","networkVersion is required.",
                "hint", "e.g. 'DB140-1', '2024-Q1', 'SUMMER-PEAK-v2'"));

        // Validate fileType parameter value itself (if provided)
        String requestedType = null;
        if (fileType != null && !fileType.isBlank()) {
            requestedType = fileType.trim().toUpperCase();
            if (!Arrays.asList("MILSOFT", "JSON", "RDF").contains(requestedType)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Invalid fileType '" + fileType + "'.",
                    "hint",  "fileType must be one of: MILSOFT, JSON, RDF (or omit it entirely)."
                ));
            }
        }

        String version = networkVersion.trim();
        String org     = orgId.trim();
        String effectiveOrg = org.isBlank() ? "" : org;
        boolean exportNeo4j = req.exportToNeo4j == null || req.exportToNeo4j;
        String  neo4jConfigId = (req.neo4jConfigId != null && !req.neo4jConfigId.isBlank())
                ? req.neo4jConfigId.trim() : null;

        // ── Version-type validation ────────────────────────────────────────
        // If any version type field is provided, apply all three rules.
        // If none are provided at all, fall through to the legacy exportToNeo4j behaviour.
        boolean anyVersionTypeProvided = (req.fullVersion != null && !req.fullVersion.isBlank())
                || (req.sanitisedVersion != null && !req.sanitisedVersion.isBlank())
                || (req.rationalisedVersion != null && !req.rationalisedVersion.isBlank());
        if (anyVersionTypeProvided) {
            ResponseEntity<?> vErr = validateVersionTypes(req);
            if (vErr != null) return vErr;
        }

        String fullVersion        = (req.fullVersion != null && !req.fullVersion.isBlank())
                ? req.fullVersion.trim() : null;
        String sanitisedVersion   = (req.sanitisedVersion != null && !req.sanitisedVersion.isBlank())
                ? req.sanitisedVersion.trim() : null;
        String rationalisedVersion = (req.rationalisedVersion != null && !req.rationalisedVersion.isBlank())
                ? req.rationalisedVersion.trim() : null;

        // ── FTP STREAM path: fileName supplied, small file — stream directly from FTP ───
        if (ftpStream && req.fileName != null) {
            String name = req.fileName.trim();
            String jobId = java.util.UUID.randomUUID().toString();
            try (java.io.InputStream ftpIn = ftpFileService.openStream(name)) {
                // Peek at the first 512 bytes for format detection, then reset
                java.io.BufferedInputStream buf = new java.io.BufferedInputStream(ftpIn, 65536);
                buf.mark(512);
                byte[] hdr = new byte[512];
                int n = buf.read(hdr, 0, 512);
                buf.reset();
                byte[] headerBytes = n > 0 ? java.util.Arrays.copyOf(hdr, n) : new byte[0];
                String format = detectFormat(headerBytes, name);

                if (requestedType != null && !requestedType.equals(claimedTypeFor(format))) {
                    return ResponseEntity.badRequest().body(Map.of(
                        "error",         "Invalid file type.",
                        "fileName",      name,
                        "requestedType", requestedType,
                        "detectedType",  claimedTypeFor(format)));
                }

                // ── Duplicate pre-check for small streamed files ──────────────────────
                // Use fileName+version as a fast guard (no hash yet — we'd need to buffer
                // the whole stream which defeats the purpose of streaming).
                if (!version.isBlank()) {
                    List<ValidationJob> existing = jobRepo
                        .findBySourceFileAndNetworkVersionAndStatusIn(
                            name, version,
                            Arrays.asList("PENDING", "RUNNING", "RESOLVED", "PROCESSING"));
                    if (!existing.isEmpty()) {
                        ValidationJob ex = existing.get(0);
                        return ResponseEntity.status(409).body(Map.of(
                            "error",          "Duplicate import rejected.",
                            "reason",         "Same fileName+version already " + ex.getStatus() + ".",
                            "existingJobId",  ex.getJobId(),
                            "existingStatus", ex.getStatus(),
                            "networkVersion", version,
                            "orgId",          effectiveOrg,
                            "fileName",       name,
                            "hint",           "Use a different networkVersion or DELETE the existing job."
                        ));
                    }
                }

                com.cim.model.mongo.ValidationJob job = new com.cim.model.mongo.ValidationJob(
                        jobId, name, format, user, version, effectiveOrg);
                jobRepo.save(job);
                log.info("FTP stream import: jobId={} fileName={} format={}", jobId, name, format);

                importService.processAndResolve(
                        buf, name, format, jobId, version, effectiveOrg);

                com.cim.model.mongo.ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId",          jobId,
                    "status",         done.getStatus(),
                    "networkVersion", version,
                    "orgId",          effectiveOrg,
                    "fileName",       name,
                    "format",         format,
                    "source",         "ftp-stream",
                    "totalObjects",   done.getTotalObjects() != null ? done.getTotalObjects() : 0,
                    "links",          links(jobId, version, effectiveOrg)
                ));
            } catch (IllegalStateException e) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "FTP not configured: " + e.getMessage(),
                    "hint",  "Set cim.ftp.host, cim.ftp.username, cim.ftp.password, cim.ftp.remote-dir in application.yml"));
            } catch (IllegalArgumentException e) {
                return ResponseEntity.badRequest().body(Map.of("error", e.getMessage(), "fileName", name));
            } catch (java.io.IOException e) {
                log.error("FTP stream import failed for fileName={}: {}", name, e.getMessage());
                return ResponseEntity.status(502).body(Map.of(
                    "error",    "FTP import failed: " + e.getMessage(),
                    "fileName", name,
                    "hint",     "If the FTP server timed out during parsing, consider pre-downloading the file and using filePath instead."));
            } catch (Exception e) {
                log.error("FTP stream import error: jobId={} error={}", jobId, e.getMessage(), e);
                return ResponseEntity.internalServerError()
                        .body(Map.of("error", e.getMessage(), "jobId", jobId, "fileName", name));
            }
        }

        // ── Local filesystem path ──────────────────────────────────────────
        java.io.File sourceFile = new java.io.File(filePath.trim());
        String originalName = sourceFile.getName();

        if (!sourceFile.exists()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "File not found on server.",
                "filePath", filePath));
        }
        if (!sourceFile.isFile()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "filePath does not point to a regular file.",
                "filePath", filePath));
        }
        if (!sourceFile.canRead()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",    "File exists but is not readable by the server process.",
                "filePath", filePath));
        }

        if (sourceFile.length() == 0)
            return ResponseEntity.badRequest().body(Map.of(
                "error", "File is empty.", "filePath", filePath));

        // Read first 512 bytes for format detection only
        byte[] header = new byte[512];
        int headerLen;
        try (java.io.FileInputStream fis = new java.io.FileInputStream(sourceFile)) {
            headerLen = fis.read(header, 0, header.length);
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Cannot read file header: " + e.getMessage(),
                                 "filePath", filePath));
        }
        byte[] headerTrimmed = headerLen > 0
                ? java.util.Arrays.copyOf(header, headerLen) : new byte[0];

        // ── Archive: stream each entry directly to ImportService ─────────
        if (archiveExtractor.isArchive(originalName)) {
            List<Map<String, Object>> results = new ArrayList<>();
            try {
                archiveExtractor.streamEntries(sourceFile, originalName,
                    (entryName, entryStream) -> {
                        ResponseEntity<?> r = importSingleFileFromStream(
                                entryStream, entryName,
                                sourceFile.length(), // approx size per entry
                                version, org, user, requestedType);
                        Map<String, Object> row = new LinkedHashMap<>();
                        row.put("fileName",   entryName);
                        row.put("httpStatus", r.getStatusCodeValue());
                        row.put("response",   r.getBody());
                        results.add(row);
                    });
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Failed to process archive '" + originalName + "': "
                            + e.getMessage()));
            }
            if (results.isEmpty())
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Archive '" + originalName + "' contains no usable files."));

            return ResponseEntity.ok(Map.of(
                "archiveFileName", originalName,
                "totalFiles",      results.size(),
                "results",         results
            ));
        }

        // ── Plain file: stream from local disk ────────────────────────────
        String format = detectFormat(headerTrimmed, originalName);
        String jobId  = java.util.UUID.randomUUID().toString();

        com.cim.model.mongo.ValidationJob job = new com.cim.model.mongo.ValidationJob(
                jobId, originalName, format, user, version, effectiveOrg);
        jobRepo.save(job);
        log.info("Import from filePath: jobId={} file={} size={}MB format={}",
                jobId, originalName,
                String.format("%.1f", sourceFile.length() / 1048576.0), format);

        try {
            if (sourceFile.length() <= LARGE) {
                // Sync — small file
                try {
                    importService.processAndResolveFromPath(
                            filePath.trim(), originalName, format,
                            jobId, version, effectiveOrg, exportNeo4j, neo4jConfigId,
                            fullVersion, sanitisedVersion, rationalisedVersion);
                } finally {
                    deleteFtpTempFile(ftpTempFile);
                }
                com.cim.model.mongo.ValidationJob done =
                        jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId",          jobId,
                    "status",         done.getStatus(),
                    "networkVersion", version,
                    "orgId",          effectiveOrg,
                    "fileName",       originalName,
                    "format",         format,
                    "totalObjects",   done.getTotalObjects() != null ? done.getTotalObjects() : 0,
                    "links",          links(jobId, version, effectiveOrg)
                ));
            } else {
                // Async — large file
                importService.processAndResolveAsync(
                        filePath.trim(), originalName, format,
                        jobId, version, effectiveOrg, neo4jConfigId,
                        fullVersion, sanitisedVersion, rationalisedVersion);
                return ResponseEntity.accepted().body(Map.of(
                    "jobId",          jobId,
                    "status",         "PROCESSING",
                    "networkVersion", version,
                    "orgId",          effectiveOrg,
                    "fileName",       originalName,
                    "fileSizeMb",     String.format("%.1f", sourceFile.length() / 1048576.0),
                    "links",          links(jobId, version, effectiveOrg)
                ));
            }
        } catch (Exception e) {
            deleteFtpTempFile(ftpTempFile);
            log.error("Import failed: jobId={} error={}", jobId, e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(),
                                 "jobId", jobId,
                                 "filePath", filePath));
        }
    }

    /**
     * Imports a single file from a streaming InputStream — zero byte[] allocation.
     * Called for archive entries (each entry streams directly from the archive
     * without being loaded into memory).
     */
    private ResponseEntity<?> importSingleFileFromStream(
            java.io.InputStream entryStream, String fileName,
            long fileSizeBytes, String version, String org,
            String user, String requestedType) {

        // Read header for format detection
        byte[] header = new byte[0];
        java.io.InputStream nonClosing = nonClosing(entryStream);
        java.io.BufferedInputStream buf = new java.io.BufferedInputStream(nonClosing, 65536);
        try {
            buf.mark(512);
            byte[] tmp = new byte[512];
            int n = buf.read(tmp, 0, 512);
            header = n > 0 ? java.util.Arrays.copyOf(tmp, n) : new byte[0];
            buf.reset();
        } catch (Exception ignored) {}

        String format = detectFormat(header, fileName);
        if (requestedType != null) {
            String detected = claimedTypeFor(format);
            if (!requestedType.equals(detected)) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error",         "Invalid file type.",
                    "fileName",      fileName,
                    "requestedType", requestedType,
                    "detectedType",  detected,
                    "hint", "The file content does not match the declared fileType."
                ));
            }
        }

        String jobId = java.util.UUID.randomUUID().toString();
        ValidationJob job = new ValidationJob(jobId, fileName, format, user, version, org);
        jobRepo.save(job);

        try {
            // Archive entries are always processed synchronously (one at a time)
            importService.processAndResolve(buf, fileName, format, jobId, version, org);
            ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
            return ResponseEntity.ok(Map.of(
                "jobId",           jobId,
                "status",          done.getStatus(),
                "networkVersion",  version,
                "orgId",           org,
                "fileName",        fileName,
                "format",          format,
                "totalObjects",    done.getTotalObjects(),
                "physicalObjects", done.getPhysicalObjects(),
                "logicalObjects",  done.getLogicalObjects(),
                "stageTimings",    done.getStageTimings(),
                "links",           links(jobId, version, org)
            ));
        } catch (Exception e) {
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId,
                                 "networkVersion", version, "orgId", org));
        }
    }

    /** Wraps an InputStream so that close() is a no-op — prevents downstream
     *  components (XMLStreamReader.close) from closing shared archive streams. */
    private static java.io.InputStream nonClosing(java.io.InputStream in) {
        return new java.io.FilterInputStream(in) {
            @Override public void close() { /* intentionally no-op */ }
        };
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "List import jobs", response = JobSummary.class, responseContainer = "List")
    @GetMapping("/jobs")
    public ResponseEntity<?> listJobs(
            @RequestParam(required=false) String networkVersion,
            @RequestParam(required=false) String orgId) {

        List<ValidationJob> jobs;
        if (networkVersion != null && orgId != null) {
            jobs = jobRepo.findByNetworkVersionAndOrgId(
                    networkVersion.trim(), orgId.trim());
        } else if (networkVersion != null) {
            jobs = jobRepo.findByNetworkVersion(networkVersion.trim());
        } else if (orgId != null) {
            jobs = jobRepo.findByOrgId(orgId.trim());
        } else {
            jobs = jobRepo.findTop10ByOrderBySubmittedAtDesc();
        }
        return ResponseEntity.ok(jobs);
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Get a single import job", response = JobSummary.class)
    @ApiResponses({@ApiResponse(code=200, message="OK", response=JobSummary.class), @ApiResponse(code=404, message="Job not found")})
    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<?> getJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/progress
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Get live import progress", response = ProgressResponse.class)
    @GetMapping("/jobs/{jobId}/progress")
    public ResponseEntity<?> progress(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId)
                .map(j -> {
                    java.util.Optional<com.cim.streaming.ProgressTracker> tracker =
                            importService.getTracker(jobId);

                    if (tracker.isPresent()) {
                        com.cim.streaming.ProgressSnapshot snap = tracker.get().snapshot();
                        return ResponseEntity.ok(Map.of(
                            "jobId",          jobId,
                            "status",         j.getStatus() != null ? j.getStatus() : "RUNNING",
                            "stage",          snap.stage() != null ? snap.stage() : "",
                            "parsed",         snap.parsed(),
                            "saved",          snap.saved(),
                            "percent",        snap.percent(),
                            "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                            "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
                            "source",         "local"
                        ));
                    }

                    String stage   = j.getProgressStage()   != null ? j.getProgressStage()   : j.getStatus();
                    long parsed    = j.getProgressParsed()  != null ? j.getProgressParsed()  : j.getTotalObjects();
                    long saved     = j.getProgressSaved()   != null ? j.getProgressSaved()   : j.getTotalObjects();
                    int  percent   = j.getProgressPercent() != null ? j.getProgressPercent() : 100;
                    String detail  = j.getProgressDetail()  != null ? j.getProgressDetail()  : j.getStatus();

                    return ResponseEntity.ok(Map.of(
                        "jobId",          jobId,
                        "status",         j.getStatus() != null ? j.getStatus() : "",
                        "stage",          stage,
                        "parsed",         parsed,
                        "saved",          saved,
                        "percent",        percent,
                        "detail",         detail,
                        "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                        "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
                        "source",         "mongodb"
                    ));
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/stats
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Get job statistics", response = JobStatsResponse.class)
    @GetMapping("/jobs/{jobId}/stats")
    public ResponseEntity<?> getJobStats(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId).map(j -> ResponseEntity.ok(Map.of(
            "jobId",          jobId,
            "networkVersion", j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
            "orgId",          j.getOrgId() != null ? j.getOrgId() : "",
            "status",         j.getStatus(),
            "totalObjects",   j.getTotalObjects(),
            "physicalObjects",j.getPhysicalObjects(),
            "logicalObjects", j.getLogicalObjects(),
            "pathIssueCount", j.getPathIssueCount(),
            "stageTimings",   j.getStageTimings(),
            "enabledNamespaces", j.getEnabledNamespaces(),
            "links",          links(jobId,
                    j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                    j.getOrgId() != null ? j.getOrgId() : "")
        ))).orElse(ResponseEntity.notFound().build());
    }

    // ── Alias endpoints — use orgId+version instead of jobId ──────────

    private java.util.Optional<String> resolveJobId(String orgId, String version) {
        return jobRepo
            .findTopByOrgIdAndNetworkVersionOrderBySubmittedAtDesc(
                orgId.trim(), version.trim())
            .map(j -> j.getJobId());
    }

    @ApiOperation(value = "Get progress by org + version", response = ProgressResponse.class)
    @GetMapping("/orgs/{orgId}/versions/{version}/progress")
    public ResponseEntity<?> progressByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .map(jobId -> {
                    java.util.Optional<com.cim.streaming.ProgressTracker> trackerOpt =
                            importService.getTracker(jobId);
                    if (trackerOpt.isPresent()) {
                        com.cim.streaming.ProgressSnapshot snap = trackerOpt.get().snapshot();
                        java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                        r.put("jobId",           jobId);
                        r.put("orgId",           orgId);
                        r.put("networkVersion",  version);
                        r.put("stage",           snap.stage());
                        r.put("parsed",          snap.parsed());
                        r.put("saved",           snap.saved());
                        r.put("percent",         snap.percent());
                        r.put("finished",        snap.finished());
                        return ResponseEntity.ok(r);
                    }
                    return jobRepo.findByJobId(jobId)
                            .map(j -> {
                                java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                                r.put("jobId",           jobId);
                                r.put("orgId",           orgId);
                                r.put("networkVersion",  version);
                                r.put("status",          j.getStatus());
                                r.put("percent",         100);
                                r.put("parsed",          j.getTotalObjects());
                                r.put("saved",           j.getTotalObjects());
                                r.put("finished",        true);
                                r.put("stageTimings",    j.getStageTimings());
                                return ResponseEntity.ok(r);
                            })
                            .orElse(ResponseEntity.notFound().build());
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "Get job by org + version alias", response = JobSummary.class)
    @GetMapping("/orgs/{orgId}/versions/{version}")
    public ResponseEntity<?> jobByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .flatMap(jobId -> jobRepo.findByJobId(jobId))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "Get stats by org + version", response = JobStatsResponse.class)
    @GetMapping("/orgs/{orgId}/versions/{version}/stats")
    public ResponseEntity<?> statsByVersion(
            @PathVariable String orgId,
            @PathVariable String version) {
        return resolveJobId(orgId, version)
                .map(jobId -> {
                    long total    = objectRepo.countByJobId(jobId);
                    long physical = objectRepo.countByJobIdAndCategory(jobId, "PHYSICAL");
                    long logical  = objectRepo.countByJobIdAndCategory(jobId, "LOGICAL");
                    java.util.Map<String,Object> r = new java.util.LinkedHashMap<>();
                    r.put("orgId",          orgId);
                    r.put("networkVersion", version);
                    r.put("jobId",          jobId);
                    r.put("total",          total);
                    r.put("physical",       physical);
                    r.put("logical",        logical);
                    return ResponseEntity.ok(r);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @ApiOperation(value = "List imported versions for an org", response = VersionListResponse.class)
    @GetMapping("/orgs/{orgId}/versions")
    public ResponseEntity<?> listVersions(@PathVariable String orgId) {
        java.util.List<com.cim.model.mongo.ValidationJob> jobs =
                jobRepo.findByOrgId(orgId.trim());
        java.util.List<java.util.Map<String,Object>> versions = new java.util.ArrayList<>();
        for (com.cim.model.mongo.ValidationJob j : jobs) {
            java.util.Map<String,Object> v = new java.util.LinkedHashMap<>();
            v.put("jobId",          j.getJobId());
            v.put("networkVersion", j.getNetworkVersion());
            v.put("status",         j.getStatus());
            v.put("totalObjects",   j.getTotalObjects());
            v.put("totalFormatted", j.getStageTimings() != null
                    ? j.getStageTimings().getTotalFormatted() : null);
            v.put("submittedAt",    j.getSubmittedAt());
            versions.add(v);
        }
        return ResponseEntity.ok(Map.of(
            "orgId",    orgId,
            "total",    versions.size(),
            "versions", versions
        ));
    }

    // ─────────────────────────────────────────────────────────────────
    // DELETE /api/jobs/{jobId}
    // ─────────────────────────────────────────────────────────────────
    @ApiOperation(value = "Delete job and all related data (raw_objects, cim_objects)")
    @ApiResponses({@ApiResponse(code=200, message="Deleted"), @ApiResponse(code=404, message="Job not found")})
    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<?> deleteJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId).map(j -> {
            jobRepo.delete(j);
            rawRepo.deleteByJobId(jobId);
            return ResponseEntity.ok(Map.of(
                "message",          "Job " + jobId + " deleted.",
                "networkVersion",   j.getNetworkVersion() != null ? j.getNetworkVersion() : "",
                "orgId",            j.getOrgId() != null ? j.getOrgId() : "",
                "collectionsCleared", java.util.Arrays.asList(
                    "validation_jobs", "raw_objects", "cim_objects"),
                "hint",             "You can now re-import the same file+version."));
        }).orElse(ResponseEntity.notFound().build());
    }

    // ── File Upload Import ────────────────────────────────────────────────────

    @PostMapping(value = "/import/upload", consumes = "multipart/form-data")
    public ResponseEntity<?> uploadAndImport(
            @RequestParam("file")                                    org.springframework.web.multipart.MultipartFile file,
            @RequestParam("networkVersion")                          String networkVersion,
            @RequestParam(value = "fileType",       required = false) String fileType,
            @RequestParam(value = "exportToNeo4j",  required = false,
                          defaultValue = "true")                      boolean exportToNeo4j,
            @RequestParam(value = "neo4jConfigId",  required = false) String neo4jConfigId,
            @RequestHeader(value = "X-Org-Id",    defaultValue = "") String orgId,
            @RequestHeader(value = "X-User",      defaultValue = "anonymous") String user) {

        if (file == null || file.isEmpty())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "No file provided or file is empty"));

        if (networkVersion == null || networkVersion.isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "networkVersion is required"));

        String originalName = org.springframework.util.StringUtils
                .cleanPath(file.getOriginalFilename() != null
                        ? file.getOriginalFilename() : "upload.xml");
        String format      = fileType != null ? fileType : "";
        String jobId       = java.util.UUID.randomUUID().toString();
        String effectiveOrg = orgId.isBlank() ? "" : orgId;

        log.info("Upload received: {} ({} MB) jobId={}",
                originalName,
                String.format("%.1f", file.getSize() / (1024.0 * 1024.0)),
                jobId);

        try {
            String resolvedNeo4jConfigId = (neo4jConfigId != null && !neo4jConfigId.isBlank())
                    ? neo4jConfigId.trim() : null;
            try (java.io.InputStream is =
                         new java.io.BufferedInputStream(file.getInputStream(), 65536)) {
                importService.processAndResolve(is, originalName, format,
                        jobId, networkVersion, effectiveOrg, resolvedNeo4jConfigId);
            }
            return ResponseEntity.accepted().body(Map.of(
                "jobId",   jobId,
                "status",  "ACCEPTED",
                "file",    originalName,
                "message", "Import started"
            ));
        } catch (Exception e) {
            log.error("Upload import failed: jobId={} error={}", jobId, e.getMessage(), e);
            return ResponseEntity.status(500)
                    .body(Map.of("error", e.getMessage(), "jobId", jobId));
        }
    }

    // ── Re-Import ─────────────────────────────────────────────────────────────

    @PostMapping("/import/{jobId}/reimport")
    public ResponseEntity<?> reimport(
            @PathVariable String jobId,
            @RequestHeader(value = "X-Org-Id",    defaultValue = "") String orgId,
            @RequestHeader(value = "X-User",      defaultValue = "anonymous") String user) {

        com.cim.model.mongo.ValidationJob job = jobRepo.findByJobId(jobId).orElse(null);
        if (job == null)
            return ResponseEntity.notFound().build();

        String currentStatus = job.getStatus();
        if (!"FAILED".equals(currentStatus) && !"PENDING".equals(currentStatus))
            return ResponseEntity.badRequest().body(Map.of(
                "error",   "Job cannot be re-imported in status: " + currentStatus,
                "allowed", "FAILED or PENDING only"
            ));

        String filePath = job.getSourceFile();
        if (filePath == null || filePath.isBlank())
            return ResponseEntity.badRequest().body(Map.of(
                "error", "Original file path not found on job record. " +
                         "Use POST /api/import with the file path instead."
            ));

        importService.cleanupFailedJob(jobId);
        log.info("Re-import: cleaned up partial data for jobId={}", jobId);

        ImportByPathRequest req = new ImportByPathRequest();
        req.filePath      = filePath;
        req.networkVersion = job.getNetworkVersion();
        req.exportToNeo4j  = true;

        return importFile(req,
                orgId.isBlank() ? job.getOrgId() : orgId,
                user);
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    /** Deletes the FTP-downloaded temp file after import completes. No-op if path is null. */
    private void deleteFtpTempFile(String tempFilePath) {
        if (tempFilePath == null) return;
        try {
            boolean deleted = new java.io.File(tempFilePath).delete();
            if (deleted) log.info("FTP temp file deleted: {}", tempFilePath);
            else         log.warn("FTP temp file could not be deleted (may not exist): {}", tempFilePath);
        } catch (Exception e) {
            log.warn("Error deleting FTP temp file {}: {}", tempFilePath, e.getMessage());
        }
    }

    private String detectFormat(byte[] bytes, String name) {
        String h = new String(bytes, 0, Math.min(512, bytes.length));
        if (h.contains("rdf:RDF") || h.contains("xmlns:cim")) return "RDF_XML";
        if (h.contains("@context") || h.contains("@graph"))   return "JSON_LD";
        if (name != null && name.toLowerCase().endsWith(".csv")) return "MILSOFT_CSV";
        return "RDF_XML";
    }

    /**
     * Extension-only format detection — no file content read.
     * Used as a cheap pre-check for large FTP files before any download starts.
     * The async thread does a definitive content-based check after download.
     */
    private String detectFormatFromExtensionOnly(String name) {
        if (name == null) return "RDF_XML";
        String lower = name.toLowerCase();
        if (lower.endsWith(".csv"))                    return "MILSOFT_CSV";
        if (lower.endsWith(".json") || lower.endsWith(".jsonld") || lower.endsWith(".json-ld"))
                                                       return "JSON_LD";
        if (lower.endsWith(".xml") || lower.endsWith(".rdf")) return "RDF_XML";
        return "RDF_XML"; // default assumption for unknown extensions
    }

    private String claimedTypeFor(String internalFormat) {
        switch (internalFormat) {
            case "RDF_XML":      return "RDF";
            case "JSON_LD":      return "JSON";
            case "MILSOFT_CSV":  return "MILSOFT";
            default:             return internalFormat;
        }
    }

    private Map<String, String> links(String jobId, String version, String orgId) {
        return Map.of(
            "progress",   "/api/jobs/" + jobId + "/progress",
            "stats",      "/api/jobs/" + jobId + "/stats",
            "objects",    "/api/jobs/" + jobId + "/objects",
            "pathIssues", "/api/jobs/" + jobId + "/objects/path-issues",
            "required",   "/api/jobs/" + jobId + "/objects/required/summary",
            "byVersion",  "/api/jobs?networkVersion=" + version + "&orgId=" + orgId
        );
    }

    public static class ImportByPathRequest {
        public String  filePath;
        public String  fileName;
        public String  networkVersion;
        public String  fileType;
        public Boolean exportToNeo4j = true;
        /**
         * Optional MongoDB _id of a specific Neo4jExportConfig to use for the auto-export
         * that runs after a successful import. When provided, that exact config is used
         * regardless of orgId matching or updatedAt ordering. When omitted, the most
         * recently updated active config for the import's orgId is chosen automatically.
         */
        public String  neo4jConfigId;

        /**
         * Version label to use in Neo4j for the FULL variant export.
         * e.g. "DB-0", "DB140-0", "2024-Q1-full"
         * If provided, the FULL variant export is triggered with this exact version label.
         * If omitted or blank, the FULL variant export is SKIPPED.
         */
        public String  fullVersion;

        /**
         * Version label to use in Neo4j for the SANITISED variant export.
         * e.g. "DB-1", "DB140-1", "2024-Q1-sanitised"
         * If provided, the SANITISED variant export is triggered with this exact version label.
         * If omitted or blank, the SANITISED variant export is SKIPPED.
         */
        public String  sanitisedVersion;

        /**
         * Version label to use in Neo4j for the RATIONALISED variant export.
         * e.g. "DB-2", "DB140-2", "2024-Q1-rationalised"
         * If provided, the RATIONALISED variant export is triggered with this exact version label.
         * If omitted or blank, the RATIONALISED variant export is SKIPPED.
         */
        public String  rationalisedVersion;
    }

    /**
     * Validates version type fields in an ImportByPathRequest.
     *
     * Rules:
     *   1) If all three version types are blank → error (nothing to export).
     *   2) If the same value appears in more than one version type → error (duplicate version).
     *   3) If a version type is blank → that variant is simply skipped (no error).
     *
     * Returns null if valid, or a ResponseEntity with the error body if invalid.
     */
    static ResponseEntity<?> validateVersionTypes(ImportByPathRequest req) {
        String full        = req.fullVersion        != null ? req.fullVersion.trim()        : "";
        String sanitised   = req.sanitisedVersion   != null ? req.sanitisedVersion.trim()   : "";
        String rationalised = req.rationalisedVersion != null ? req.rationalisedVersion.trim() : "";

        // Rule 2: at least one version type must be provided
        if (full.isEmpty() && sanitised.isEmpty() && rationalised.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error", "At least one of fullVersion, sanitisedVersion, or rationalisedVersion must be provided.",
                "hint",  "Set the version label(s) for the variant(s) you want exported to Neo4j. " +
                         "Blank variants are skipped. e.g. fullVersion=\"DB-0\", sanitisedVersion=\"DB-1\"."
            ));
        }

        // Rule 3: same value in more than one version type is not allowed
        List<String> provided = new ArrayList<>();
        Map<String, String> valueToField = new LinkedHashMap<>();
        if (!full.isEmpty())         { provided.add(full);         valueToField.put(full,         "fullVersion"); }
        if (!sanitised.isEmpty())    { provided.add(sanitised);    valueToField.put(sanitised,    "sanitisedVersion"); }
        if (!rationalised.isEmpty()) { provided.add(rationalised); valueToField.put(rationalised, "rationalisedVersion"); }

        Set<String> seen = new LinkedHashSet<>();
        List<String> duplicates = new ArrayList<>();
        for (String v : provided) {
            if (!seen.add(v)) duplicates.add(v);
        }
        if (!duplicates.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error",      "Duplicate version values across version types.",
                "duplicates", duplicates,
                "hint",       "Each of fullVersion, sanitisedVersion, rationalisedVersion must have a unique value. " +
                              "Use distinct labels e.g. \"DB-0\", \"DB-1\", \"DB-2\"."
            ));
        }

        return null; // valid
    }
}
