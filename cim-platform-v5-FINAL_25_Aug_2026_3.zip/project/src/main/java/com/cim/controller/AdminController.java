package com.cim.controller;

import com.cim.repository.CimClassRepository;
import com.cim.service.CIMStandardService;
import com.cim.service.Neo4jExportService;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import io.swagger.annotations.*;
import com.cim.model.api.ApiResponseModels.*;

/**
 * Admin API
 *
 * ── OWL Management ──────────────────────────────────────────────────
 * POST /api/admin/cim/upload-owl              single OWL file
 * POST /api/admin/cim/upload-owl/multiple     CPSM multi-profile
 * POST /api/admin/cim/reload                  reload from configured path
 * GET  /api/admin/cim/stats                   registry stats
 * GET  /api/admin/cim/classes                 list all classes
 * GET  /api/admin/cim/classes/{name}          class detail
 * GET  /api/admin/cim/chain/{name}            inheritance chain
 * POST /api/admin/cim/validate-path           test path validation
 *
 * ── Neo4j Export ────────────────────────────────────────────────────
 * POST /api/admin/neo4j/export                start export
 * GET  /api/admin/neo4j/exports               list recent exports
 * GET  /api/admin/neo4j/exports/{exportId}    export status
 *
 * Export modes:
 *   ALL           → all objects in job
 *   PHYSICAL_ONLY → only PHYSICAL category
 *   REQUIRED_ONLY → only isRequired=true
 *   CUSTOM        → specify cimTypes list
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final CIMStandardService                          standardService;
    private final CIMHierarchyRegistry                        registry;
    private final CimClassRepository                          classRepo;
    private final Neo4jExportService                          exportService;
    private final ValidationJobRepository                     jobRepo;
    private final Neo4jExportConfigRepository                 exportConfigRepo;
    private final com.cim.service.RevalidationService         revalidationService;

    public AdminController(CIMStandardService standardService,
                            CIMHierarchyRegistry registry,
                            CimClassRepository classRepo,
                            Neo4jExportService exportService,
                            ValidationJobRepository jobRepo,
                            Neo4jExportConfigRepository exportConfigRepo,
                            com.cim.service.RevalidationService revalidationService) {
        this.standardService      = standardService;
        this.registry             = registry;
        this.classRepo            = classRepo;
        this.exportService        = exportService;
        this.jobRepo              = jobRepo;
        this.exportConfigRepo     = exportConfigRepo;
        this.revalidationService  = revalidationService;
    }

    // ── OWL ───────────────────────────────────────────────────────────────

    @ApiOperation(value = "Upload single OWL file to build CIM hierarchy", response = OwlUploadResponse.class)
    @PostMapping("/cim/upload-owl")
    public ResponseEntity<?> uploadOwl(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value="version", defaultValue="CIM17") String version) {
        if (file.isEmpty()) return ResponseEntity.badRequest()
                .body(Map.of("error","File is empty."));
        try {
            var r = standardService.uploadSingle(file, version);
            return ResponseEntity.ok(Map.of(
                "status","OK","cimVersion",r.version(),"totalClasses",r.total(),
                "physicalClasses",r.physical(),"logicalClasses",r.logical()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error",e.getMessage()));
        }
    }

    @ApiOperation(value = "Upload multiple OWL files", response = OwlUploadResponse.class)
    @PostMapping("/cim/upload-owl/multiple")
    public ResponseEntity<?> uploadMultipleOwls(
            @RequestParam("files") List<MultipartFile> files,
            @RequestParam(value="version", defaultValue="CIM17-CPSM") String version) {
        if (files == null || files.isEmpty()) return ResponseEntity.badRequest()
                .body(Map.of("error","No files provided."));
        try {
            var r = standardService.uploadMultiple(files, version);
            return ResponseEntity.ok(Map.of(
                "status","OK","cimVersion",r.version(),"totalClasses",r.total(),
                "files", files.stream().map(MultipartFile::getOriginalFilename).toList()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error",e.getMessage()));
        }
    }

    @ApiOperation(value = "Reload CIM hierarchy registry from MongoDB")
    @PostMapping("/cim/reload")
    public ResponseEntity<?> reload() {
        try {
            var r = standardService.reload();
            return ResponseEntity.ok(Map.of("status","OK",
                    "cimVersion",r.version(),"totalClasses",r.total()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error",e.getMessage()));
        }
    }

    @ApiOperation(value = "CIM hierarchy stats (class count, packages)", response = CimStatsResponse.class)
    @GetMapping("/cim/stats")
    public ResponseEntity<?> stats() {
        return ResponseEntity.ok(registry.getStats());
    }

    @ApiOperation(value = "List all known CIM classes", response = CimClassResponse.class, responseContainer = "List")
    @GetMapping("/cim/classes")
    public ResponseEntity<?> listClasses(
            @RequestParam(required=false) String category) {
        var classes = category != null
                ? classRepo.findByCategory(category.toUpperCase())
                : classRepo.findAll();
        return ResponseEntity.ok(Map.of("total",classes.size(),"classes",classes));
    }

    @ApiOperation(value = "Get details for a single CIM class", response = CimClassResponse.class)
    @ApiResponses({@ApiResponse(code=200, message="OK", response=CimClassResponse.class), @ApiResponse(code=404, message="Unknown class")})
    @GetMapping("/cim/classes/{name}")
    public ResponseEntity<?> getClass(@PathVariable String name) {
        var def = registry.getDefinition(name);
        if (def == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of(
            "className",     def.getClassName(),
            "parentClass",   def.getParentClass() != null ? def.getParentClass() : "ROOT",
            "ancestors",     def.getAncestors(),
            "ownAttributes", def.getOwnAttributes(),
            "category",      def.getCategory(),
            "required",      def.isRequired(),
            "stereotype",    def.getStereotype() != null ? def.getStereotype() : "",
            "cimPackage",    def.getCimPackage() != null ? def.getCimPackage() : "",
            "cimVersion",    def.getCimVersion(),
            "description",   def.getDescription() != null ? def.getDescription() : ""
        ));
    }

    @ApiOperation(value = "Get full inheritance chain for a class, leaf to root", response = CimChainResponse.class)
    @ApiResponses({@ApiResponse(code=200, message="OK", response=CimChainResponse.class), @ApiResponse(code=404, message="Unknown class")})
    @GetMapping("/cim/chain/{className}")
    public ResponseEntity<?> getChain(@PathVariable String className) {
        if (!registry.isKnownClass(className))
            return ResponseEntity.notFound().build();
        var chain = registry.getFullChain(className);
        return ResponseEntity.ok(Map.of(
            "className",className,"chain",chain,"depth",chain.size()-1));
    }

    @ApiOperation(value = "Validate whether an attribute path is valid for a CIM class", response = ValidatePathResponse.class)
    @PostMapping("/cim/validate-path")
    public ResponseEntity<?> validatePath(@RequestBody Map<String,String> body) {
        String type = body.get("objectType");
        String tag  = body.get("attributeTag");
        if (type == null || tag == null) return ResponseEntity.badRequest()
                .body(Map.of("error","Both objectType and attributeTag required."));
        var result = registry.validateAttributePath(type, tag);
        return ResponseEntity.ok(Map.of(
            "objectType",type,"attributeTag",tag,
            "status",result.getStatus().name(),
            "valid",result.isValid(),
            "explanation",result.getExplanation(),
            "chain",registry.getFullChain(type)
        ));
    }

    // ── Neo4j Export ─────────────────────────────────────────────────────

    /**
     * POST /api/admin/neo4j/export
     *
     * Body:
     * {
     *   "jobId":      "uuid",
     *   "mode":       "ALL" | "PHYSICAL_ONLY" | "REQUIRED_ONLY" | "CUSTOM",
     *   "cimTypes":   ["ACLineSegment","Breaker"],   // for CUSTOM mode only
     *   "clearFirst": true                            // delete existing nodes first
     * }
     */
    /**
     * POST /api/admin/neo4j/export
     *
     * REQ #3: Three version types, each with its OWN set of CIM types.
     * REQ #4: orgId specific
     * REQ #6: Full RequestBody schema visible in Swagger UI
     *
     * ── SINGLE VARIANT ──────────────────────────────────────────────
     * Export one version type:
     * {
     *   "jobId":       "uuid",
     *   "orgId":       "CAISO",
     *   "versionType": "SANITISED",
     *   "clearFirst":  true,
     *   "cimTypes": [
     *     "ACLineSegment","Breaker","PowerTransformer","Terminal","ConnectivityNode"
     *   ]
     * }
     * → Creates nodes with version = "{networkVersion}-1"
     *
     * ── MULTI VARIANT (all three at once) ───────────────────────────
     * Export all three variants with different CIM type sets:
     * {
     *   "jobId":      "uuid",
     *   "orgId":      "CAISO",
     *   "clearFirst": true,
     *   "fullCimTypes": [
     *     "ACLineSegment","Breaker","PowerTransformer","Fuse","Disconnector",
     *     "SynchronousMachine","EnergyConsumer","GeneratingUnit",
     *     "Terminal","ConnectivityNode","TopologicalNode",
     *     "BaseVoltage","Substation","VoltageLevel","Bay","Line"
     *   ],
     *   "sanitisedCimTypes": [
     *     "ACLineSegment","Breaker","PowerTransformer","Fuse","Disconnector",
     *     "Terminal","ConnectivityNode","BaseVoltage","Substation","VoltageLevel","Line"
     *   ],
     *   "rationalisedCimTypes": [
     *     "ACLineSegment","Breaker","PowerTransformer","Fuse","Disconnector"
     *   ]
     * }
     * → Creates 3 sets of nodes: {version}-0, {version}-1, {version}-2
     */
    @ApiOperation(value = "Start a Neo4j topology export", response = ExportStartedResponse.class)
    @ApiResponses({@ApiResponse(code=202, message="Export started async", response=ExportStartedResponse.class), @ApiResponse(code=400, message="Invalid request")})
    @PostMapping("/neo4j/export")
    public ResponseEntity<?> startExport(@RequestBody ExportRequest req) {
        if (req.getJobId() == null || req.getJobId().isBlank())
            return ResponseEntity.badRequest()
                    .body(Map.of("error","jobId is required."));

        // Single variant validation
        if (!req.isMultiVariant()) {
            if (req.getVersionType() == null)
                req.setVersionType(ExportRequest.VersionType.SANITISED);
            if (req.getMode() == null)
                req.setMode(ExportRequest.ExportMode.TOPOLOGY);

            boolean isFromConfig = req.getMode() == ExportRequest.ExportMode.FROM_CONFIG;
            boolean hasTypes     = req.getCimTypes() != null && !req.getCimTypes().isEmpty();

            if (isFromConfig) {
                // FROM_CONFIG: configId required, cimTypes come from stored config
                if (req.getConfigId() == null || req.getConfigId().isBlank())
                    return ResponseEntity.badRequest().body(Map.of(
                        "error",  "configId required when mode=FROM_CONFIG.",
                        "hint",   "Set configId to the _id of a Neo4jExportConfig document.",
                        "lookup", "GET /api/cim/admin/neo4j/configs to find config IDs."));
            } else if (!hasTypes
                    && req.getMode() == ExportRequest.ExportMode.CUSTOM) {
                // CUSTOM mode without cimTypes — error
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "cimTypes required when mode=CUSTOM.",
                    "hint",  "Provide cimTypes list OR use mode=FROM_CONFIG with configId."));
            }
            // Other modes (ALL, PHYSICAL_ONLY, REQUIRED_ONLY, TOPOLOGY)
            // don't need cimTypes — they use built-in criteria
        }

        com.cim.model.mongo.Neo4jExportJob exportJob = exportService.startExport(req);
        Map<String, Object> response = new java.util.LinkedHashMap<>();
        response.put("exportId",     exportJob != null ? exportJob.getExportId() : "multiple");
        response.put("status",       exportJob != null ? exportJob.getStatus()   : "RUNNING");
        response.put("jobId",        req.getJobId());
        response.put("multiVariant", req.isMultiVariant());
        if (req.isMultiVariant()) {
            response.put("variants", Map.of(
                "full",      req.getFullCimTypes().size() + " cimTypes → {version}-0",
                "sanitised", req.getSanitisedCimTypes().size() + " cimTypes → {version}-1",
                "rationalised", req.getRationalisedCimTypes().size() + " cimTypes → {version}-2"
            ));
        } else {
            response.put("versionType",  req.getVersionType().name());
            response.put("neo4jVersion", exportJob != null ? exportJob.getNetworkVersion() : "");
            if (req.getMode() == ExportRequest.ExportMode.FROM_CONFIG) {
                response.put("configId",    req.getConfigId());
                response.put("note",        "cimTypes loaded from Neo4jExportConfig: " + req.getConfigId());
            } else {
                response.put("cimTypeCount", req.getCimTypes() != null ? req.getCimTypes().size() : 0);
            }
        }
        response.put("orgId", req.getOrgId() != null ? req.getOrgId() : "from job");
        response.put("links", Map.of(
            "list", "/api/admin/neo4j/exports?jobId=" + req.getJobId()));
        return ResponseEntity.accepted().body(response);
    }

    @ApiOperation(value = "Remove legacy labels from old Neo4j exports", response = CleanupLabelsResponse.class)
    @PostMapping("/neo4j/cleanup-labels")
    public ResponseEntity<?> cleanupLabels() {
        try {
            long removed = exportService.removeLegacyLabels();
            return ResponseEntity.ok(Map.of(
                "message", "Legacy labels removed.",
                "nodesUpdated", removed));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/neo4j/exports")
    public ResponseEntity<?> listExports(
            @RequestParam(required=false) String networkVersion,
            @RequestParam(required=false) String orgId) {
        // Filter exports by version and/or orgId when provided
        List<com.cim.model.mongo.Neo4jExportJob> exports = exportService.getRecentExports();
        if (networkVersion != null && !networkVersion.isBlank()) {
            String v = networkVersion.trim();
            exports = exports.stream()
                    .filter(e -> v.equals(e.getNetworkVersion()))
                    .collect(java.util.stream.Collectors.toList());
        }
        if (orgId != null && !orgId.isBlank()) {
            String o = orgId.trim();
            exports = exports.stream()
                    .filter(e -> o.equals(e.getOrgId()))
                    .collect(java.util.stream.Collectors.toList());
        }
        return ResponseEntity.ok(Map.of(
            "total",   exports.size(),
            "exports", exports,
            "filter",  Map.of(
                "networkVersion", networkVersion != null ? networkVersion : "ALL",
                "orgId",          orgId          != null ? orgId          : "ALL"
            )
        ));
    }

    @GetMapping("/neo4j/exports/{exportId}")
    public ResponseEntity<?> getExport(@PathVariable String exportId) {
        return exportService.getExportStatus(exportId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * POST /api/cim/admin/neo4j/migrate-cimnode
     *
     * ONE-TIME migration: adds :CIMNode label to all existing Neo4j nodes
     * exported BEFORE the :CIMNode fix was applied.
     *
     * Run ONCE after deploying this fix. Idempotent — safe to run multiple times.
     */
    // ── Export alias — use orgId+version instead of jobId ──────────

    /**
     * POST /api/cim/admin/neo4j/export/orgs/{orgId}/versions/{version}
     *
     * Alias for POST /api/cim/admin/neo4j/export when you don't want to
     * look up the jobId first. Resolves jobId from orgId + version.
     *
     * Body: same as POST /api/cim/admin/neo4j/export but jobId is optional
     * (resolved from path params if not provided in body).
     *
     * Example:
     *   POST /api/cim/admin/neo4j/export/orgs/CAISO/versions/DB140
     *   { "mode":"FROM_CONFIG", "configId":"...", "versionType":"SANITISED" }
     */
    @PostMapping("/neo4j/export/orgs/{orgId}/versions/{version}")
    public ResponseEntity<?> exportByVersion(
            @PathVariable String orgId,
            @PathVariable String version,
            @RequestBody ExportRequest req) {
        // Resolve jobId if not provided in body
        if (req.getJobId() == null || req.getJobId().isBlank()) {
            java.util.Optional<String> jobId =
                    jobRepo.findTopByOrgIdAndNetworkVersionOrderBySubmittedAtDesc(
                            orgId.trim(), version.trim())
                    .map(j -> j.getJobId());
            if (!jobId.isPresent())
                return ResponseEntity.notFound().build();
            req.setJobId(jobId.get());
        }
        if (req.getOrgId() == null || req.getOrgId().isBlank())
            req.setOrgId(orgId);
        return startExport(req);
    }

    /**
     * POST /api/cim/admin/revalidate/orgs/{orgId}/versions/{version}
     *
     * Alias for POST /api/cim/admin/revalidate.
     * Resolves jobId from orgId + networkVersion.
     *
     * Example:
     *   POST /api/cim/admin/revalidate/orgs/CAISO/versions/DB140
     *   { "triggerExport": true }
     */
    @PostMapping("/revalidate/orgs/{orgId}/versions/{version}")
    public ResponseEntity<?> revalidateByVersion(
            @PathVariable String orgId,
            @PathVariable String version,
            @RequestBody(required=false) java.util.Map<String,Object> body) {
        java.util.Optional<String> jobId =
                jobRepo.findTopByOrgIdAndNetworkVersionOrderBySubmittedAtDesc(
                        orgId.trim(), version.trim())
                .map(j -> j.getJobId());
        if (!jobId.isPresent())
            return ResponseEntity.notFound().build();

        if (body == null) body = new java.util.LinkedHashMap<>();
        body.put("jobId", jobId.get());
        body.put("orgId", orgId);
        // Delegate to revalidation controller logic
        boolean triggerExport = Boolean.parseBoolean(
                body.getOrDefault("triggerExport","false").toString());
        com.cim.service.RevalidationService.RevalidationResult result =
                revalidationService.startRevalidation(jobId.get(), orgId, triggerExport, null);
        return ResponseEntity.accepted().body(Map.of(
            "revalidationId", result.revalidationId,
            "jobId",          jobId.get(),
            "orgId",          orgId,
            "networkVersion", version,
            "triggerExport",  triggerExport,
            "status",         "RUNNING",
            "links",          Map.of(
                "status", "/api/cim/admin/revalidate/" + result.revalidationId)
        ));
    }

    /**
     * GET /api/cim/admin/neo4j/configs/orgs/{orgId}
     * List all export configs for an org (org-specific + global).
     */
    @GetMapping("/neo4j/configs/orgs/{orgId}")
    public ResponseEntity<?> configsByOrg(@PathVariable String orgId) {
        return ResponseEntity.ok(exportConfigRepo.findByOrgIdAndActiveTrue(orgId.trim()));
    }



    /**
     * POST /api/cim/admin/neo4j/cleanup-labels
     * Removes any unwanted labels like :CIMObject from old exports.
     */
    @ApiOperation(value = "Remove legacy labels from old Neo4j exports", response = CleanupLabelsResponse.class)
    @PostMapping("/neo4j/cleanup-labels")
    public ResponseEntity<?> cleanupLabels() {
        try {
            long removed = exportService.removeLegacyLabels();
            return ResponseEntity.ok(Map.of(
                "message", "Legacy labels removed.",
                "nodesUpdated", removed));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }
}
