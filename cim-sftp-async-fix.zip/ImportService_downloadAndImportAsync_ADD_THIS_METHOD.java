// ─────────────────────────────────────────────────────────────────────────────
// ADD THIS METHOD to your existing ImportService.java
//
// Also add this import at the top of ImportService.java if not already present:
//   import org.springframework.scheduling.annotation.Async;
//   import com.cim.service.FtpFileService;
//
// Also ensure @EnableAsync is on your Spring Boot main class or a @Configuration class.
// ─────────────────────────────────────────────────────────────────────────────

    /**
     * Downloads a large SFTP/FTP file to a local temp path and imports it —
     * all in a background thread. The HTTP thread has already returned 202.
     *
     * Flow:
     *   1. Download file via FtpFileService.downloadFile() → temp file
     *   2. Detect format from first 512 bytes
     *   3. Update the already-saved job record with the detected format
     *   4. Run processAndResolveFromPath() which handles parse + Neo4j export
     *   5. Delete the temp file (always, even on failure)
     *   6. On failure: update job status to FAILED with error message
     *
     * The caller can poll GET /api/jobs/{jobId} or GET /api/jobs/{jobId}/progress
     * to track the status and progress.
     *
     * @param ftpFileService  FTP/SFTP service used to download the file
     * @param fileName        Plain file name on the remote server (no directory)
     * @param jobId           Already-saved job ID — status starts as PROCESSING
     * @param networkVersion  CIM network version label
     * @param orgId           Organisation ID (e.g. "CAISO")
     * @param exportToNeo4j   Whether to run Neo4j export after MongoDB import
     */
    @org.springframework.scheduling.annotation.Async
    public void downloadAndImportAsync(
            com.cim.service.FtpFileService ftpFileService,
            String fileName,
            String jobId,
            String networkVersion,
            String orgId,
            boolean exportToNeo4j) {

        String tempFile = null;
        try {
            log.info("Async SFTP download starting: jobId={} fileName={}", jobId, fileName);

            // ── Step 1: Download to temp file ────────────────────────────────
            tempFile = ftpFileService.downloadFile(fileName);
            log.info("Async SFTP download complete: jobId={} tempFile={}", jobId, tempFile);

            // ── Step 2: Detect format from file header ────────────────────────
            java.io.File f = new java.io.File(tempFile);
            byte[] header = new byte[512];
            int n = 0;
            try (java.io.FileInputStream fis = new java.io.FileInputStream(f)) {
                n = fis.read(header, 0, 512);
            }
            String h = new String(header, 0, Math.max(n, 0));
            String format;
            if (h.contains("rdf:RDF") || h.contains("xmlns:cim")) format = "RDF_XML";
            else if (h.contains("@context") || h.contains("@graph")) format = "JSON_LD";
            else if (fileName.toLowerCase().endsWith(".csv")) format = "MILSOFT_CSV";
            else format = "RDF_XML";

            // ── Step 3: Patch job record with detected format ─────────────────
            jobRepo.findByJobId(jobId).ifPresent(j -> {
                j.setFormat(format);   // update from placeholder "RDF_XML" if needed
                jobRepo.save(j);
            });

            // ── Step 4: Run import (parse → MongoDB → Neo4j) ─────────────────
            processAndResolveFromPath(
                    tempFile, fileName, format, jobId, networkVersion, orgId, exportToNeo4j);

        } catch (Exception e) {
            log.error("Async SFTP import failed: jobId={} fileName={} error={}",
                    jobId, fileName, e.getMessage(), e);
            // Mark job as FAILED so the caller sees a terminal status when polling
            jobRepo.findByJobId(jobId).ifPresent(j -> {
                j.setStatus("FAILED");
                j.setErrorMessage("SFTP download/import failed: " + e.getMessage());
                jobRepo.save(j);
            });
        } finally {
            // ── Step 5: Always delete the temp file ───────────────────────────
            if (tempFile != null) {
                try {
                    boolean deleted = new java.io.File(tempFile).delete();
                    log.info("Async SFTP temp file {}: {}",
                            tempFile, deleted ? "deleted" : "could not delete");
                } catch (Exception ex) {
                    log.warn("Could not delete SFTP temp file {}: {}", tempFile, ex.getMessage());
                }
            }
        }
    }
