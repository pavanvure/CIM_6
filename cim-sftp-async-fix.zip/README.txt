CIM SFTP ASYNC + DUPLICATE FIX
==============================

Changes to apply:
─────────────────

1. ImportController.java  (REPLACE the existing file)
   - Large SFTP files (>50MB): now returns 202 IMMEDIATELY instead of blocking
     the HTTP thread during download. Download + import runs in background.
   - Duplicate pre-check: before starting any SFTP download (large OR small),
     checks by fileName+networkVersion if an active job already exists.
     Returns 409 instantly without touching the SFTP server.

2. ImportService_downloadAndImportAsync_ADD_THIS_METHOD.java
   - Add the downloadAndImportAsync() method to your ImportService.java.
   - This is the background worker: downloads file → detects format → imports.
   - Deletes temp file always (success or failure).
   - Sets job status to FAILED with error message if anything goes wrong.

3. ValidationJobRepository_ADD_THIS_METHOD.java
   - Add findBySourceFileAndNetworkVersionAndStatusIn() to your
     ValidationJobRepository interface (Spring Data — no implementation needed).

Required: @EnableAsync
──────────────────────
Add @EnableAsync to your Spring Boot main class or a @Configuration class
so that @Async on downloadAndImportAsync() actually runs in a thread pool:

    @SpringBootApplication
    @EnableAsync   // ← add this
    public class CimApplication { ... }

How it works after the fix:
────────────────────────────

  fileName = "BigFile.xml" (300 MB)

  Before fix:
    POST /api/import ──► [waits 3–5 minutes for SFTP download] ──► 202 response
                         HTTP thread blocked entire time

  After fix:
    POST /api/import ──► [checks duplicate, saves job, fires async] ──► 202 response (< 1 second)
                         Background thread: download → parse → import → delete temp
    GET /api/jobs/{jobId}/progress ──► poll for live progress

  Duplicate (same fileName + version, already RESOLVED):
    POST /api/import ──► 409 response (< 1 second, no SFTP connection opened)

FTP small files (≤50MB) — unchanged:
  Still streamed directly. Duplicate pre-check added here too (by fileName+version).

filePath (local server path) — unchanged:
  No changes to the existing synchronous/async local file handling.
