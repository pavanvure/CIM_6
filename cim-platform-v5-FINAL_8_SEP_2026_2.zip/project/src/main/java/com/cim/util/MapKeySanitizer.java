package com.cim.util;

import java.util.LinkedHashMap;
import java.util.Map;

public final class MapKeySanitizer {
    public static final String DOT  = ".";
    public static final String REPL = "_";      // underscore — MongoDB safe, human readable

    private MapKeySanitizer() {}

    public static String encode(String k)  { return k == null ? null : k.replace(DOT, REPL); }
    public static String decode(String k)  { return k == null ? null : k.replace(REPL, DOT); }

    public static Map<String,String> encodeKeys(Map<String,String> m) {
        if (m == null || m.isEmpty()) return new LinkedHashMap<>();
        Map<String,String> r = new LinkedHashMap<>(m.size());
        m.forEach((k,v) -> r.put(encode(k), v));
        return r;
    }

    public static Map<String,String> decodeKeys(Map<String,String> m) {
        if (m == null || m.isEmpty()) return new LinkedHashMap<>();
        Map<String,String> r = new LinkedHashMap<>(m.size());
        m.forEach((k,v) -> r.put(decode(k), v));
        return r;
    }
}
