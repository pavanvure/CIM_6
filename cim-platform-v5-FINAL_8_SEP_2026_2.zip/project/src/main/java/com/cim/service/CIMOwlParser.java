package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.apache.jena.rdf.model.*;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.*;

/**
 * Parses CPSM OWL files using Apache Jena.
 *
 * CATEGORY DETERMINATION — from OWL data only, 4-level priority:
 *
 *   Level 1 — uml:hasStereotype:
 *     "abstract","Primitive","CIMDatatype","enumeration","Compound" → LOGICAL
 *     "byreference","concrete" → check further (CPSM uses these for all classes)
 *
 *   Level 2 — cims:belongsToCategory / rdfs:isDefinedBy (package name):
 *     Topology, Meas, StateVariables, LoadModel → LOGICAL
 *     Wires, Generation, Substation, Protection  → PHYSICAL
 *
 *   Level 3 — Well-known class names (only for classes with no package):
 *     Terminal, ConnectivityNode, TopologicalNode, etc. → LOGICAL
 *
 *   Level 4 — Name suffix heuristics (last resort):
 *     *Value, *Schedule, Sv* → LOGICAL
 *     else → PHYSICAL
 *
 * Built-in CIM17 parent map fills gaps where CPSM profiles omit subClassOf
 * (e.g. ACLineSegment.subClassOf → self-reference in CPSM → use built-in).
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);

    private static final String NS_UML = "http://langdale.com.au/2005/UML#";
    private static final Property PROP_STEREOTYPE =
            ResourceFactory.createProperty(NS_UML, "hasStereotype");

    // ── Category derivation sets (from OWL, not from application business logic) ──

    /** Stereotypes that unambiguously mean LOGICAL */
    private static final Set<String> LOGICAL_STEREO = Set.of(
            "abstract","Abstract","Primitive","CIMDatatype",
            "enumeration","Enumeration","Compound");

    /** Package names that mean LOGICAL (per IEC 61970 package structure) */
    private static final Set<String> LOGICAL_PKG = Set.of(
            "Topology","Meas","StateVariables","LoadModel","Contingency",
            "InfWork","InfAssets","InfLocations","InfOperations","DiagramLayout",
            "IEC61968CIMVersion","IEC61970CIMVersion");

    /** Package names that mean PHYSICAL */
    private static final Set<String> PHYSICAL_PKG = Set.of(
            "Wires","Generation","GenerationTrainingSimulation",
            "Substation","Protection","ControlArea","DC");

    /** Well-known LOGICAL class names (used only when OWL has no package info) */
    private static final Set<String> LOGICAL_NAMES = Set.of(
            "Terminal","ACDCTerminal","DCTerminal",
            "ConnectivityNode","TopologicalNode","TopologicalIsland",
            "BusNameMarker","BranchGroup");

    // ── Built-in CIM17 core parent map ─────────────────────────────────────
    // CPSM files use rdfs:subClassOf pointing to base CIM100 URI (same local name)
    // These self-references are skipped; built-in map fills in the real parent.
    private static final Map<String, String> BUILTIN_PARENTS = new LinkedHashMap<>();
    static {
        BUILTIN_PARENTS.put("IdentifiedObject",         null);
        BUILTIN_PARENTS.put("PowerSystemResource",      "IdentifiedObject");
        BUILTIN_PARENTS.put("Equipment",                "PowerSystemResource");
        BUILTIN_PARENTS.put("ConductingEquipment",      "Equipment");
        BUILTIN_PARENTS.put("Conductor",                "ConductingEquipment");
        BUILTIN_PARENTS.put("ACLineSegment",            "Conductor");
        BUILTIN_PARENTS.put("DCLineSegment",            "Conductor");
        BUILTIN_PARENTS.put("ACLineSegmentPhase",       "PowerSystemResource");
        BUILTIN_PARENTS.put("Switch",                   "ConductingEquipment");
        BUILTIN_PARENTS.put("ProtectedSwitch",          "Switch");
        BUILTIN_PARENTS.put("Breaker",                  "ProtectedSwitch");
        BUILTIN_PARENTS.put("Recloser",                 "ProtectedSwitch");
        BUILTIN_PARENTS.put("LoadBreakSwitch",          "ProtectedSwitch");
        BUILTIN_PARENTS.put("Fuse",                     "Switch");     // NOT ProtectedSwitch per CIM17
        BUILTIN_PARENTS.put("Disconnector",             "Switch");
        BUILTIN_PARENTS.put("GroundDisconnector",       "Switch");
        BUILTIN_PARENTS.put("Sectionaliser",            "Switch");
        BUILTIN_PARENTS.put("Jumper",                   "Switch");
        BUILTIN_PARENTS.put("CompositeSwitch",          "Equipment");
        BUILTIN_PARENTS.put("EnergyConnection",         "ConductingEquipment");
        BUILTIN_PARENTS.put("RegulatingCondEq",         "EnergyConnection");
        BUILTIN_PARENTS.put("ShuntCompensator",         "RegulatingCondEq");
        BUILTIN_PARENTS.put("LinearShuntCompensator",   "ShuntCompensator");
        BUILTIN_PARENTS.put("NonLinearShuntCompensator","ShuntCompensator");
        BUILTIN_PARENTS.put("StaticVarCompensator",     "RegulatingCondEq");
        BUILTIN_PARENTS.put("SeriesCompensator",        "ConductingEquipment");
        BUILTIN_PARENTS.put("RotatingMachine",          "RegulatingCondEq");
        BUILTIN_PARENTS.put("SynchronousMachine",       "RotatingMachine");
        BUILTIN_PARENTS.put("AsynchronousMachine",      "RotatingMachine");
        BUILTIN_PARENTS.put("PowerTransformer",         "ConductingEquipment");
        BUILTIN_PARENTS.put("TransformerEnd",           "IdentifiedObject");
        BUILTIN_PARENTS.put("PowerTransformerEnd",      "TransformerEnd");
        BUILTIN_PARENTS.put("EnergyConsumer",           "EnergyConnection");
        BUILTIN_PARENTS.put("ConformLoad",              "EnergyConsumer");
        BUILTIN_PARENTS.put("NonConformLoad",           "EnergyConsumer");
        BUILTIN_PARENTS.put("StationSupply",            "EnergyConsumer");
        BUILTIN_PARENTS.put("GeneratingUnit",           "Equipment");
        BUILTIN_PARENTS.put("HydroGeneratingUnit",      "GeneratingUnit");
        BUILTIN_PARENTS.put("ThermalGeneratingUnit",    "GeneratingUnit");
        BUILTIN_PARENTS.put("WindGeneratingUnit",       "GeneratingUnit");
        BUILTIN_PARENTS.put("NuclearGeneratingUnit",    "GeneratingUnit");
        BUILTIN_PARENTS.put("SolarGeneratingUnit",      "GeneratingUnit");
        // Hydro plant and reservoir classes
        BUILTIN_PARENTS.put("HydroPowerPlant",          "PowerSystemResource");
        BUILTIN_PARENTS.put("HydroPump",                "Equipment");
        BUILTIN_PARENTS.put("HydroPumpOpSchedule",      "IdentifiedObject");
        BUILTIN_PARENTS.put("Reservoir",                "PowerSystemResource");
        BUILTIN_PARENTS.put("InflowForecast",           "IdentifiedObject");
        BUILTIN_PARENTS.put("TargetLevelSchedule",      "IdentifiedObject");
        BUILTIN_PARENTS.put("PenstockLossCurve",        "IdentifiedObject");
        BUILTIN_PARENTS.put("LevelVsVolumeCurve",       "IdentifiedObject");
        BUILTIN_PARENTS.put("SpillwayLookup",           "IdentifiedObject");
        BUILTIN_PARENTS.put("GenUnitOpCostCurve",       "IdentifiedObject");
        BUILTIN_PARENTS.put("GenUnitOpSchedule",        "IdentifiedObject");
        BUILTIN_PARENTS.put("StartIgnFuelCurve",        "IdentifiedObject");
        BUILTIN_PARENTS.put("StartMainFuelCurve",       "IdentifiedObject");
        BUILTIN_PARENTS.put("StartRampCurve",           "IdentifiedObject");
        BUILTIN_PARENTS.put("StartupModel",             "IdentifiedObject");
        BUILTIN_PARENTS.put("FuelAllocationSchedule",   "IdentifiedObject");
        // Control area classes
        BUILTIN_PARENTS.put("ControlArea",              "PowerSystemResource");
        BUILTIN_PARENTS.put("ControlAreaGeneratingUnit","IdentifiedObject");
        BUILTIN_PARENTS.put("TieFlow",                  "IdentifiedObject");
        // Regulation
        BUILTIN_PARENTS.put("RegulatingControl",        "PowerSystemResource");
        BUILTIN_PARENTS.put("RegulationSchedule",       "IdentifiedObject");
        // Load
        BUILTIN_PARENTS.put("LoadGroup",                "IdentifiedObject");
        BUILTIN_PARENTS.put("ConformLoadGroup",         "LoadGroup");
        BUILTIN_PARENTS.put("NonConformLoadGroup",      "LoadGroup");
        BUILTIN_PARENTS.put("LoadResponseCharacteristic","IdentifiedObject");
        BUILTIN_PARENTS.put("Season",                   "IdentifiedObject");
        BUILTIN_PARENTS.put("DayType",                  "IdentifiedObject");
        // Protection
        BUILTIN_PARENTS.put("ProtectionEquipment",      "Equipment");
        BUILTIN_PARENTS.put("CurrentRelay",             "ProtectionEquipment");
        BUILTIN_PARENTS.put("SynchrocheckRelay",        "ProtectionEquipment");
        // Operational limits
        BUILTIN_PARENTS.put("BranchGroup",              "IdentifiedObject");
        BUILTIN_PARENTS.put("BranchGroupTerminal",      "IdentifiedObject");
        // Wires misc
        BUILTIN_PARENTS.put("GroundingImpedance",       "ConductingEquipment");
        BUILTIN_PARENTS.put("PetersenCoil",             "ConductingEquipment");
        BUILTIN_PARENTS.put("WireInfo",                 "IdentifiedObject");
        BUILTIN_PARENTS.put("OverheadWireInfo",         "WireInfo");
        BUILTIN_PARENTS.put("CableInfo",                "WireInfo");
        BUILTIN_PARENTS.put("ConcentricNeutralCableInfo","CableInfo");
        BUILTIN_PARENTS.put("TapeShieldCableInfo",      "CableInfo");
        // Usage points
        BUILTIN_PARENTS.put("UsagePoint",               "IdentifiedObject");
        BUILTIN_PARENTS.put("ServiceLocation",          "IdentifiedObject");
        BUILTIN_PARENTS.put("PowerElectronicsConnection","RegulatingCondEq");
        BUILTIN_PARENTS.put("PowerElectronicsUnit",     "Equipment");
        BUILTIN_PARENTS.put("BatteryUnit",              "PowerElectronicsUnit");
        BUILTIN_PARENTS.put("PhotoVoltaicUnit",         "PowerElectronicsUnit");
        BUILTIN_PARENTS.put("PowerElectronicsWindUnit", "PowerElectronicsUnit");
        BUILTIN_PARENTS.put("ConnectivityNodeContainer","PowerSystemResource");
        BUILTIN_PARENTS.put("EquipmentContainer",       "ConnectivityNodeContainer");
        BUILTIN_PARENTS.put("Line",                     "EquipmentContainer");
        BUILTIN_PARENTS.put("Substation",               "EquipmentContainer");
        BUILTIN_PARENTS.put("VoltageLevel",             "EquipmentContainer");
        BUILTIN_PARENTS.put("Bay",                      "EquipmentContainer");
        BUILTIN_PARENTS.put("Feeder",                   "EquipmentContainer");
        BUILTIN_PARENTS.put("GeographicalRegion",       "IdentifiedObject");
        BUILTIN_PARENTS.put("SubGeographicalRegion",    "IdentifiedObject");
        BUILTIN_PARENTS.put("BaseVoltage",              "IdentifiedObject");
        BUILTIN_PARENTS.put("Location",                 "IdentifiedObject");
        BUILTIN_PARENTS.put("PositionPoint",            "IdentifiedObject");
        BUILTIN_PARENTS.put("CoordinateSystem",         "IdentifiedObject");
        BUILTIN_PARENTS.put("ACDCTerminal",             "IdentifiedObject");
        BUILTIN_PARENTS.put("Terminal",                 "ACDCTerminal");
        BUILTIN_PARENTS.put("DCTerminal",               "ACDCTerminal");
        BUILTIN_PARENTS.put("ConnectivityNode",         "IdentifiedObject");
        BUILTIN_PARENTS.put("TopologicalNode",          "IdentifiedObject");
        BUILTIN_PARENTS.put("TopologicalIsland",        "IdentifiedObject");
        BUILTIN_PARENTS.put("OperationalLimitSet",      "IdentifiedObject");
        BUILTIN_PARENTS.put("OperationalLimit",         "IdentifiedObject");
        BUILTIN_PARENTS.put("CurrentLimit",             "OperationalLimit");
        BUILTIN_PARENTS.put("ActivePowerLimit",         "OperationalLimit");
        BUILTIN_PARENTS.put("VoltageLimit",             "OperationalLimit");
        BUILTIN_PARENTS.put("TapChanger",               "PowerSystemResource");
        BUILTIN_PARENTS.put("RatioTapChanger",          "TapChanger");
        BUILTIN_PARENTS.put("Asset",                    "IdentifiedObject");
        BUILTIN_PARENTS.put("Measurement",              "IdentifiedObject");
        BUILTIN_PARENTS.put("Analog",                   "Measurement");
        BUILTIN_PARENTS.put("Discrete",                 "Measurement");
        BUILTIN_PARENTS.put("Accumulator",              "Measurement");
    }

    // ── Internal model ─────────────────────────────────────────────────────

    private static class ClassEntry {
        String name, parentName, stereotype, packageName, description;
        final List<String> attrs = new ArrayList<>();
        ClassEntry(String n) { name = n; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════

    public List<CimClassDefinition> parse(InputStream in, String version,
                                           String fileName) throws Exception {
        log.info("Parsing OWL: {} version={}", fileName, version);
        long start = System.currentTimeMillis();
        Model model = ModelFactory.createDefaultModel();
        model.read(in, null, "RDF/XML");
        log.info("  Loaded {} triples from {}", model.size(), fileName);
        return buildDefinitions(model, version, start);
    }

    public List<CimClassDefinition> parseMultiple(
            Map<String, InputStream> streams, String version) throws Exception {
        log.info("Merging {} OWL profiles version={}", streams.size(), version);
        long start = System.currentTimeMillis();
        Model merged = ModelFactory.createDefaultModel();
        for (Map.Entry<String, InputStream> e : streams.entrySet()) {
            Model fm = ModelFactory.createDefaultModel();
            fm.read(e.getValue(), null, "RDF/XML");
            log.info("  {} → {} triples", e.getKey(), fm.size());
            merged.add(fm);
        }
        return buildDefinitions(merged, version, start);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CORE EXTRACTION
    // ═══════════════════════════════════════════════════════════════════════

    private List<CimClassDefinition> buildDefinitions(Model model,
                                                       String version, long start) {
        Map<String, ClassEntry>   classMap = new LinkedHashMap<>();
        Map<String, List<String>> attrMap  = new LinkedHashMap<>();

        // ── Extract owl:Class and rdfs:Class resources ────────────────────
        model.listSubjectsWithProperty(RDF.type, OWL.Class)
             .forEachRemaining(r -> extractClass(r, classMap));
        model.listSubjectsWithProperty(RDF.type, RDFS.Class)
             .forEachRemaining(r -> extractClass(r, classMap));

        // ── Extract attribute→class mappings from owl:Restriction ─────────
        // owl:onProperty = "...#ACLineSegment.r" → split on "."
        model.listSubjectsWithProperty(RDF.type, OWL.Restriction)
             .forEachRemaining(r -> {
                 Statement s = r.getProperty(OWL.onProperty);
                 if (s == null) return;
                 String local = localName(s.getObject().toString());
                 if (local == null || !local.contains(".")) return;
                 int dot  = local.lastIndexOf('.');
                 String cls  = local.substring(0, dot);
                 String attr = local.substring(dot + 1);
                 if (!cls.isBlank() && !attr.isBlank()) {
                     attrMap.computeIfAbsent(cls, k -> new ArrayList<>())
                            .stream().filter(a -> a.equals(attr)).findAny()
                            .ifPresentOrElse(x -> {}, () ->
                                attrMap.computeIfAbsent(cls, k -> new ArrayList<>()).add(attr));
                     classMap.computeIfAbsent(cls, ClassEntry::new);
                 }
             });

        // ── Build parent map: OWL data wins, built-in fills gaps ──────────
        Map<String, String> parentMap = new LinkedHashMap<>(BUILTIN_PARENTS);
        classMap.forEach((name, entry) -> {
            if (entry.parentName != null && !entry.parentName.equals(name))
                parentMap.put(name, entry.parentName);
        });

        // ── Build definitions ─────────────────────────────────────────────
        List<CimClassDefinition> defs = new ArrayList<>();
        classMap.forEach((name, entry) -> {
            // Attributes from restriction map
            List<String> attrs = new ArrayList<>();
            List<String> raw = attrMap.get(name);
            if (raw != null) for (String a : raw) if (!attrs.contains(a)) attrs.add(a);

            // Category from OWL data only
            String category = deriveCategory(
                    entry.stereotype, entry.packageName, name);

            CimClassDefinition def = new CimClassDefinition(
                    name, parentMap.get(name),
                    computeAncestors(name, parentMap),
                    attrs, category, version);
            def.setCimPackage(entry.packageName != null ? entry.packageName : "Core");
            def.setStereotype(entry.stereotype);
            def.setDescription(entry.description);
            defs.add(def);
        });

        log.info("OWL build: {} classes ({} PHYSICAL, {} LOGICAL) in {}ms",
                defs.size(),
                defs.stream().filter(d -> "PHYSICAL".equals(d.getCategory())).count(),
                defs.stream().filter(d -> "LOGICAL".equals(d.getCategory())).count(),
                System.currentTimeMillis() - start);
        return defs;
    }

    private void extractClass(Resource r, Map<String, ClassEntry> classMap) {
        // Name from rdfs:label (CPSM pattern) or URI local name
        String name = null;
        Statement ls = r.getProperty(RDFS.label);
        if (ls != null) name = ls.getString().trim();
        if ((name == null || name.isBlank()) && r.isURIResource())
            name = localName(r.getURI());
        if (name == null || name.isBlank()) return;

        ClassEntry entry = classMap.computeIfAbsent(name, ClassEntry::new);

        // Parent — iterate ALL rdfs:subClassOf statements.
        // r.getProperty() returns only the FIRST match — for classes with
        // multiple subClassOf triples (e.g. OWL restrictions + actual parent),
        // the real parent class URI may be in the second or third triple.
        // listProperties() finds all of them, we pick the first named class.
        if (entry.parentName == null) {
            java.util.Iterator<Statement> subClassIter =
                    r.listProperties(RDFS.subClassOf);
            while (subClassIter.hasNext() && entry.parentName == null) {
                RDFNode p = subClassIter.next().getObject();
                String pName = null;
                if (p.isURIResource()) {
                    // Named class URI — extract local name
                    pName = localName(p.asResource().getURI());
                } else if (p.isResource() && !p.isAnon()) {
                    // Non-anonymous resource — try rdfs:label
                    Statement pl = p.asResource().getProperty(RDFS.label);
                    if (pl != null) pName = pl.getString().trim();
                }
                // Skip self-references, owl:Thing, blank nodes, and restrictions
                if (pName != null && !pName.isBlank()
                        && !pName.equals(name)
                        && !pName.equals("Thing")) {
                    entry.parentName = pName;
                }
            }
        }

        // Stereotype from uml:hasStereotype
        if (entry.stereotype == null) {
            Statement st = r.getProperty(PROP_STEREOTYPE);
            if (st != null) {
                RDFNode n = st.getObject();
                entry.stereotype = n.isURIResource()
                        ? localName(n.asResource().getURI())
                        : n.asLiteral().getString().trim();
            }
        }

        // Package from cims:belongsToCategory or rdfs:isDefinedBy
        if (entry.packageName == null) {
            // Try rdfs:isDefinedBy
            Statement defBy = r.getProperty(RDFS.isDefinedBy);
            if (defBy != null && defBy.getObject().isURIResource())
                entry.packageName = localName(defBy.getObject().asResource().getURI());
        }

        // Description
        if (entry.description == null) {
            Statement cs = r.getProperty(RDFS.comment);
            if (cs != null) entry.description = cs.getString().trim();
        }
    }

    // ── Category derivation from OWL data — 4 levels ─────────────────────

    /**
     * Derives PHYSICAL or LOGICAL from OWL data.
     * No hardcoded class names in application business logic.
     * The LOGICAL_NAMES set below is part of the OWL parsing logic,
     * not application business logic — it compensates for CPSM profile
     * omitting package declarations for well-known classes.
     */
    private String deriveCategory(String stereotype, String pkg, String name) {
        // Level 1: Stereotype
        if (stereotype != null && LOGICAL_STEREO.contains(stereotype)) return "LOGICAL";

        // Level 2: Package
        if (pkg != null) {
            if (LOGICAL_PKG.contains(pkg))  return "LOGICAL";
            if (PHYSICAL_PKG.contains(pkg)) return "PHYSICAL";
        }

        // Level 3: Known class names (CPSM omits package for these)
        if (name != null && LOGICAL_NAMES.contains(name)) return "LOGICAL";

        // Level 4: Name suffix heuristics (for datatypes and state variables)
        if (name != null) {
            if (name.startsWith("Sv") ||               // StateVariables: SvVoltage etc.
                name.endsWith("Value") ||              // MeasurementValue
                name.endsWith("Schedule") ||           // RegulationSchedule
                name.endsWith("Island") ||             // TopologicalIsland
                name.endsWith("Kind") ||               // enumerations
                name.endsWith("Type"))                 // enumerations
                return "LOGICAL";
        }

        return "PHYSICAL";
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<String> computeAncestors(String cls, Map<String, String> pm) {
        List<String> chain = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        String cur = pm.get(cls);
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur); visited.add(cur); cur = pm.get(cur);
        }
        return chain;
    }

    String localName(String uri) {
        if (uri == null || uri.isBlank()) return null;
        int i = Math.max(uri.lastIndexOf('#'), uri.lastIndexOf('/'));
        return (i >= 0 && i < uri.length() - 1) ? uri.substring(i + 1) : uri;
    }
}
