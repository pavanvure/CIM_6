package com.cim.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Defines two isolated async thread pools so that Neo4j export tasks
 * can never contend with — or be rejected by — the import executor.
 *
 * Problem solved:
 *   When importFile(exportToNeo4j=true) completes, it calls
 *   Neo4jExportExecutor.runAsync() from inside an import thread.
 *   Both @Async methods previously used the DEFAULT executor (pool=3,
 *   queue=0). With all 3 slots busy, the export submission was rejected:
 *
 *     RejectedExecutionException: ThreadPoolTaskExecutor
 *       [Running, pool size = 3, active threads = 3, queued tasks = 0]
 *
 * Fix: two named beans — each @Async is qualified with its own executor.
 *   "importExecutor"    — processes CIM file imports (parse + enrich)
 *   "neo4jExportExecutor" — runs Neo4j export jobs
 *
 * They are fully independent: submitting to neo4jExportExecutor from an
 * importExecutor thread is never rejected, regardless of import load.
 */
@Configuration
public class AsyncConfig {

    /**
     * Import executor: handles CIM file parse + reference resolution +
     * enrichment phases.  3 concurrent imports max (CIM parsing is
     * memory-intensive — keep small to avoid OOM).
     *
     * Queue of 5 lets burst submissions wait briefly rather than fail
     * immediately (e.g. rapid file uploads from the UI).
     */
    @Bean(name = "importExecutor")
    public Executor importExecutor() {
        ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
        exec.setCorePoolSize(3);
        exec.setMaxPoolSize(3);
        exec.setQueueCapacity(5);
        exec.setThreadNamePrefix("cim-import-");
        exec.setWaitForTasksToCompleteOnShutdown(true);
        exec.setAwaitTerminationSeconds(120);
        exec.initialize();
        return exec;
    }

    /**
     * Neo4j export executor: runs export jobs independently of imports.
     * 5 concurrent exports (network I/O bound, not memory intensive).
     *
     * Queue of 10 allows multi-variant export sets (up to 4 variants per
     * import) to queue safely when multiple imports complete simultaneously.
     */
    @Bean(name = "neo4jExportExecutor")
    public Executor neo4jExportExecutor() {
        ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
        exec.setCorePoolSize(5);
        exec.setMaxPoolSize(5);
        exec.setQueueCapacity(10);
        exec.setThreadNamePrefix("cim-neo4j-");
        exec.setWaitForTasksToCompleteOnShutdown(true);
        exec.setAwaitTerminationSeconds(300);   // export can take minutes
        exec.initialize();
        return exec;
    }

    /**
     * Revalidation executor: runs re-validation jobs (re-enrichment, re-export).
     * Kept separate from importExecutor so that a busy revalidation queue
     * cannot block new imports, and vice versa.
     *
     * Queue of 5 absorbs burst revalidation requests without rejection.
     */
    @Bean(name = "revalidationExecutor")
    public Executor revalidationExecutor() {
        ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
        exec.setCorePoolSize(3);
        exec.setMaxPoolSize(3);
        exec.setQueueCapacity(5);
        exec.setThreadNamePrefix("cim-reval-");
        exec.setWaitForTasksToCompleteOnShutdown(true);
        exec.setAwaitTerminationSeconds(300);
        exec.initialize();
        return exec;
    }
}
