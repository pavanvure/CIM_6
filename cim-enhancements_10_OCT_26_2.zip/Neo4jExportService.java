package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.Neo4jExportJob;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.model.mongo.ExportRequest.VersionType;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.Neo4jExportJobRepository;
import com.cim.repository.ValidationJobRepository;
import com.cim.repository.Neo4jExportConfigRepository;
import com.cim.model.mongo.Neo4jExportConfig;
import com.cim.util.MapKeySanitizer;
import org.neo4j.driver.*;
import org.neo4j.driver.exceptions.Neo4jException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

/**
 * Neo4j Export Service — v5
 *
 * Changes from previous version:
 *
 * REQ #1 — Index drop/rebuild removed.
 *           Indexes are maintained live. Heap tuning handles performance.
 *
 * No :CIMNode routing label — removed per manager request.
 * Label-less indexes on nodeKey/version/orgId used instead.
 *           Nodes have ONLY their specific cimType label (:ACLineSegment etc).
 *           Matches your existing Neo4j topology structure.
 *
 * REQ #3 — Three version types per export:
 *           FULL      → stored with version "{version}-0"
 *           SANITISED → stored with version "{version}-1" (default)
 *           RATIONALISED → stored with version "{version}-2"
 *
 * REQ #4 — OrgId specific: export uses jobId orgId + req.orgId override.
 *
 * Performance: per-label constraints created upfront, batch=5000.
 */
@Service
public class Neo4jExportService {

    private static final Logger log = LoggerFactory.getLogger(Neo4jExportService.class);

    @Value("${cim.neo4j.export.batch-size:5000}")
    private int batchSize;

    private final Driver                     driver;
    private final MongoTemplate              mongo;
    private final CimObjectRecordRepository  objectRepo;
    private final Neo4jExportJobRepository   exportRepo;
    private final ValidationJobRepository    jobRepo;
    private final Neo4jExportConfigRepository configRepo;

    // Tracks labels that already have a constraint this export run
    private final Set<String> constrainedLabels = new HashSet<>();

    private Neo4jExportExecutor executor;

    @org.springframework.beans.factory.annotation.Autowired
    public void setExecutor(Neo4jExportExecutor executor) { this.executor = executor; }

    public Neo4jExportService(Driver driver, MongoTemplate mongo,
                               CimObjectRecordRepository objectRepo,
                               Neo4jExportJobRepository exportRepo,
                               ValidationJobRepository jobRepo,
                               Neo4jExportConfigRepository configRepo) {
        this.driver      = driver;
        this.mongo       = mongo;
        this.objectRepo  = objectRepo;
        this.exportRepo  = exportRepo;
        this.jobRepo     = jobRepo;
        this.configRepo  = configRepo;
    }

    // ── Start export ──────────────────────────────────────────────────────

    /**
     * Starts a Neo4j export.
     *
     * SINGLE variant:   uses req.versionType + req.cimTypes
     * MULTI variant:    uses req.fullCimTypes + sanitisedCimTypes + rationalisedCimTypes
     *                   triggers three separate async export jobs
     *
     * Returns the first job created (or a summary job for multi-variant).
     */
    public Neo4jExportJob startExport(ExportRequest req) {
        String jobOrgId = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getOrgId() != null ? j.getOrgId() : "").orElse("");
        String orgId = (req.getOrgId() != null && !req.getOrgId().isBlank())
                       ? req.getOrgId().trim() : jobOrgId;

        String networkVersion = jobRepo.findByJobId(req.getJobId())
                .map(j -> j.getNetworkVersion() != null ? j.getNetworkVersion() : "")
                .orElse("");

        if (req.isMultiVariant()) {
            return startMultiVariantExport(req, networkVersion, orgId);
        }

        // FROM_CONFIG: load cimTypes from stored Neo4jExportConfig
        if (req.getMode() == ExportRequest.ExportMode.FROM_CONFIG) {
            return startFromConfig(req, networkVersion, orgId);
        }

        // Single variant with explicit cimTypes in request
        return startSingleExport(req, networkVersion, orgId,
                req.getVersionType() != null
                        ? req.getVersionType() : ExportRequest.VersionType.SANITISED,
                req.getCimTypes());
    }

    /**
     * FROM_CONFIG: load the stored Neo4jExportConfig and decide:
     *
     *   Case 1 — versionType NOT set (null) OR all three lists populated in config:
     *     → Trigger ALL configured variants as multi-variant export.
     *     → FULL(-0) triggered if config.fullCimTypes is not empty.
     *     → SANITISED(-1) triggered if config.sanitisedCimTypes is not empty.
     *     → RATIONALISED(-2) triggered if config.rationalisedCimTypes is not empty.
     *
     *   Case 2 — versionType IS explicitly set (FULL / SANITISED / RATIONALISED):
     *     → Trigger only that specific variant.
     *     → e.g. versionType=RATIONALISED → only config.rationalisedCimTypes → {version}-2
     *
     * This way:
     *   triggerExport=true in revalidation (no versionType) → all three variants
     *   Manual export with versionType=SANITISED → only sanitised
     */
    private Neo4jExportJob startFromConfig(ExportRequest req,
                                            String networkVersion, String orgId) {
        if (req.getConfigId() == null || req.getConfigId().isBlank())
            throw new IllegalArgumentException(
                    "configId required when mode=FROM_CONFIG");

        Neo4jExportConfig cfg = configRepo.findById(req.getConfigId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Neo4jExportConfig not found: " + req.getConfigId()));

        // FIX: versionType field defaults to SANITISED in ExportRequest, so
        // req.getVersionType() is NEVER null — the old null check always
        // resolved to "single variant", never reaching multi-variant.
        //
        // New rule: go single-variant ONLY when the caller also provided an
        // explicit cimTypes list (meaning they want that specific variant with
        // their own types). If cimTypes is empty, they want FROM_CONFIG to
        // drive ALL variants from the stored config lists.
        boolean wantsSingleVariant = req.getVersionType() != null
                && !req.getCimTypes().isEmpty();

        if (wantsSingleVariant) {
            // Caller specified both a versionType AND a cimTypes list explicitly
            List<String> types = req.getCimTypes();
            log.info("FROM_CONFIG single variant (caller-supplied types): config='{}' variant={} types={}",
                    cfg.getConfigName(), req.getVersionType(), types.size());
            return startSingleExport(req, networkVersion, orgId, req.getVersionType(), types);
        }

        // Caller specified only a versionType (no cimTypes) — load from config
        // for THAT specific variant only
        if (req.getCimTypes().isEmpty()
                && req.getVersionType() != ExportRequest.VersionType.SANITISED) {
            // Non-default versionType explicitly set → single variant from config
            List<String> types = getTypesForVariant(cfg, req.getVersionType());
            if (!types.isEmpty()) {
                log.info("FROM_CONFIG single variant (from config): config='{}' variant={} types={}",
                        cfg.getConfigName(), req.getVersionType(), types.size());
                return startSingleExport(req, networkVersion, orgId, req.getVersionType(), types);
            }
        }

        // Case 1: no versionType specified → trigger ALL configured variants
        // Build a multi-variant request from the stored config lists
        ExportRequest multiReq = new ExportRequest();
        multiReq.setJobId(req.getJobId());
        multiReq.setOrgId(orgId);
        multiReq.setClearFirst(req.isClearFirst());

        if (cfg.getFullCimTypes()           != null && !cfg.getFullCimTypes().isEmpty())
            multiReq.setFullCimTypes(cfg.getFullCimTypes());
        if (cfg.getSanitisedCimTypes()      != null && !cfg.getSanitisedCimTypes().isEmpty())
            multiReq.setSanitisedCimTypes(cfg.getSanitisedCimTypes());
        if (cfg.getRationalisedCimTypes()   != null && !cfg.getRationalisedCimTypes().isEmpty())
            multiReq.setRationalisedCimTypes(cfg.getRationalisedCimTypes());
        if (cfg.getCustomCimTypes()         != null && !cfg.getCustomCimTypes().isEmpty()) {
            multiReq.setCustomCimTypes(cfg.getCustomCimTypes());
            if (cfg.getCustomNeoVersion()   != null && !cfg.getCustomNeoVersion().isBlank())
                multiReq.setNeoVersion(cfg.getCustomNeoVersion());
        }

        if (!multiReq.isMultiVariant())
            throw new IllegalArgumentException(
                    "Config '" + cfg.getConfigName()
                    + "' has no cimTypes configured in any variant list.");

        log.info("FROM_CONFIG multi-variant: config='{}' full={} sanitised={} rationalised={}",
                cfg.getConfigName(),
                multiReq.getFullCimTypes().size(),
                multiReq.getSanitisedCimTypes().size(),
                multiReq.getRationalisedCimTypes().size());

        return startMultiVariantExport(multiReq, networkVersion, orgId);
    }

    private List<String> getTypesForVariant(Neo4jExportConfig cfg,
                                             ExportRequest.VersionType vType) {
        if (vType == ExportRequest.VersionType.FULL)
            return cfg.getFullCimTypes()      != null ? cfg.getFullCimTypes()      : new ArrayList<>();
        if (vType == ExportRequest.VersionType.RATIONALISED)
            return cfg.getRationalisedCimTypes() != null ? cfg.getRationalisedCimTypes() : new ArrayList<>();
        return cfg.getSanitisedCimTypes()     != null ? cfg.getSanitisedCimTypes() : new ArrayList<>();
    }

    /**
     * Triggers three separate export jobs — one per variant.
     * Each uses its own cimType list and version suffix.
     */
    private Neo4jExportJob startMultiVariantExport(ExportRequest req,
                                                    String networkVersion,
                                                    String orgId) {
        Neo4jExportJob firstJob = null;

        // FULL (-0)
        if (!req.getFullCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.FULL, req.getFullCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: FULL ({}-0) triggered — {} cimTypes",
                    networkVersion, req.getFullCimTypes().size());
        }

        // SANITISED (-1)
        if (!req.getSanitisedCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.SANITISED, req.getSanitisedCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: SANITISED ({}-1) triggered — {} cimTypes",
                    networkVersion, req.getSanitisedCimTypes().size());
        }

        // RATIONALISED (-2)
        if (!req.getRationalisedCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.RATIONALISED, req.getRationalisedCimTypes());
            if (firstJob == null) firstJob = j;
            log.info("Multi-variant: RATIONALISED ({}-2) triggered — {} cimTypes",
                    networkVersion, req.getRationalisedCimTypes().size());
        }

        // CUSTOM — REQ 6: user-provided version string
        if (!req.getCustomCimTypes().isEmpty()) {
            Neo4jExportJob j = startSingleExport(req, networkVersion, orgId,
                    ExportRequest.VersionType.CUSTOM, req.getCustomCimTypes());
            if (firstJob == null) firstJob = j;
            String custVer = req.getNeoVersion() != null ? req.getNeoVersion() : "custom";
            log.info("Multi-variant: CUSTOM ({}) triggered — {} cimTypes",
                    custVer, req.getCustomCimTypes().size());
        }

        return firstJob;
    }

    /**
     * ENHANCEMENT 3: Resolve FROM_CONFIG mode.
     * Loads cimType list from the specified Neo4jExportConfig document.
     */
    private List<String> resolveFromConfig(ExportRequest req,
                                            ExportRequest.VersionType vType) {
        if (req.getConfigId() == null || req.getConfigId().isBlank())
            throw new IllegalArgumentException(
                    "configId required when mode=FROM_CONFIG");
        Neo4jExportConfig cfg = configRepo.findById(req.getConfigId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Neo4jExportConfig not found: " + req.getConfigId()));
        List<String> types;
        if (vType == ExportRequest.VersionType.FULL)
            types = cfg.getFullCimTypes();
        else if (vType == ExportRequest.VersionType.RATIONALISED)
            types = cfg.getRationalisedCimTypes();
        else
            types = cfg.getSanitisedCimTypes();  // SANITISED default

        if (types == null || types.isEmpty())
            throw new IllegalArgumentException(
                    "Config '" + cfg.getConfigName() + "' has no cimTypes for variant "
                    + vType.name());
        log.info("FROM_CONFIG resolved: config='{}' variant={} types={}",
                cfg.getConfigName(), vType, types.size());
        return types;
    }

    private Neo4jExportJob startSingleExport(ExportRequest req,
                                              String networkVersion,
                                              String orgId,
                                              ExportRequest.VersionType vType,
                                              List<String> typesForVariant) {
        String exportId     = UUID.randomUUID().toString();
        String neo4jVersion = req.buildNeo4jVersion(networkVersion, vType);

        Neo4jExportJob job = new Neo4jExportJob(
                exportId, req.getJobId(), neo4jVersion, orgId,
                "CUSTOM_" + vType.name());
        exportRepo.save(job);

        // Force-include types required for topology simplification.
        // NOTE: VoltageLevel and BaseVoltage are NO LONGER force-included.
        // They were previously needed for post-Neo4j nominalVoltage enrichment
        // (associateNominalVoltage) but that enrichment now runs during import
        // (Phase 3 CimEnrichmentService, MongoDB-based) — so Neo4j no longer
        // needs VoltageLevel/BaseVoltage for enrichment.
        // Only Terminal, ConnectivityNode, BusbarSection remain force-included
        // for RATIONALISED Pass 3 topology simplification.
        List<String> effectiveTypes = typesForVariant;
        if (vType == ExportRequest.VersionType.RATIONALISED) {
            java.util.LinkedHashSet<String> withRequired =
                    new java.util.LinkedHashSet<>(typesForVariant);
            withRequired.add("Terminal");
            withRequired.add("ConnectivityNode");
            withRequired.add("BusbarSection");
            effectiveTypes = new ArrayList<>(withRequired);
            log.info("RATIONALISED: force-included Terminal/ConnectivityNode/BusbarSection. "
                    + "Configured: {} Effective: {}",
                    typesForVariant.size(), effectiveTypes.size());
        }

        // Build a single-variant request for the executor
        ExportRequest singleReq = new ExportRequest(
                req.getJobId(),
                ExportRequest.ExportMode.CUSTOM,
                effectiveTypes,
                req.isClearFirst());
        singleReq.setVersionType(vType);
        singleReq.setOrgId(orgId);

        executor.runAsync(singleReq, job);
        return job;
    }

    // ── Called by executor on async thread ───────────────────────────────

    public void runExport(ExportRequest req, Neo4jExportJob job) {
        try {
            job.setStatus("RUNNING");
            exportRepo.save(job);
            long start = System.currentTimeMillis();
            // NOTE: constrainedLabels is intentionally NOT cleared here.
            // It tracks which Neo4j constraints already exist — this is
            // GLOBAL state safe to share across concurrent exports, since
            // "CREATE INDEX ... IF NOT EXISTS" is idempotent regardless.
            // Clearing it per-call was the bug: concurrent multi-variant
            // exports would wipe each other's tracking, causing wasted
            // re-creation attempts and, under heavier concurrency, risked
            // racing on the underlying HashSet (not thread-safe).

            // Per-export state — local to THIS call, never shared across
            // concurrent variants. See ExportContext for why this matters.
            ExportContext ctx = new ExportContext();

            // Resolve effective orgId
            String orgId = job.getOrgId();
            // neo4jVersion already has suffix (e.g. "DB140-1")
            String neo4jVersion = job.getNetworkVersion();

            // Clear existing nodes if requested
            long nodesCleared = 0;
            if (req.isClearFirst()) {
                nodesCleared = clearExistingNodesCount(neo4jVersion, orgId);
            }

            // Use CREATE mode only if clearFirst=true AND clear succeeded (or was empty)
            // If clear failed midway, fall back to MERGE to avoid duplicates
            ctx.useBulkCreate = req.isClearFirst();
            // Note: clearExistingNodes logs warnings on partial failure
            // For production safety, MERGE handles duplicates even if clear was partial

            // Load non-CIM flags:
            //   includeNonCimNs    = include vendor ATTRIBUTES (caiso:, spc: etc.)
            //   includeNonCimNodes = include non-CIM NODES (category=UNKNOWN/null)
            ctx.includeNonCimNs    = false;
            ctx.includeNonCimNodes = req.isIncludeNonCim(); // request default=true

            if (req.getMode() == ExportRequest.ExportMode.FROM_CONFIG
                    && req.getConfigId() != null) {
                Neo4jExportConfig cfg = configRepo.findById(req.getConfigId()).orElse(null);
                if (cfg != null) {
                    ctx.includeNonCimNs    = cfg.isIncludeNonCimNamespaces();
                    ctx.includeNonCimNodes = cfg.isIncludeNonCimNodes();
                }
            }
            log.info("version={} includeNonCimNodes={} includeNonCimNs={}",
                    neo4jVersion, ctx.includeNonCimNodes, ctx.includeNonCimNs);

            // Create per-label constraints upfront (safe to share globally —
            // see note above; createConstraintsUpfront has its own
            // already-exists short-circuit)
            createConstraintsUpfront(req);

            Instant exportStart = Instant.now();
            recordExportPhase(req.getJobId(), "NEO4J_EXPORT_STARTED",
                    exportStart, exportStart, 0, "RUNNING",
                    String.format("Neo4j export started: version=%s mode=%s clearFirst=%b",
                            neo4jVersion, req.getMode(), req.isClearFirst()));

            int[] counts = twoPassExport(req, job, neo4jVersion, orgId, ctx);

            Instant exportEnd = Instant.now();
            job.setStatus("DONE");
            job.setNodesExported(counts[0]);
            job.setRelsExported(counts[1]);
            job.setCompletedAt(exportEnd);
            job.setProcessingMs(System.currentTimeMillis() - start);
            exportRepo.save(job);

            // Append COMPLETED phase to validation_jobs — uses $push so
            // repeated exports append entries rather than overwriting
            recordExportPhase(req.getJobId(), "NEO4J_EXPORT",
                    exportStart, exportEnd, counts[0], "COMPLETED",
                    String.format("Exported %,d nodes and %,d relationships to Neo4j " +
                                  "in %s. version=%s mode=%s",
                            counts[0], counts[1],
                            com.cim.model.mongo.StageTimings.format(
                                    System.currentTimeMillis() - start),
                            neo4jVersion, req.getMode()));

            log.info("Export DONE: mode={} version={} orgId={} nodes={} rels={} in {}",
                    req.getMode(), neo4jVersion, orgId, counts[0], counts[1],
                    com.cim.model.mongo.StageTimings.format(
                            System.currentTimeMillis() - start));

        } catch (Exception e) {
            log.error("Export FAILED: {}", e.getMessage(), e);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(Instant.now());
            exportRepo.save(job);

            // Append FAILED phase to validation_jobs
            recordExportPhase(req.getJobId(), "NEO4J_EXPORT",
                    Instant.now(), Instant.now(), 0, "FAILED",
                    "Neo4j export failed: " + e.getMessage());
        }
    }

    // ── Two-pass export ───────────────────────────────────────────────────

    private int[] twoPassExport(ExportRequest req, Neo4jExportJob job,
                                  String neo4jVersion, String orgId,
                                  ExportContext ctx) {
        int totalNodes = 0, totalRels = 0;
        long total = mongo.count(new Query(buildCriteria(req, ctx)), "cim_objects");
        log.info("Pass 1 — {} nodes batch={} version={} orgId={}",
                total, batchSize, neo4jVersion, orgId);

        long start = System.currentTimeMillis();
        String lastId = null;
        int page = 0;

        // ── Pass 1: Nodes ─────────────────────────────────────────────────
        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId, ctx);
            if (batch.isEmpty()) break;

            totalNodes += writeNodes(batch, neo4jVersion, orgId, ctx);
            lastId = batch.get(batch.size() - 1).getId();
            page++;

            if (page % 20 == 0) {
                long el   = System.currentTimeMillis() - start;
                long rate = el > 0 ? totalNodes * 1000L / el : 0;
                long eta  = rate > 0 ? (total - totalNodes) / rate / 60 : -1;
                log.info("Pass 1: page={} nodes={}/{} rate={}/s eta={}min",
                        page, totalNodes, total, rate, eta);
                job.setNodesExported(totalNodes);
                exportRepo.save(job);
            }
        }
        log.info("Pass 1 DONE — {} nodes in {}",
                totalNodes,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));

        // Note: separate :OPEN node creation (createOpenStateNodes) has been
        // removed. Replaced by applyOpenLabel() — a simpler approach that
        // adds :OPEN directly as a label on the switch node itself, run as
        // part of the CAISO-specific post-processing block after Pass 2.

        // ── Pass 2: Relationships ─────────────────────────────────────────
        // Build pass-through index for topology collapse (stored in ctx —
        // local to this export call, not shared across concurrent variants)
        Set<String> exportedTypes = req.getCimTypes() != null
                ? new java.util.HashSet<>(req.getCimTypes())
                : java.util.Collections.emptySet();
        buildPassThroughIndex(req.getJobId(), exportedTypes, ctx);

        log.info("Pass 2 — relationships");
        start = System.currentTimeMillis();
        lastId = null; page = 0;

        while (true) {
            List<CimObjectRecord> batch = fetchPage(req, lastId, ctx);
            if (batch.isEmpty()) break;

            totalRels += writeRelationships(batch, neo4jVersion, orgId, ctx);
            lastId = batch.get(batch.size() - 1).getId();
            page++;

            if (page % 20 == 0) {
                log.info("Pass 2: page={} rels={}", page, totalRels);
                job.setRelsExported(totalRels);
                exportRepo.save(job);
            }
        }
        log.info("Pass 2 DONE — {} rels in {}",
                totalRels,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));

        // Free pass-through index memory (ctx is local to this call —
        // no risk of clearing another concurrent variant's index)
        ctx.passThroughIndex.clear();

        // ── CAISO enrichment ────────────────────────────────────────────────
        // associateNominalVoltage runs for FULL + SANITISED + RATIONALISED.
        // ── Graph enrichment (nominalVoltage + substation) ───────────────
        // REPLACED BY Phase 3 CimEnrichmentService (runs during import).
        // nominalVoltage_1, substationMrid_N, substationName_N are now
        // pre-computed in MongoDB at import time and exported automatically
        // as regular node properties — no post-export graph traversal needed.
        //
        // applyIntertieLabel (:TIE_LINE) and applyOpenLabel (:OPEN) still
        // run here — they set Neo4j LABELS (not properties) which cannot
        // be pre-computed in MongoDB.
        ExportRequest.VersionType vType = req.getVersionType();
        // Apply TIE_LINE and OPEN labels for SANITISED and RATIONALISED only.
        // FULL (-0) exports raw topology without label classification.
        ExportRequest.VersionType vType = req.getVersionType();
        if (vType == ExportRequest.VersionType.SANITISED
                || vType == ExportRequest.VersionType.RATIONALISED) {
            log.info("Applying Neo4j labels (TIE_LINE, OPEN) for version={}", neo4jVersion);
            applyIntertieLabel(neo4jVersion, orgId, vType);
            applyOpenLabel(neo4jVersion, orgId);
        }

        // ── Pass 3: RATIONALISED topology simplification ─────────────────
        // Only runs for RATIONALISED variant. Collapses pass-through
        // Terminal/ConnectivityNode nodes into direct [:UC_TO] relationships,
        // producing a simplified "rationalised" topology graph.
        // Must run BEFORE :CIMNode removal — these queries rely on :CIMNode
        // existing on all nodes for efficient generic (t)--(n) matching.
        if (req.getVersionType() == ExportRequest.VersionType.RATIONALISED) {
            log.info("Pass 3 — RATIONALISED topology simplification...");
            long p3start = System.currentTimeMillis();
            long simplified = simplifyRationalisedTopology(neo4jVersion, orgId);
            log.info("Pass 3 DONE — {} nodes collapsed in {}",
                    simplified,
                    com.cim.model.mongo.StageTimings.format(
                            System.currentTimeMillis() - p3start));
        }

        // ── Pass 4: Remove :CIMNode routing label ─────────────────────────
        // :CIMNode was added during export for fast O(log n) MATCH in Pass 2
        // and used by Pass 3's topology simplification queries.
        // Now that export is complete, remove it — manager sees only clean
        // equipment labels (:ACLineSegment, :Breaker, :Substation etc.)
        log.info("Pass 4 — removing :CIMNode routing label...");
        long p4start = System.currentTimeMillis();
        long labelsRemoved = removeCimNodeLabel(neo4jVersion, orgId);
        log.info("Pass 4 DONE — :CIMNode removed from {} nodes in {}",
                labelsRemoved,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - p4start));

        return new int[]{totalNodes, totalRels};
    }

    /**
     * Appends a Neo4j export phase entry to the validation_jobs document.
     * Uses MongoDB $push so repeated exports APPEND to phaseHistory,
     * not overwrite — giving a full audit trail of every export attempt.
     *
     * This is identical to ImportService.recordPhase() but lives here
     * so Neo4jExportService has no dependency on ImportService.
     */
    private void recordExportPhase(String jobId, String phase,
                                    Instant startedAt, Instant completedAt,
                                    long objectsProcessed, String status,
                                    String description) {
        if (jobId == null || jobId.isBlank()) return;
        try {
            com.cim.model.mongo.PhaseRecord record =
                    new com.cim.model.mongo.PhaseRecord(
                            phase, startedAt, completedAt,
                            objectsProcessed, status, null, description);
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(
                            org.springframework.data.mongodb.core.query.Criteria
                                    .where("jobId").is(jobId));
            org.springframework.data.mongodb.core.query.Update u =
                    new org.springframework.data.mongodb.core.query.Update()
                            .push("phaseHistory", record);
            mongo.updateFirst(q, u, "validation_jobs");
        } catch (Exception e) {
            log.warn("recordExportPhase failed (non-fatal): job={} phase={} err={}",
                    jobId, phase, e.getMessage());
        }
    }

    // ── Per-export state — encapsulated, NOT instance fields ─────────────
    //
    // FIX: Neo4jExportService is a singleton Spring bean. Multi-variant
    // exports (FULL+SANITISED+RATIONALISED) run CONCURRENTLY on different
    // @Async threads via Neo4jExportExecutor, but all previously shared
    // ONE set of instance fields (useBulkCreate, includeNonCimNs,
    // includeNonCimNodes, passThroughIndex). Concurrent variants
    // overwrote each other's settings mid-export, causing:
    //   - wrong CREATE/MERGE mode for some variants
    //   - wrong non-CIM filtering for some variants
    //   - corrupted topology-collapse data shared across variants
    //
    // Each call to runExport() now creates its own ExportContext and
    // threads it through every private method that needs this state —
    // no shared mutable fields, no cross-variant interference, and
    // multi-variant exports still run fully concurrently (no slowdown).
    private static class ExportContext {
        boolean useBulkCreate;
        boolean includeNonCimNs;
        boolean includeNonCimNodes;
        final java.util.concurrent.ConcurrentHashMap<String, PassThroughEntry>
                passThroughIndex = new java.util.concurrent.ConcurrentHashMap<>();
    }

    /**
     * Write nodes using CREATE (clearFirst) or MERGE (incremental).
     *
     * CREATE mode (clearFirst=true):
     *   - No duplicate check needed — nodes were just deleted
     *   - No index lookup per node — pure append write
     *   - 10-20x faster than MERGE: O(1) vs O(log n) per node
     *   - No MERGE scan degradation as node count grows
     *
     * MERGE mode (incremental):
     *   - Safe when existing nodes may be present
     *   - Uses per-label constraint for O(log n) lookup
     *   - Slower but correct for partial re-exports
     */
    private static class PassThroughEntry {
        final String cimType;
        final Map<String, String> refs; // attrName → targetRdfId (decoded)
        PassThroughEntry(String cimType, Map<String, String> refs) {
            this.cimType = cimType;
            this.refs    = refs != null ? refs : new java.util.LinkedHashMap<>();
        }
    }

    private int writeNodes(List<CimObjectRecord> records,
                            String neo4jVersion, String orgId,
                            ExportContext ctx) {
        if (records.isEmpty()) return 0;

        Map<String, List<Map<String, Object>>> byLabel = new LinkedHashMap<>();
        for (CimObjectRecord rec : records) {
            String label = sanitizeLabel(rec.getCimType());
            byLabel.computeIfAbsent(label, k -> new ArrayList<>())
                   .add(buildNodeProps(rec, neo4jVersion, orgId, ctx));
        }

        int written = 0;
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byLabel.entrySet()) {
                String label = e.getKey();
                List<Map<String, Object>> nodeBatch = e.getValue();
                String cypher;

                if (ctx.useBulkCreate) {
                    // CREATE — pure append, no lookup, no index maintenance during write
                    // :CIMNode is a shared routing label added to ALL nodes.
                    // This enables ONE index (CIMNode.nodeKey) used by Pass 2 MATCH.
                    // Without it, MATCH (src {nodeKey:...}) scans all 953K nodes = slow.
                    // Users still query by specific label (:ACLineSegment etc).
                    cypher = "UNWIND $batch AS p " +
                             "CREATE (n:" + label + ":CIMNode) SET n = p";
                } else {
                    // MERGE — idempotent, uses per-label constraint
                    ensureLabelConstraint(s, label);
                    cypher = "UNWIND $batch AS p " +
                             "MERGE (n:" + label + ":CIMNode {nodeKey: p.nodeKey}) " +
                             "SET n += p";
                }

                final String fc = cypher;
                final List<Map<String, Object>> fb = nodeBatch;
                try {
                    s.executeWrite(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += nodeBatch.size();

                } catch (Neo4jException ex) {
                    log.warn("Node write failed {}: {}", label, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeNodes: {}", e.getMessage());
        }
        return written;
    }

    // ── Build node properties — version type variant handling (REQ #3) ────

    private Map<String, Object> buildNodeProps(CimObjectRecord rec,
                                                String neo4jVersion,
                                                String orgId,
                                                ExportContext ctx) {
        Map<String, Object> p = new LinkedHashMap<>();
        String r = rec.getRdfId() != null ? rec.getRdfId() : "";
        String o = orgId         != null ? orgId           : "";

        // nodeKey uses neo4jVersion which already has suffix (e.g. "DB140-1")
        p.put("nodeKey",  r + "|" + neo4jVersion + "|" + o);
        p.put("mrid",     rec.getMrid()    != null ? rec.getMrid()    : r);
        p.put("rdfId",    r);
        p.put("name",     rec.getName()    != null ? rec.getName()    : "");
        p.put("cimType",  rec.getCimType() != null ? rec.getCimType() : "Unknown");
        p.put("version",  neo4jVersion);   // "DB140-0", "DB140-1", or "DB140-2"
        p.put("orgId",    o);
        p.put("category", rec.getCategory() != null ? rec.getCategory() : "");
        p.put("uri",      rec.getSourceFile() != null ? rec.getSourceFile() : "");

        // REQ 3: Attribute filtering based on isCimStandard flag in namespace_configs
        // includeNonCimNs=true  → store all attributes (CIM standard + vendor)
        // includeNonCimNs=false → store only CIM standard attributes (no colon prefix)
        if (rec.getAttributes() != null) {
            MapKeySanitizer.decodeKeys(rec.getAttributes()).forEach((k, v) -> {
                if (k == null || v == null || v.isBlank()) return;
                boolean isVendorAttr = k.contains(":");
                if (!isVendorAttr || ctx.includeNonCimNs) {
                    p.put(k, v);
                }
            });
        }
        return p;
    }

    // ── Write relationships ───────────────────────────────────────────────

    private int writeRelationships(List<CimObjectRecord> records,
                                    String neo4jVersion, String orgId,
                                    ExportContext ctx) {
        if (records.isEmpty()) return 0;

        // Collect all edges — using collectEdges() which handles topology collapse.
        // For each ref, if the target is an excluded cimType (in passThroughIndex),
        // the algorithm walks THROUGH it to find the next included node,
        // preserving the original first-hop attribute name as the relationship type.
        //
        // Group by relType for batched Cypher execution.
        Map<String, List<Map<String, Object>>> byRelType = new LinkedHashMap<>();

        for (CimObjectRecord rec : records) {
            if (rec.getResolvedRefIds() == null || rec.getResolvedRefIds().isEmpty()) continue;
            String srcRdfId = rec.getRdfId() != null ? rec.getRdfId() : "";

            // Decode keys and collect edges with topology collapse
            Map<String, String> decodedRefs =
                    MapKeySanitizer.decodeKeys(rec.getResolvedRefIds());

            List<Map<String, Object>> edges = new ArrayList<>();
            Set<String> visited = new java.util.HashSet<>();
            visited.add(srcRdfId); // prevent src→src cycles
            collectEdges(srcRdfId, decodedRefs, neo4jVersion, orgId,
                    edges, null, visited, ctx);

            for (Map<String, Object> edge : edges) {
                String relType = (String) edge.get("relType");
                byRelType.computeIfAbsent(relType, k -> new ArrayList<>()).add(edge);
            }
        }

        int written = 0;
        try (Session s = driver.session()) {
            for (Map.Entry<String, List<Map<String, Object>>> e : byRelType.entrySet()) {
                String relType = e.getKey();
                List<Map<String, Object>> relBatch = e.getValue();
                String cypher =
                    "UNWIND $batch AS r " +
                    "MATCH (src:CIMNode {nodeKey: r.srcKey}) " +
                    "MATCH (tgt:CIMNode {nodeKey: r.tgtKey}) " +
                    "MERGE (src)-[:" + relType +
                    " {version: r.version, orgId: r.orgId}]->(tgt)";
                final String fc = cypher;
                final List<Map<String, Object>> fb = relBatch;
                try {
                    s.executeWrite(tx -> {
                        tx.run(fc, Values.parameters("batch", fb));
                        return null;
                    });
                    written += relBatch.size();
                } catch (Neo4jException ex) {
                    log.warn("Rel write failed {}: {}", relType, ex.getMessage());
                }
            }
        } catch (Exception e) {
            log.warn("Session error writeRelationships: {}", e.getMessage());
        }
        return written;
    }

    // ── Constraint creation (upfront, per label) ──────────────────────────

    private void createConstraintsUpfront(ExportRequest req) {
        if (constrainedLabels.size() > 0) return;
        log.info("Creating constraints and indexes...");
        long start = System.currentTimeMillis();

        // Label-less indexes — no :CIMNode label needed.
        // Neo4j 4.4+ supports label-less indexes and uses them for
        // MATCH (n {nodeKey:...}) and MATCH (n {version:...}) queries.
        String[][] sharedIndexes = {
            // CRITICAL: used by Pass 2 MATCH (src {nodeKey: r.srcKey})
            {"nodekey_idx",
             "CREATE INDEX nodekey_idx IF NOT EXISTS FOR (n) ON (n.nodeKey)"},
            // Used by clearExistingNodes and version-filtered queries
            {"version_idx",
             "CREATE INDEX version_idx IF NOT EXISTS FOR (n) ON (n.version)"},
            // Used by org-filtered queries
            {"orgid_idx",
             "CREATE INDEX orgid_idx IF NOT EXISTS FOR (n) ON (n.orgId)"},
            // Used by mRID lookups
            {"mrid_idx",
             "CREATE INDEX mrid_idx IF NOT EXISTS FOR (n) ON (n.mrid)"},
        };
        for (String[] idx : sharedIndexes) {
            try (Session s = driver.session()) {
                s.run(idx[1]);
                log.debug("Index ensured: {}", idx[0]);
            } catch (Exception e) {
                log.debug("Index note {}: {}", idx[0], e.getMessage());
            }
        }
        log.info("Label-less indexes ready — Pass 2 MATCH uses nodekey_idx");

        org.springframework.data.mongodb.core.aggregation.Aggregation agg =
            org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation(
                org.springframework.data.mongodb.core.aggregation.Aggregation
                        .match(buildCriteria(req)),
                org.springframework.data.mongodb.core.aggregation.Aggregation
                        .group("cimType")
            );

        List<org.bson.Document> results = mongo.aggregate(
                agg, "cim_objects", org.bson.Document.class).getMappedResults();

        int created = 0;
        for (org.bson.Document doc : results) {
            Object ct = doc.get("_id");
            if (ct == null) continue;
            String label = sanitizeLabel(ct.toString());
            if (constrainedLabels.contains(label)) continue;
            try (Session s = driver.session()) {
                s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                      "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
                constrainedLabels.add(label);
                created++;
            } catch (Exception e) {
                constrainedLabels.add(label);
            }
        }
        log.info("Constraints ready: {} labels in {}",
                constrainedLabels.size(),
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start));
    }

    private void ensureLabelConstraint(Session s, String label) {
        if (constrainedLabels.contains(label)) return;
        try {
            s.run("CREATE CONSTRAINT " + label + "_nodekey IF NOT EXISTS " +
                  "ON (n:" + label + ") ASSERT n.nodeKey IS UNIQUE");
            constrainedLabels.add(label);
        } catch (Exception e) {
            constrainedLabels.add(label);
        }
    }

    // ── Clear existing nodes (batched, version+orgId scoped) ─────────────

    /**
     * Delete all nodes for a given version+orgId from Neo4j.
     *
     * THREE-STEP APPROACH (prevents transaction timeouts):
     *
     *   Step 1: Delete all RELATIONSHIPS first (batched).
     *           A Substation may have 50K+ relationships.
     *           DETACH DELETE 1000 nodes could mean deleting millions of rels
     *           in one transaction → TransactionDeadlockException / timeout.
     *           Deleting rels first makes DETACH DELETE safe (no rels left).
     *
     *   Step 2: Delete :CIMNode nodes (batch 5000 — fast, index-backed).
     *           All rels already gone → DETACH DELETE = simple node delete.
     *
     *   Step 3: Removed. No :CIMNode label used anymore.
     *
     * DUPLICATE RISK if clear fails:
     *   CREATE mode (useBulkCreate=true): creates NEW nodes regardless.
     *     → duplicates if old nodes exist. Clear MUST succeed.
     *   MERGE mode (useBulkCreate=false): upserts existing nodes.
     *     → no duplicates regardless. Clear just cleans old extra nodes.
     */
    private long clearExistingNodesCount(String neo4jVersion, String orgId) {
        clearExistingNodes(neo4jVersion, orgId);
        return 0L; // count logged inside clearExistingNodes
    }

    /**
     * Public API — delete all Neo4j nodes and relationships for a given
     * version + orgId combination. Used by the data management DELETE endpoint.
     * Delegates to the same batched-deletion logic used before each export.
     */
    public void deleteNeo4jData(String neo4jVersion, String orgId) {
        log.info("deleteNeo4jData requested: version={} orgId={}", neo4jVersion, orgId);
        clearExistingNodes(neo4jVersion, orgId);
        log.info("deleteNeo4jData complete: version={} orgId={}", neo4jVersion, orgId);
    }

    private void clearExistingNodes(String neo4jVersion, String orgId) {
        log.info("Clearing nodes: version={} orgId={}", neo4jVersion, orgId);
        long relsDeleted = 0, nodesDeleted = 0;

        // ── Step 1: Delete relationships first ───────────────────────────
        // Batch: 10000 rels per transaction (relationships are lightweight)
        log.info("Step 1: deleting relationships for version={} orgId={}",
                neo4jVersion, orgId);
        // Step 1: Delete relationships
        // FIX: consume Result INSIDE writeTransaction lambda — not outside.
        // In Neo4j Driver 4.4.x, Result is only valid within the transaction.
        // Accessing r.single() after writeTransaction() returns = result already closed.
        while (true) {
            try (Session s = driver.session()) {
                long d = s.executeWrite(tx -> {
                    Result r = tx.run(
                        "MATCH (n {version: $v, orgId: $o})-[rel]-() " +
                        "WITH rel LIMIT 10000 DELETE rel RETURN count(rel) AS d",
                        Values.parameters("v", neo4jVersion, "o", orgId));
                    return r.single().get("d").asLong(); // consumed inside tx ✅
                });
                relsDeleted += d;
                if (d == 0) break;
            } catch (Exception e) {
                log.warn("Rel delete batch error (retrying): {}", e.getMessage());
                try { Thread.sleep(500); } catch (InterruptedException ie) { break; }
            }
        }
        log.info("Relationships deleted: {}", relsDeleted);

        // Step 2: Delete :CIMNode nodes
        log.info("Step 2: deleting nodes for version={} orgId={}",
                neo4jVersion, orgId);
        int retries = 0;
        while (retries < 3) {
            boolean hadError = false;
            while (true) {
                try (Session s = driver.session()) {
                    long d = s.executeWrite(tx -> {
                        Result r = tx.run(
                            "MATCH (n {version: $v, orgId: $o}) " +
                            "WITH n LIMIT 5000 DELETE n RETURN count(n) AS d",
                            Values.parameters("v", neo4jVersion, "o", orgId));
                        return r.single().get("d").asLong(); // consumed inside tx ✅
                    });
                    nodesDeleted += d;
                    if (d == 0) break;
                } catch (Exception e) {
                    log.warn("Node delete batch error: {}", e.getMessage());
                    hadError = true;
                    break;
                }
            }
            if (!hadError) break;
            retries++;
            try { Thread.sleep(1000); } catch (InterruptedException ie) { break; }
        }

        // Step 3: Not needed. :CIMNode removed — Step 2 handles all nodes.

        log.info("Clear complete: {} relationships + {} nodes deleted (version={} orgId={})",
                relsDeleted, nodesDeleted, neo4jVersion, orgId);

        if (nodesDeleted == 0 && relsDeleted == 0)
            log.info("No existing data found for version={} orgId={} — fresh export",
                    neo4jVersion, orgId);
    }

    // ── Cursor pagination ─────────────────────────────────────────────────

    private List<CimObjectRecord> fetchPage(ExportRequest req, String lastId,
                                             ExportContext ctx) {
        Criteria criteria = buildCriteria(req, ctx);
        if (lastId != null && !lastId.isBlank()) {
            criteria = new Criteria().andOperator(
                    criteria,
                    Criteria.where("_id").gt(
                            new org.bson.types.ObjectId(lastId)));
        }
        return mongo.find(
                new Query(criteria)
                        .limit(batchSize)
                        .with(Sort.by(Sort.Direction.ASC, "_id")),
                CimObjectRecord.class, "cim_objects");
    }

    private Criteria buildCriteria(ExportRequest req, ExportContext ctx) {
        String jobId = req.getJobId();

        // CUSTOM with cimTypes list — used by all multi-variant exports
        if (req.getMode() == ExportMode.CUSTOM
                && req.getCimTypes() != null && !req.getCimTypes().isEmpty()) {

            // includeNonCimNs=true: also export non-CIM objects (category=UNKNOWN/null)
            // alongside the explicit cimTypes list.
            // Non-CIM objects have cimType like "VendorWidget" — not in standard list.
            // Two ways to include them:
            //   1. Add their cimType names to the export config's cimTypes list (explicit)
            //   2. Set includeNonCimNamespaces=true on Neo4jExportConfig (automatic)
            if (ctx.includeNonCimNodes) {
                return new Criteria().andOperator(
                        Criteria.where("jobId").is(jobId),
                        new Criteria().orOperator(
                                Criteria.where("cimType").in(req.getCimTypes()),
                                Criteria.where("category").is("UNKNOWN"),
                                Criteria.where("category").isNull()
                        )
                );
            }
            return Criteria.where("jobId").is(jobId)
                    .and("cimType").in(req.getCimTypes());
        }

        if (req.getMode() == ExportMode.PHYSICAL_ONLY) {
            if (ctx.includeNonCimNodes) {
                // PHYSICAL + vendor types (UNKNOWN/null category)
                return new Criteria().andOperator(
                        Criteria.where("jobId").is(jobId),
                        new Criteria().orOperator(
                                Criteria.where("category").is("PHYSICAL"),
                                Criteria.where("category").is("UNKNOWN"),
                                Criteria.where("category").isNull()
                        )
                );
            }
            return Criteria.where("jobId").is(jobId).and("category").is("PHYSICAL");
        }
        if (req.getMode() == ExportMode.REQUIRED_ONLY) {
            return Criteria.where("jobId").is(jobId).and("isRequired").is(true);
        }
        if (req.getMode() == ExportMode.TOPOLOGY) {
            List<String> logicalTypes = Arrays.asList(
                    "Terminal","ConnectivityNode","TopologicalNode","TopologicalIsland");
            List<Criteria> orList = new ArrayList<>();
            orList.add(Criteria.where("category").is("PHYSICAL"));
            orList.add(Criteria.where("cimType").in(logicalTypes));
            if (ctx.includeNonCimNodes) {
                orList.add(Criteria.where("category").is("UNKNOWN"));
                orList.add(Criteria.where("category").isNull());
            }
            return new Criteria().andOperator(
                    Criteria.where("jobId").is(jobId),
                    new Criteria().orOperator(
                            orList.toArray(new Criteria[0]))
            );
        }
        // ALL mode — returns everything including non-CIM nodes by default
        return Criteria.where("jobId").is(jobId);
    }

    // ── Label sanitizer ───────────────────────────────────────────────────

    private String sanitizeLabel(String t) {
        if (t == null || t.isBlank()) return "Unknown";
        return t.replaceAll("[^A-Za-z0-9_]", "_");
    }

    // ── Topology Collapse — Pass-Through Index ───────────────────────────

    /**
     * Builds the pass-through index before Pass 2.
     *
     * Queries cim_objects for ALL objects whose cimType is NOT in the export list.
     * Stores their rdfId + resolvedRefIds in passThroughIndex for O(1) lookup
     * during collectEdges() walk.
     *
     * Uses lightweight projection — only rdfId, cimType, resolvedRefIds.
     * No attributes loaded — keeps memory footprint small.
     *
     * @param jobId       import job ID
     * @param exportedTypes  set of cimTypes being exported (from export config)
     */
    /**
     * Builds the pass-through index — but ONLY for bridgeable types
     * (Terminal, ConnectivityNode) that are excluded from the export config.
     *
     * Other excluded types (Measurement, Analog, SvPowerFlow, vendor types
     * etc.) are deliberately NOT indexed here — collectEdges() will not
     * bridge through them, so there is no need to load their refs at all.
     * This also keeps the index small and fast to build.
     */
    private void buildPassThroughIndex(String jobId, Set<String> exportedTypes,
                                        ExportContext ctx) {
        ctx.passThroughIndex.clear();
        if (exportedTypes.isEmpty()) return;

        // Only consider bridgeable types that are NOT already in the export list.
        // If Terminal/ConnectivityNode are both already exported, nothing to index.
        Set<String> bridgeableExcluded = new java.util.HashSet<>();
        for (String t : BRIDGEABLE_TYPES) {
            if (!exportedTypes.contains(t)) bridgeableExcluded.add(t);
        }
        if (bridgeableExcluded.isEmpty()) {
            log.info("Terminal/ConnectivityNode already in export config — "
                    + "no pass-through index needed");
            return;
        }

        log.info("Building pass-through index for: {}", bridgeableExcluded);
        long start = System.currentTimeMillis();

        // Stream only the bridgeable-excluded objects in pages
        int PAGE = 2000;
        String lastId = null;
        long total = 0;

        while (true) {
            // Criteria: same job, cimType is one of the bridgeable-excluded types
            Criteria criteria = Criteria.where("jobId").is(jobId)
                    .and("cimType").in(bridgeableExcluded);
            if (lastId != null)
                criteria = new Criteria().andOperator(criteria,
                        Criteria.where("_id").gt(
                                new org.bson.types.ObjectId(lastId)));

            // Projection: only fields needed for topology walk — no attributes
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(criteria)
                            .limit(PAGE)
                            .with(org.springframework.data.domain.Sort.by(
                                    org.springframework.data.domain.Sort.Direction.ASC, "_id"));
            q.fields()
                    .include("rdfId")
                    .include("cimType")
                    .include("resolvedRefIds");

            List<com.cim.model.mongo.CimObjectRecord> batch =
                    mongo.find(q, com.cim.model.mongo.CimObjectRecord.class, "cim_objects");

            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();

            for (com.cim.model.mongo.CimObjectRecord rec : batch) {
                if (rec.getRdfId() == null) continue;
                // Decode resolvedRefIds keys (U+FF0E → dot)
                Map<String, String> decodedRefs = rec.getResolvedRefIds() != null
                        ? MapKeySanitizer.decodeKeys(rec.getResolvedRefIds())
                        : new java.util.LinkedHashMap<>();
                ctx.passThroughIndex.put(rec.getRdfId(),
                        new PassThroughEntry(rec.getCimType(), decodedRefs));
                total++;
            }
        }

        log.info("Pass-through index built: {} excluded objects in {}ms — "
                + "topology collapse enabled for excluded cimTypes",
                total, System.currentTimeMillis() - start);
    }

    /**
     * Collect edges from a source object's resolvedRefIds, collapsing through
     * any excluded cimTypes encountered.
     *
     * For each ref:
     *   - If target is an INCLUDED node → emit edge directly
     *   - If target is an EXCLUDED node → walk through its refs recursively
     *     until we reach an INCLUDED node (or exhaust all paths)
     *   - Cycle protection via visitedRdfIds set
     *
     * @param srcRdfId      rdfId of the source (included) object
     * @param refs          resolvedRefIds of the source (attrName → targetRdfId)
     * @param neo4jVersion  version string for nodeKey
     * @param orgId         orgId for nodeKey
     * @param edges         output — list of (srcKey, tgtKey, relType) maps
     * @param firstHopName  the original attribute name from the very first hop
     *                      (preserved as relType when collapsing through excluded)
     * @param visited       cycle protection — rdfIds already visited in this walk
     */
    /**
     * Types allowed to be walked-through (bridged) when excluded from the
     * export's cimTypes list. These are structural topology connectors —
     * the whole point of CIM modeling is that equipment connects via them,
     * so bypassing them when excluded preserves a meaningful equipment graph.
     *
     * Any OTHER excluded type (Measurement, Analog, SvPowerFlow, vendor
     * types etc.) is NOT a topology connector — if the user excluded it
     * from config, that path is intentionally left disconnected. No
     * relationship is created through it.
     */
    private static final Set<String> BRIDGEABLE_TYPES =
            new java.util.HashSet<>(Arrays.asList("Terminal", "ConnectivityNode"));

    private void collectEdges(String srcRdfId, Map<String, String> refs,
                               String neo4jVersion, String orgId,
                               List<Map<String, Object>> edges,
                               String firstHopName,
                               Set<String> visited,
                               ExportContext ctx) {
        if (refs == null || refs.isEmpty()) return;
        String o = orgId != null ? orgId : "";

        for (Map.Entry<String, String> entry : refs.entrySet()) {
            String attrName   = entry.getKey();   // e.g. "Terminal.ConductingEquipment"
            String targetRdfId = entry.getValue(); // e.g. "_line1"
            if (targetRdfId == null || targetRdfId.isBlank()) continue;

            // Determine the relationship type for this edge:
            // If we are at the first hop: use attrName as-is
            // If we are in a recursive walk: preserve the ORIGINAL first-hop name
            String relType = firstHopName != null ? firstHopName : attrName;

            PassThroughEntry excluded = ctx.passThroughIndex.get(targetRdfId);

            if (excluded != null) {
                // Target is EXCLUDED from the export config.
                // Only bridge through Terminal/ConnectivityNode — these are
                // structural connectors and must remain navigable even when
                // the node itself isn't exported. Any other excluded type
                // (Measurement, Analog, vendor types etc.) is a genuine
                // omission — skip this path entirely, no relationship created.
                if (!BRIDGEABLE_TYPES.contains(excluded.cimType)) {
                    continue; // skip — do not bypass, do not emit an edge
                }

                if (visited.contains(targetRdfId)) continue; // cycle protection
                visited.add(targetRdfId);

                // Recurse: walk through the excluded object's own refs
                // Keep original relType (firstHopName) for the eventual edge
                collectEdges(srcRdfId, excluded.refs,
                        neo4jVersion, orgId, edges,
                        relType,   // preserve first-hop name through all levels
                        visited, ctx);
            } else {
                // Target is INCLUDED — emit direct edge
                Map<String, Object> edge = new java.util.LinkedHashMap<>();
                edge.put("srcKey",  srcRdfId    + "|" + neo4jVersion + "|" + o);
                edge.put("tgtKey",  targetRdfId + "|" + neo4jVersion + "|" + o);
                edge.put("version", neo4jVersion);
                edge.put("orgId",   o);
                edge.put("relType", "`" + relType.replace("`", "") + "`");
                edges.add(edge);
            }
        }
    }

    // ── Batched property write helper ────────────────────────────────────

    /**
     * Writes properties onto Neo4j nodes in batches — one transaction per
     * group of nodes that share the same set of property keys.
     *
     * WHY: Writing one transaction per node (the naive approach) causes
     * 50,000+ roundtrips for large datasets → 15+ minutes.
     * Grouping by property key signature reduces this to ~100 transactions
     * (one per distinct property combination) → seconds.
     *
     * HOW: Items with the same property keys (e.g. all nodes with just
     * "nominalVoltage_1") are batched together into one UNWIND query.
     * The SET clause is built once per group from the shared key set.
     * Values are passed as a List<Map> with fixed keys per batch.
     *
     * @param updates  list of {nodeKey: "...", props: {key: value, ...}}
     * @param batchSize max nodes per transaction (500 recommended)
     * @param logLabel  prefix for warn log messages
     * @return total number of nodes successfully updated
     */
    private long batchWriteProperties(List<Map<String, Object>> updates,
                                       int batchSize, String logLabel) {
        if (updates.isEmpty()) return 0;

        // Group updates by their property key signature (sorted key names joined)
        // so all nodes with the same keys go into one UNWIND batch
        java.util.Map<String, List<Map<String, Object>>> byKeySignature =
                new java.util.LinkedHashMap<>();

        for (Map<String, Object> upd : updates) {
            @SuppressWarnings("unchecked")
            Map<String, Object> props = (Map<String, Object>) upd.get("props");
            if (props == null || props.isEmpty()) continue;
            // Signature = sorted comma-joined property names
            String sig = props.keySet().stream()
                    .sorted()
                    .collect(java.util.stream.Collectors.joining(","));
            byKeySignature.computeIfAbsent(sig, k -> new ArrayList<>()).add(upd);
        }

        long total = 0;

        for (Map.Entry<String, List<Map<String, Object>>> sigEntry
                : byKeySignature.entrySet()) {

            // Build one SET clause for this key signature
            // e.g. "n.`nominalVoltage_1` = item.v0, n.`nominalVoltage_2` = item.v1"
            @SuppressWarnings("unchecked")
            Map<String, Object> sampleProps =
                    (Map<String, Object>) sigEntry.getValue().get(0).get("props");
            List<String> sortedKeys = sampleProps.keySet().stream()
                    .sorted().collect(java.util.stream.Collectors.toList());

            StringBuilder setClauses = new StringBuilder();
            for (int i = 0; i < sortedKeys.size(); i++) {
                if (setClauses.length() > 0) setClauses.append(", ");
                setClauses.append("n.`").append(sortedKeys.get(i))
                          .append("` = item.v").append(i);
            }
            String setClause = setClauses.toString();

            // Build each batch item as {nodeKey: ..., v0: ..., v1: ..., ...}
            List<Map<String, Object>> allItems = new ArrayList<>();
            for (Map<String, Object> upd : sigEntry.getValue()) {
                @SuppressWarnings("unchecked")
                Map<String, Object> props = (Map<String, Object>) upd.get("props");
                Map<String, Object> item = new java.util.LinkedHashMap<>();
                item.put("nodeKey", upd.get("nodeKey"));
                int vi = 0;
                for (String key : sortedKeys) {
                    item.put("v" + vi++, props.get(key));
                }
                allItems.add(item);
            }

            // Write in sub-batches of batchSize
            for (int from = 0; from < allItems.size(); from += batchSize) {
                int to = Math.min(from + batchSize, allItems.size());
                final List<Map<String, Object>> batch = allItems.subList(from, to);
                final String fSetClause = setClause;
                try (Session s = driver.session()) {
                    s.executeWrite(tx -> {
                        tx.run(
                            "UNWIND $batch AS item " +
                            "MATCH (n {nodeKey: item.nodeKey}) " +
                            "SET " + fSetClause,
                            Values.parameters("batch", batch));
                        return null;
                    });
                    total += batch.size();
                } catch (Exception e) {
                    log.warn("{} batch write error (keys={}): {}",
                            logLabel, sigEntry.getKey(), e.getMessage());
                }
            }
        }
        return total;
    }

    // ── RATIONALISED Topology Simplification (pure Cypher, no APOC) ──────

    /**
     * Simplifies the topology graph for the RATIONALISED variant by collapsing
     * pass-through Terminal and ConnectivityNode patterns into direct [:UC_TO]
     * relationships. Runs three sub-steps in order:
     *
     *   Step 1: Collapse 2-degree Terminal nodes
     *           (A)--(t:Terminal)--(B)  →  (A)-[:UC_TO]->(B), delete t
     *
     *   Step 2: Collapse ConnectivityNode at a BusbarSection (fan-in/fan-out)
     *           (n1,n2,n3)--(cn:ConnectivityNode)--(b:BusbarSection)
     *             → (n1)-[:UC_TO]->(b), (n2)-[:UC_TO]->(b), (n3)-[:UC_TO]->(b)
     *               delete cn
     *
     *   Step 3: Collapse remaining 2-degree ConnectivityNode nodes
     *           Same pattern as Step 1, applied to ConnectivityNode
     *
     * ORDER MATTERS: Step 1 simplifies Terminals first, Step 2 handles
     * busbar fan-in next, Step 3 catches any ConnectivityNodes that became
     * 2-degree as a side effect of Step 2.
     *
     * Direction rule for Steps 1 and 3: the node whose label is
     * alphabetically smaller becomes the source (fromNode) — gives a
     * consistent, deterministic direction regardless of which side of the
     * original pattern each equipment type was on.
     *
     * Implemented as pure-Cypher batched loops via the Java driver —
     * equivalent to apoc.periodic.iterate but requires no APOC plugin.
     * Same batching pattern as clearExistingNodes()/createOpenStateNodes().
     */
    private long simplifyRationalisedTopology(String neo4jVersion, String orgId) {
        // Step 1: collapse pass-through Terminal nodes (exactly 2 connections)
        long step1 = collapseTwoDegreeNodes("Terminal", neo4jVersion, orgId);
        log.info("RATIONALISED Step 1 — {} Terminal nodes collapsed", step1);

        // Step 2: collapse ConnectivityNode sitting between equipment and a BusbarSection
        // (fan-in/fan-out pattern — CN connects to 1 busbar + N other nodes)
        long step2 = collapseConnectivityNodeAtBusbar(neo4jVersion, orgId);
        log.info("RATIONALISED Step 2 — {} ConnectivityNode (busbar fan-in) collapsed", step2);

        // Step 3: collapse ConnectivityNode nodes with exactly 2 connections.
        // Runs AFTER Step 1 and Step 2 because:
        //   - Step 1 removes Terminals, which may reduce a CN's degree from 3→2
        //   - Step 2 removes busbar-CNs, which may expose additional 2-degree CNs
        // The collapseTwoDegreeNodes loop keeps running until no 2-degree CNs remain,
        // so cascading collapses (CN collapses exposing another 2-degree CN) are handled.
        long step3 = collapseTwoDegreeNodes("ConnectivityNode", neo4jVersion, orgId);
        log.info("RATIONALISED Step 3 — {} ConnectivityNode (2-degree) collapsed", step3);

        // Step 4: re-run Terminal collapse — after CN removal some Terminals may now
        // have exactly 2 connections that weren't visible in Step 1.
        long step4 = collapseTwoDegreeNodes("Terminal", neo4jVersion, orgId);
        log.info("RATIONALISED Step 4 — {} Terminal nodes collapsed (post-CN cleanup)", step4);

        long total = step1 + step2 + step3 + step4;
        log.info("RATIONALISED simplification complete — {} total nodes collapsed", total);
        return total;
    }

    /**
     * Step 1 / Step 3 — Collapse pass-through nodes of a given label that
     * have exactly 2 neighbors. Connects the two neighbors directly via
     * [:UC_TO {version, orgId}] and deletes the pass-through node.
     *
     * Pure-Cypher translation of:
     *   MATCH (t:{label})--(n) WHERE t.orgId=$o AND n.version=$v
     *   WITH t, COUNT(n) AS connectionCount WHERE connectionCount = 2
     *   ... (direction logic) ...
     *   MERGE (fromNode)-[:UC_TO]->(toNode)
     *   DETACH DELETE t
     *
     * Batched: processes up to {batchSize} candidate nodes per transaction,
     * loops until no more 2-degree nodes of this label remain.
     */
    private long collapseTwoDegreeNodes(String label, String neo4jVersion, String orgId) {
        long total = 0;
        int  BATCH = 2000;

        while (true) {
            try (Session s = driver.session()) {
                long processed = s.executeWrite(tx -> {
                    // FIX: filter to exactly-2-degree nodes FIRST, then LIMIT.
                    // Previous query did LIMIT before the degree filter, so batches
                    // were filled with high-degree nodes, processed=0 fired too early,
                    // and the while-loop exited leaving 2-degree CNs un-collapsed.
                    Result r = tx.run(
                        "MATCH (t:" + label + ":CIMNode {version: $v, orgId: $o}) " +
                        "MATCH (t)--(n) WHERE n.version = $v AND n.orgId = $o " +
                        "WITH t, collect(DISTINCT n) AS neighbors " +
                        "WHERE size(neighbors) = 2 " +          // degree filter BEFORE limit
                        "WITH t, neighbors[0] AS n1, neighbors[1] AS n2 " +
                        "LIMIT $batch " +                        // limit only 2-degree candidates
                        "WITH t, n1, n2, " +
                        "     head(labels(n1)) AS l1, " +
                        "     head(labels(n2)) AS l2 " +
                        "WITH t, " +
                        "     CASE WHEN l1 <= l2 THEN n1 ELSE n2 END AS fromNode, " +
                        "     CASE WHEN l1 <= l2 THEN n2 ELSE n1 END AS toNode " +
                        "MERGE (fromNode)-[:UC_TO {version: $v, orgId: $o}]->(toNode) " +
                        "WITH DISTINCT t " +
                        "DETACH DELETE t " +
                        "RETURN count(t) AS processed",
                        Values.parameters("v", neo4jVersion, "o", orgId, "batch", BATCH));
                    return r.single().get("processed").asLong();
                });
                total += processed;
                if (processed == 0) break;
            } catch (Exception e) {
                log.warn("collapseTwoDegreeNodes({}) batch error: {}", label, e.getMessage());
                break;
            }
        }
        return total;
    }

    /**
     * Step 2 — Collapse ConnectivityNode at a BusbarSection (fan-in/fan-out).
     * Every OTHER neighbor of the ConnectivityNode gets a direct [:UC_TO]
     * relationship to the BusbarSection; the ConnectivityNode is deleted.
     *
     * Pure-Cypher translation of:
     *   MATCH (cn:ConnectivityNode)--(b:BusbarSection)
     *   MATCH (cn)--(n) WHERE n <> b
     *   WITH cn, b, collect(n) AS neighbors
     *   UNWIND neighbors AS n
     *   MERGE (n)-[:UC_TO]->(b)
     *   DETACH DELETE cn
     */
    private long collapseConnectivityNodeAtBusbar(String neo4jVersion, String orgId) {
        long total = 0;
        int  BATCH = 1000; // smaller batch — each cn may fan out to several neighbors

        while (true) {
            try (Session s = driver.session()) {
                long processed = s.executeWrite(tx -> {
                    Result r = tx.run(
                        "MATCH (cn:ConnectivityNode:CIMNode {version: $v, orgId: $o})" +
                        "--(b:BusbarSection {version: $v, orgId: $o}) " +
                        "WITH DISTINCT cn, b LIMIT $batch " +
                        "MATCH (cn)--(n) WHERE n.orgId = $o AND n <> b " +
                        "WITH cn, b, collect(DISTINCT n) AS neighbors " +
                        "UNWIND neighbors AS n " +
                        "MERGE (n)-[:UC_TO {version: $v, orgId: $o}]->(b) " +
                        "WITH DISTINCT cn " +
                        "DETACH DELETE cn " +
                        "RETURN count(cn) AS processed",
                        Values.parameters("v", neo4jVersion, "o", orgId, "batch", BATCH));
                    return r.single().get("processed").asLong();
                });
                total += processed;
                if (processed == 0) break;
            } catch (Exception e) {
                log.warn("collapseConnectivityNodeAtBusbar batch error: {}", e.getMessage());
                break;
            }
        }
        return total;
    }

    // ── CAISO-specific post-processing ────────────────────────────────────
    //
    // Three CAISO-only enrichment steps, run after Pass 2 (relationships)
    // and BEFORE Pass 3 (RATIONALISED topology simplification). They MUST
    // run before Pass 3 because all three rely on the intact
    // Terminal -> ConnectivityNode -> VoltageLevel chain, which Pass 3's
    // RATIONALISED collapse logic removes (Terminal/ConnectivityNode get
    // merged into [:UC_TO] relationships).
    //
    // Only executed when orgId="CAISO" AND versionType is SANITISED or
    // RATIONALISED. Skipped for FULL and CUSTOM variants, and for all
    // other organisations.

    /**
     * Runs all three CAISO enrichment steps in order.
     * Called from twoPassExport() after Pass 2, before Pass 3.
     */
    private void runGraphEnrichment(String neo4jVersion, String orgId,
                                     ExportRequest.VersionType vType) {
        log.info("Graph enrichment for org={} variant={}...", orgId, vType);
        long start = System.currentTimeMillis();

        // associateNominalVoltage: FULL + SANITISED + RATIONALISED
        long voltageCount = associateNominalVoltage(neo4jVersion, orgId);

        // associateSubstation: FULL + SANITISED + RATIONALISED
        // Sets substationMrid_1/substationName_1 (and _2, _3... for tie-lines)
        // on every ACLineSegment node
        long substationCount = associateSubstation(neo4jVersion, orgId);

        // applyIntertieLabel + applyOpenLabel: SANITISED + RATIONALISED only
        long tieLineCount = 0;
        long openCount    = 0;
        boolean restrictedEligible =
                vType == ExportRequest.VersionType.SANITISED
                || vType == ExportRequest.VersionType.RATIONALISED;
        if (restrictedEligible) {
            tieLineCount = applyIntertieLabel(neo4jVersion, orgId, vType);
            openCount    = applyOpenLabel(neo4jVersion, orgId);
        }

        log.info("Graph enrichment DONE in {} — nominalVoltage={} substation={} TIE_LINE={} OPEN={}",
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start),
                voltageCount, substationCount, tieLineCount, openCount);
    }

    /**
     * applyOpen — sets :OPEN as a direct label on switch nodes whose
     * Switch.normalOpen attribute is 'true'.
     *
     * Pure-Cypher translation of:
     *   MATCH (n) WHERE n.orgId='CAISO' AND n.version=$v
     *             AND n.`Switch.normalOpen` = 'true'
     *   SET n:OPEN
     *
     * Simpler than the old createOpenStateNodes() approach — no separate
     * node, no relationship. The switch node itself just gets an extra
     * label, e.g. (:Breaker:OPEN {name:'BKR-01', ...}).
     */
    private long applyOpenLabel(String neo4jVersion, String orgId) {
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                long updated = s.executeWrite(tx -> {
                    Result r = tx.run(
                        "MATCH (n:CIMNode {version: $v, orgId: $o}) " +
                        "WHERE n.`Switch.normalOpen` = 'true' AND NOT n:OPEN " +
                        "WITH n LIMIT 5000 SET n:OPEN " +
                        "RETURN count(n) AS updated",
                        Values.parameters("v", neo4jVersion, "o", orgId));
                    return r.single().get("updated").asLong();
                });
                total += updated;
                if (updated == 0) break;
            } catch (Exception e) {
                log.warn("applyOpenLabel batch error: {}", e.getMessage());
                break;
            }
        }
        return total;
    }

    /**
     * applyIntertie — labels an ACLineSegment as :TIE_LINE when it connects
     * two substations that belong to more than one SubGeographicalRegion.
     *
     * Pure-Cypher translation of:
     *   MATCH (l:ACLineSegment {orgId:'CAISO', version:$v})
     *   MATCH (l)<-[]-(t:Terminal)
     *   MATCH (t)-[]->(:ConnectivityNode)-[]->(:VoltageLevel)-[]->(s:Substation)
     *   OPTIONAL MATCH (s)-[]->(sgr:SubGeographicalRegion)
     *   OPTIONAL MATCH (sgr)-[]->(gr:GeographicalRegion)
     *   WITH l, collect(DISTINCT substations), collect(DISTINCT subregions), ...
     *   WHERE size(substations)=2 AND size(subregions)>1
     *   SET l:TIE_LINE
     *
     * Must run BEFORE Pass 3 (RATIONALISED collapse) — relies on the intact
     * Terminal -> ConnectivityNode -> VoltageLevel -> Substation chain.
     *
     * Batched over ACLineSegment candidates to avoid one giant transaction.
     */
    /**
     * applyIntertie — labels an ACLineSegment as :TIE_LINE when it connects
     * two substations that belong to more than one SubGeographicalRegion.
     *
     * PAGINATION FIX: the original implementation filtered candidates with
     * "WHERE NOT l:TIE_LINE" + "LIMIT 1000" and stopped as soon as one
     * batch produced zero matches. That is WRONG — if the first 1000
     * ACLineSegments happen to be non-tie-lines (a very likely scenario,
     * since tie-lines are a small minority), the function gave up
     * immediately, leaving thousands of real tie-lines further in the
     * graph unlabelled. ("No progress in this batch" does not mean
     * "no more candidates exist.")
     *
     * FIX: paginate over ALL ACLineSegment nodes by nodeKey (an indexed,
     * unique, sortable property) using a cursor — same id-based pagination
     * pattern used elsewhere (clearExistingNodes etc.), but for Neo4j
     * nodes. This guarantees every ACLineSegment is visited exactly once
     * regardless of how many early batches fail to match the join pattern.
     */
    /**
     * Applies :TIE_LINE label to ACLineSegment nodes that connect two
     * different SubGeographicalRegions.
     *
     * TWO FLAVOURS based on what exists in the graph:
     *
     * Flavour A — Terminal chain (FULL + SANITISED):
     *   Used when Terminal→ConnectivityNode→VoltageLevel→Substation chain
     *   exists in the graph (i.e. those types are in the export config).
     *   Collects distinct substations and SGRs via graph traversal.
     *
     * Flavour B — Enriched properties (RATIONALISED):
     *   Used when ConnectivityNode/VoltageLevel/Substation are NOT in the
     *   graph (RATIONALISED config typically omits them).
     *   Uses substationMrid + substationMridB properties pre-computed by
     *   Phase 3 CimEnrichmentService — no graph traversal needed.
     *   A node qualifies as TIE_LINE if:
     *     - substationMrid IS set (has at least one substation)
     *     - substationMridB IS set (has a second distinct substation)
     *     - subGeographicalRegionMrid ≠ subGeographicalRegionMridB
     *       (the two substations belong to different SGRs)
     */
    private long applyIntertieLabel(String neo4jVersion, String orgId,
                                     ExportRequest.VersionType versionType) {
        long total = 0;
        String lastKey = "";

        // Flavour is determined directly by versionType — no graph detection needed:
        //   SANITISED    → Flavour A: graph traversal via Terminal→CN→VL→Substation
        //   RATIONALISED → Flavour B: enriched properties (substationMrid/B + sgrMrid/B)
        //                  CN/VL/Substation may not be in RATIONALISED config so
        //                  graph traversal is unreliable.
        final boolean useChain =
                versionType != ExportRequest.VersionType.RATIONALISED;

        log.info("applyIntertieLabel: version={} flavour={}",
                neo4jVersion, useChain ? "A (terminal chain)" : "B (enriched properties)");

        while (true) {
            try (Session s = driver.session()) {
                final String fLastKey = lastKey;

                Map<String, Object> result = s.executeWrite(tx -> {
                    Result r;

                    if (useChain) {
                        // ── Flavour A: graph traversal via Terminal chain ──────────
                        r = tx.run(
                            "MATCH (l:ACLineSegment:CIMNode {orgId: $o, version: $v}) " +
                            "WHERE l.nodeKey > $lastKey " +
                            "WITH l ORDER BY l.nodeKey LIMIT 1000 " +
                            "WITH collect(l) AS candidates, max(l.nodeKey) AS newLastKey " +
                            "UNWIND candidates AS l " +
                            "MATCH (l)<-[]-(t:Terminal) " +
                            "MATCH (t)-[]->(:ConnectivityNode)-[]->(:VoltageLevel)-[]->(s:Substation) " +
                            "OPTIONAL MATCH (s)-[]->(sgr:SubGeographicalRegion) " +
                            "WITH l, newLastKey, " +
                            "     collect(DISTINCT s.mrid)   AS substations, " +
                            "     collect(DISTINCT sgr.mrid) AS subregions " +
                            "WITH newLastKey, l, " +
                            "     size(substations) = 2 AND size(subregions) > 1 AS qualifies " +
                            "FOREACH (x IN CASE WHEN qualifies THEN [1] ELSE [] END | SET l:TIE_LINE) " +
                            "RETURN count(CASE WHEN qualifies THEN 1 END) AS updated, " +
                            "       count(l) AS candidateCount, " +
                            "       collect(newLastKey)[0] AS newLastKey",
                            Values.parameters("v", neo4jVersion, "o", orgId, "lastKey", fLastKey));
                    } else {
                        // ── Flavour B: enriched properties ────────────────────────
                        // Uses substationMrid/substationMridB properties pre-computed
                        // by Phase 3 CimEnrichmentService on each ACLineSegment node.
                        //
                        // LOGIC: A line is a TIE_LINE if it connects two distinct
                        // substations that belong to different SubGeographicalRegions:
                        //   substationMrid  = first substation  (always set if enriched)
                        //   substationMridB = second substation (set only for tie-lines)
                        //
                        // For SGR comparison:
                        //   subGeographicalRegionMrid  = SGR of first substation
                        //   subGeographicalRegionMridB = SGR of second substation
                        //     → null when both substations share the SAME SGR (deduplication)
                        //     → set when substations belong to DIFFERENT SGRs
                        //
                        // Therefore: substationMridB IS NOT NULL (two substations exist)
                        //        AND subGeographicalRegionMridB IS NOT NULL (different SGRs)
                        //        is the correct tie-line condition.
                        //
                        // Fallback: if subGeographicalRegionMridB is missing but
                        // substationMridB exists, compare region names instead.
                        r = tx.run(
                            "MATCH (l:ACLineSegment:CIMNode {orgId: $o, version: $v}) " +
                            "WHERE l.nodeKey > $lastKey " +
                            "WITH l ORDER BY l.nodeKey LIMIT 1000 " +
                            "WITH collect(l) AS candidates, max(l.nodeKey) AS newLastKey " +
                            "UNWIND candidates AS l " +
                            "WITH newLastKey, l, " +
                            "     l.substationMrid                AS subA, " +
                            "     l.substationMridB               AS subB, " +
                            "     l.subGeographicalRegionMrid     AS sgrA, " +
                            "     l.subGeographicalRegionMridB    AS sgrB " +
                            "WITH newLastKey, l, " +
                            // Two substations exist AND either:
                            // a) different SGR mrids (sgrB is set = different SGRs), OR
                            // b) sgrB is null but sgrA is set = enrichment ran but
                            //    both ends share same SGR → NOT a tie-line across regions
                            // So: qualifies = subB IS NOT NULL AND sgrB IS NOT NULL
                            "     subA IS NOT NULL AND subB IS NOT NULL " +
                            "     AND sgrB IS NOT NULL AS qualifies " +
                            "FOREACH (x IN CASE WHEN qualifies THEN [1] ELSE [] END | SET l:TIE_LINE) " +
                            "RETURN count(CASE WHEN qualifies THEN 1 END) AS updated, " +
                            "       count(l) AS candidateCount, " +
                            "       collect(newLastKey)[0] AS newLastKey",
                            Values.parameters("v", neo4jVersion, "o", orgId, "lastKey", fLastKey));
                    }

                    org.neo4j.driver.Record rec = r.single();
                    Map<String, Object> out = new java.util.HashMap<>();
                    out.put("updated",        rec.get("updated").asLong(0));
                    out.put("candidateCount", rec.get("candidateCount").asLong(0));
                    out.put("newLastKey",     rec.get("newLastKey").isNull()
                            ? null : rec.get("newLastKey").asString());
                    return out;
                });

                long candidateCount = (Long) result.get("candidateCount");
                long updated        = (Long) result.get("updated");
                String newLastKey   = (String) result.get("newLastKey");

                if (candidateCount == 0 || newLastKey == null) break;
                total  += updated;
                lastKey = newLastKey;

            } catch (Exception e) {
                log.warn("applyIntertieLabel batch error: {}", e.getMessage());
                break;
            }
        }
        log.info("applyIntertieLabel: {} TIE_LINE nodes set for version={}", total, neo4jVersion);
        return total;
    }


    /**
     * associateNominalVoltage — sets l.nominalVoltage on each ACLineSegment
     * from its connected BaseVoltage.
     *
     * Pure-Cypher translation of:
     *   MATCH (l:ACLineSegment)<-[]-(t:Terminal)-[]->(:ConnectivityNode)
     *         -[]->(v:VoltageLevel)-[]->(bv:BaseVoltage)
     *   WHERE l.orgId='CAISO' AND l.version=$v
     *   SET l.nominalVoltage = bv.`BaseVoltage.nominalVoltage`
     *
     * Must run BEFORE Pass 3 (RATIONALISED collapse) — relies on the intact
     * Terminal -> ConnectivityNode -> VoltageLevel -> BaseVoltage chain.
     */
    /**
     * PAGINATION FIX (same bug class as applyIntertieLabel): the original
     * filtered candidates with "WHERE l.nominalVoltage IS NULL" + LIMIT
     * and stopped on the first batch with zero matches — but a batch
     * having zero matches does not mean no more ACLineSegments remain
     * that DO have a resolvable BaseVoltage chain.
     *
     * FIX: paginate over ALL ACLineSegment nodes by nodeKey cursor,
     * guaranteeing every node is visited exactly once.
     */
    /**
     * Associates substation mrid and name onto each ACLineSegment node.
     *
     * CHAIN: ACLineSegment ← Terminal → ConnectivityNode → VoltageLevel → Substation
     * (same chain used by applyIntertieLabel)
     *
     * An ACLineSegment can connect more than one substation (e.g. a tie-line
     * connects two). Properties are named with a numeric suffix so all
     * substations are preserved without overwriting:
     *
     *   Single substation:
     *     l.substationMrid_1 = "SUB-001-mrid"
     *     l.substationName_1 = "NORTH_SUBSTATION"
     *
     *   Tie-line (two substations):
     *     l.substationMrid_1 = "SUB-001-mrid"
     *     l.substationName_1 = "NORTH_SUBSTATION"
     *     l.substationMrid_2 = "SUB-002-mrid"
     *     l.substationName_2 = "SOUTH_SUBSTATION"
     *
     * Runs for FULL + SANITISED + RATIONALISED (same as associateNominalVoltage).
     * Uses the same cursor-paginated pattern — visits every ACLineSegment exactly
     * once regardless of whether a substation chain is reachable.
     *
     * NOTE: The property-setting loop (FOREACH per index) is done in Java rather
     * than pure Cypher because Cypher has no indexed iteration over a collect()
     * result that can emit dynamic property names like substationMrid_1, _2 etc.
     * We retrieve the collected substations from Neo4j, then issue one SET per
     * ACLineSegment per batch in a second write transaction.
     */
    /**
     * Sets substationMrid_1/substationName_1 (and _2, _3... for tie-lines) on
     * ALL CIMNode equipment nodes — not just ACLineSegment.
     *
     * APPROACH — variable-length path (max 4 hops):
     *   From any equipment node, walk via Terminal to find Substation.
     *   We use a variable-length path because the exact intermediate nodes
     *   (ConnectivityNode, VoltageLevel, Bay etc.) vary per CIM profile
     *   and weren't confirmed from graph analysis.
     *
     *   Confirmed from graph:
     *     (:Terminal)-[:Terminal.ConductingEquipment]->(:Equipment)
     *     (:Terminal)-[:Terminal.ConnectivityNode]->(:ConnectivityNode)
     *     (:SubGeographicalRegion)-[:Substation.Region]->(:Substation)
     *
     *   The path: Equipment ←[Terminal.ConductingEquipment]- Terminal
     *             -[Terminal.ConnectivityNode]-> ConnectivityNode
     *             -[*1..3]-> Substation
     *
     *   Max depth 3 after ConnectivityNode keeps it bounded and safe.
     */
    /**
     * Sets substationMrid_1/substationName_1 etc. on ALL equipment nodes.
     *
     * FAST APPROACH: Start from Terminal nodes (which connect equipment to
     * ConnectivityNode and ultimately to Substation). This avoids scanning
     * all 953K nodes — only nodes reachable via Terminal are processed.
     *
     * Chain: Equipment ←[Terminal.ConductingEquipment]- Terminal
     *        -[Terminal.ConnectivityNode]-> ConnectivityNode
     *        -[*1..3]-> Substation
     */
    /**
     * Sets substationMrid_1/substationName_1 (and _2 for tie-lines) on ALL
     * equipment nodes reachable via Terminal → ConnectivityNode → Substation.
     *
     * PURE CYPHER — read + write in ONE writeTransaction per page.
     * No Java intermediate step, no nested map serialization.
     * Supports up to 2 substations per node (covers tie-lines).
     */
    /**
     * Sets substationMrid_1/substationName_1, substationMrid_2/substationName_2,
     * ... (unlimited) on ALL equipment nodes reachable via Terminal.
     *
     * APPROACH — two steps per page:
     *   Step 1 READ (Cypher): collect substations per node (fast, single query)
     *   Step 2 WRITE (Java): build flat alternating-kv SET per batch of nodes
     *
     * Dynamic property names (substationMrid_N) cannot be done in pure Cypher
     * without APOC, so Java handles the property name generation.
     * Nodes are batched 200 per write transaction — one SET covers all
     * substations for all nodes in the batch via UNWIND + alternating params.
     *
     * No arbitrary cap — handles 1, 2, 3, or any number of substations.
     */
    private long associateSubstation(String neo4jVersion, String orgId) {
        long total = 0;
        String lastKey = "";
        final int PAGE = 1000;
        final int WRITE_BATCH = 200;

        while (true) {
            final String fLastKey = lastKey;

            // ── Step 1: READ — collect substations per node ───────────────
            List<Map<String, Object>> pageResults = new ArrayList<>();
            String newLastKey;

            try (Session s = driver.session()) {
                @SuppressWarnings("unchecked")
                List<org.neo4j.driver.Record> records =
                    (List<org.neo4j.driver.Record>) s.executeRead(tx -> {
                        org.neo4j.driver.Result r = tx.run(
                            "MATCH (n {orgId: $o, version: $v})" +
                            "  <-[:`Terminal.ConductingEquipment`]-(t:Terminal)" +
                            "  -[:`Terminal.ConnectivityNode`]->(cn:ConnectivityNode)" +
                            "  -[*1..3]->(sub:Substation) " +
                            "WHERE n.nodeKey > $lastKey " +
                            "WITH n, collect(DISTINCT {" +
                            "       mrid: sub.mrid, " +
                            "       name: sub.`IdentifiedObject.name`}) AS subs " +
                            "WITH n, [s IN subs WHERE s.mrid IS NOT NULL " +
                            "                      OR s.name IS NOT NULL] AS subs " +
                            "ORDER BY n.nodeKey LIMIT $page " +
                            "RETURN n.nodeKey AS nodeKey, subs",
                            Values.parameters("v", neo4jVersion, "o", orgId,
                                              "lastKey", fLastKey, "page", PAGE));
                        return r.list(); // consumed inside lambda ✅
                    });

                if (records.isEmpty()) break;
                newLastKey = null;

                for (org.neo4j.driver.Record rec : records) {
                    String nodeKey = rec.get("nodeKey").asString();
                    if (newLastKey == null || nodeKey.compareTo(newLastKey) > 0)
                        newLastKey = nodeKey;
                    List<Object> subs = rec.get("subs").asList();
                    if (subs == null || subs.isEmpty()) continue;
                    Map<String, Object> row = new java.util.LinkedHashMap<>();
                    row.put("nodeKey", nodeKey);
                    row.put("subs", subs);
                    pageResults.add(row);
                }
            } catch (Exception e) {
                log.warn("associateSubstation read error: {}", e.getMessage());
                break;
            }

            if (pageResults.isEmpty()) break;

            // ── Step 2: WRITE — build SET per node with unlimited suffix ──
            // Group nodes into write batches of WRITE_BATCH.
            // For each node, generate substationMrid_1, substationName_1, _2, ...
            // Pass as flat alternating Object[] to Values.parameters().
            for (int from = 0; from < pageResults.size(); from += WRITE_BATCH) {
                int to = Math.min(from + WRITE_BATCH, pageResults.size());
                List<Map<String, Object>> writeBatch = pageResults.subList(from, to);

                // Build one SET clause covering ALL nodes in this batch.
                // Each node gets its own WHEN clause so only its own props are set.
                // Strategy: UNWIND with one row per property assignment.
                // Row: {nodeKey, propKey, propVal}
                // Cypher: UNWIND batch AS row MATCH (n {nodeKey:row.nodeKey})
                //         CALL { WITH n, row SET n[row.propKey] = row.propVal }
                // BUT: SET n[dynamicKey] requires Neo4j 5.x syntax — not 4.4.x.
                //
                // WORKAROUND for 4.4.x: for each node, issue one tx.run()
                // with a SET clause that lists ALL properties explicitly.
                // Use ONE writeTransaction for the whole write batch —
                // multiple tx.run() calls inside one writeTransaction
                // = one roundtrip, not N roundtrips.
                final List<Map<String, Object>> fBatch = writeBatch;
                try (Session s = driver.session()) {
                    s.executeWrite(tx -> {
                        for (Map<String, Object> row : fBatch) {
                            String nodeKey = (String) row.get("nodeKey");
                            @SuppressWarnings("unchecked")
                            List<Object> subs = (List<Object>) row.get("subs");

                            // Build SET clause: n.`substationMrid_1`=$p0,
                            //                  n.`substationName_1`=$p1, ...
                            StringBuilder setClause = new StringBuilder();
                            // alternating: key, val, key, val ...
                            List<Object> kvList = new ArrayList<>();
                            kvList.add("nodeKey"); kvList.add(nodeKey);
                            int idx = 1;
                            for (Object subObj : subs) {
                                if (!(subObj instanceof Map)) continue;
                                @SuppressWarnings("unchecked")
                                Map<String, Object> sub = (Map<String, Object>) subObj;
                                String mrid = sub.get("mrid") != null
                                        ? sub.get("mrid").toString() : null;
                                String name = sub.get("name") != null
                                        ? sub.get("name").toString() : null;
                                if (mrid != null && !mrid.isBlank()) {
                                    String pk = "m" + idx;
                                    if (setClause.length() > 0) setClause.append(", ");
                                    setClause.append("n.`substationMrid_").append(idx)
                                             .append("` = $").append(pk);
                                    kvList.add(pk); kvList.add(mrid);
                                }
                                if (name != null && !name.isBlank()) {
                                    String pk = "n" + idx;
                                    if (setClause.length() > 0) setClause.append(", ");
                                    setClause.append("n.`substationName_").append(idx)
                                             .append("` = $").append(pk);
                                    kvList.add(pk); kvList.add(name);
                                }
                                if (mrid != null || name != null) idx++;
                            }
                            if (setClause.length() == 0) continue;

                            // One tx.run per node inside the same transaction
                            // = no extra roundtrip per node
                            tx.run("MATCH (n {nodeKey: $nodeKey}) SET " + setClause,
                                   Values.parameters(kvList.toArray()));
                        }
                        return null;
                    });
                    total += fBatch.size();
                } catch (Exception e) {
                    log.warn("associateSubstation write batch error: {}", e.getMessage());
                }
            }

            lastKey = newLastKey != null ? newLastKey : lastKey;
        }
        log.info("associateSubstation: {} nodes updated (version={})", total, neo4jVersion);
        return total;
    }




    /**
     * Sets nominalVoltage on ALL ConductingEquipment nodes (not just ACLineSegment)
     * by traversing: Equipment ←[Terminal]← Terminal →[ConnectivityNode]→
     * ConnectivityNode →[VoltageLevel]→ VoltageLevel →[BaseVoltage]→ BaseVoltage.
     *
     * FIXES:
     *   1. Was restricted to :ACLineSegment — now applies to ANY :CIMNode that
     *      has the voltage chain reachable (Breaker, PowerTransformer, Load, etc.)
     *   2. SANITISED/RATIONALISED previously had no nominalVoltage because
     *      VoltageLevel/BaseVoltage were not in those variant's cimType lists —
     *      fixed by force-including them in startSingleExport() for these variants.
     *   3. Cursor pagination uses max(n.nodeKey) collected from the page batch,
     *      not from UNWIND output, to avoid last-key mismatch after OPTIONAL MATCH
     *      filters some candidates.
     */
    /**
     * Associates nominalVoltage on ALL CIMNode nodes.
     *
     * CHAIN A (ConductingEquipment): Equipment ← Terminal → ConnectivityNode
     *                                → VoltageLevel → BaseVoltage
     * CHAIN B (Substation/Container): Substation → VoltageLevel → BaseVoltage
     *                                 (Substation is a container, has no Terminal)
     *
     * A node may be connected to MORE THAN ONE BaseVoltage (e.g. a transformer
     * spans two voltage levels). All distinct values are written with suffix:
     *   nominalVoltage_1, nominalVoltage_2, ...
     *
     * Uses read-then-write pattern (same as associateSubstation) so Java can
     * handle the dynamic property name generation with numeric suffixes.
     */
    /**
     * Sets nominalVoltage_1, nominalVoltage_2... on ALL CIMNode equipment nodes.
     *
     * From graph analysis of actual CAISO data:
     *   ACLineSegment has a DIRECT relationship to BaseVoltage:
     *     (n)-[:ConductingEquipment.BaseVoltage]->(bv:BaseVoltage)
     *   No Terminal→ConnectivityNode→VoltageLevel chain needed.
     *
     * Multiple BaseVoltages per node (e.g. transformers) are written with
     * numeric suffix: nominalVoltage_1, nominalVoltage_2 etc.
     */
    /**
     * Sets nominalVoltage_1, nominalVoltage_2... on equipment nodes.
     *
     * FAST APPROACH: Start from nodes that HAVE a BaseVoltage relationship
     * (not scan ALL nodes with OPTIONAL MATCH). This avoids scanning
     * 953K nodes to find the ~50K that actually have the property.
     *
     * Batched by nodeKey cursor — processes only nodes WITH BaseVoltage.
     */
    /**
     * Sets nominalVoltage_1, nominalVoltage_2... on equipment nodes.
     *
     * PURE CYPHER — read + write in ONE writeTransaction per page.
     * No Java intermediate step, no nested map serialization.
     * Supports up to 3 distinct voltage levels per node (covers all real cases).
     */
    private long associateNominalVoltage(String neo4jVersion, String orgId) {
        long total = 0;
        String lastKey = "";
        final int PAGE = 2000;

        while (true) {
            final String fLastKey = lastKey;
            try (Session s = driver.session()) {
                long[] result = {0L, 0L}; // [count, hasMore]
                String[] nextKey = {null};

                s.executeWrite(tx -> {
                    org.neo4j.driver.Result r = tx.run(
                        // Start from nodes WITH BaseVoltage rel — no full scan
                        "MATCH (n {orgId: $o, version: $v})" +
                        "  -[:`ConductingEquipment.BaseVoltage`]->(bv:BaseVoltage) " +
                        "WHERE n.nodeKey > $lastKey " +
                        "WITH n, collect(DISTINCT bv.`BaseVoltage.nominalVoltage`) AS allV " +
                        "WITH n, [v IN allV WHERE v IS NOT NULL AND v <> ''] AS v " +
                        "ORDER BY n.nodeKey LIMIT $page " +
                        // SET up to 3 voltage levels using FOREACH conditional trick
                        "FOREACH (_ IN CASE WHEN size(v) >= 1 THEN [1] ELSE [] END | " +
                        "  SET n.nominalVoltage_1 = v[0]) " +
                        "FOREACH (_ IN CASE WHEN size(v) >= 2 THEN [1] ELSE [] END | " +
                        "  SET n.nominalVoltage_2 = v[1]) " +
                        "FOREACH (_ IN CASE WHEN size(v) >= 3 THEN [1] ELSE [] END | " +
                        "  SET n.nominalVoltage_3 = v[2]) " +
                        "RETURN count(n) AS updated, max(n.nodeKey) AS lastKey",
                        Values.parameters("v", neo4jVersion, "o", orgId,
                                          "lastKey", fLastKey, "page", PAGE));
                    if (r.hasNext()) {
                        org.neo4j.driver.Record rec = r.single();
                        result[0] = rec.get("updated").asLong(0);
                        if (!rec.get("lastKey").isNull())
                            nextKey[0] = rec.get("lastKey").asString();
                    }
                    return null;
                });

                total += result[0];
                if (result[0] == 0 || nextKey[0] == null) break;
                lastKey = nextKey[0];
            } catch (Exception e) {
                log.warn("associateNominalVoltage error: {}", e.getMessage());
                break;
            }
        }
        log.info("associateNominalVoltage: {} nodes updated (version={})", total, neo4jVersion);
        return total;
    }




    // ── Pass 3: Remove :CIMNode routing label after export ───────────────

    /**
     * Removes :CIMNode label from all nodes for a specific version+orgId.
     * Called after Pass 2 completes — nodes keep their equipment labels only.
     * Batched to avoid transaction timeouts.
     */
    private long removeCimNodeLabel(String neo4jVersion, String orgId) {
        long total = 0;
        while (true) {
            try (Session s = driver.session()) {
                long removed = s.executeWrite(tx -> {
                    Result r = tx.run(
                        "MATCH (n:CIMNode {version: $v, orgId: $o}) " +
                        "WITH n LIMIT 5000 REMOVE n:CIMNode RETURN count(n) AS removed",
                        Values.parameters("v", neo4jVersion, "o", orgId));
                    return r.single().get("removed").asLong();
                });
                total += removed;
                if (removed == 0) break;
            } catch (Exception e) {
                log.warn("CIMNode label removal batch error: {}", e.getMessage());
                break;
            }
        }
        return total;
    }

    // ── Cleanup legacy labels ─────────────────────────────────────────────

    public long removeLegacyLabels() {
        long total = 0;
        for (String label : Arrays.asList("CIMObject")) {
            while (true) {
                try (Session s = driver.session()) {
                    String cypher = "MATCH (n:" + label + ") WITH n LIMIT 1000 " +
                                    "REMOVE n:" + label + " RETURN count(n) AS r";
                    long removed = s.executeWrite(tx -> {
                        Result r = tx.run(cypher);
                        return r.single().get("r").asLong(); // consumed inside tx ✅
                    });
                    total += removed;
                    if (removed == 0) break;
                    log.info("Removed :{} from {} nodes", label, removed);
                } catch (Exception e) { break; }
            }
        }
        log.info("Legacy label cleanup: {} nodes updated", total);
        return total;
    }


    // ── Migration — add :CIMNode to existing nodes ───────────────────────

    /** Removed: migrateAddCimNodeLabel no longer needed — :CIMNode removed. */

    // ── Status ────────────────────────────────────────────────────────────

    public Optional<Neo4jExportJob> getExportStatus(String exportId) {
        return exportRepo.findByExportId(exportId);
    }

    public List<Neo4jExportJob> getRecentExports() {
        return exportRepo.findTop10ByOrderByStartedAtDesc();
    }
}
