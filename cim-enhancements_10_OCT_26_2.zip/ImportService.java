package com.cim.service;

import com.cim.service.CimTypeFilterService;

import com.cim.model.cim.CIMObject;
import com.cim.model.mongo.CimObjectRecord;
import com.cim.model.mongo.StageTimings;
import com.cim.model.mongo.ValidationJob;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.repository.RawCimObjectRepository;
import com.cim.model.mongo.RawCimObject;
import com.cim.repository.ValidationJobRepository;
import com.cim.streaming.ProgressTracker;
import com.cim.streaming.StreamingRdfXmlParser;
import com.cim.streaming.StreamingReferenceResolver;
import com.cim.util.MapKeySanitizer;
import com.cim.validation.registry.CIMHierarchyRegistry;
import com.cim.model.mongo.Neo4jExportConfig;
import com.cim.model.mongo.ExportRequest;
import com.cim.model.mongo.ExportRequest.ExportMode;
import com.cim.repository.Neo4jExportConfigRepository;
import com.cim.validation.registry.PathValidationResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * Core import pipeline: parse → path-validate → save → resolve-references
 *
 * Enhancements in this version:
 *   REQ #1: orgId stored on every CimObjectRecord and ValidationJob
 *   REQ #2: Namespace filtering — only store attributes from enabled namespaces
 *   REQ #3: Disabled namespace attributes logged as UNKNOWN_NAMESPACE in pathIssues
 *   REQ #5: percentSaved fix — uses totalObjectsInFile for accurate percentage
 *   REQ #6: Per-stage timings stored on ValidationJob.stageTimings
 */
@Service
public class ImportService {

    private static final Logger log = LoggerFactory.getLogger(ImportService.class);

    @Value("${cim.streaming.chunk-size:500}")  private int chunkSize;
    @Value("${cim.streaming.log-every:10000}") private int logEvery;
    @Value("${cim.upload.temp-dir:/tmp/cim-uploads}") private String tempDir;

    private final StreamingRdfXmlParser      rdfParser;
    private final StreamingReferenceResolver refResolver;
    private final CimObjectRecordRepository  objectRepo;
    private final RawCimObjectRepository     rawRepo;
    private final ValidationJobRepository    jobRepo;
    private final CIMHierarchyRegistry       registry;
    private final NamespaceService             namespaceService;
    private final Neo4jExportService           neo4jExportService;
    private final Neo4jExportConfigRepository  exportConfigRepo;
    private final org.springframework.data.mongodb.core.MongoTemplate mongo;
    private final CimTypeFilterService   cimTypeFilter;
    private final CimEnrichmentService enrichmentService;

    private final Map<String, ProgressTracker> trackers = new ConcurrentHashMap<>();

    public ImportService(StreamingRdfXmlParser rdfParser,
                          com.cim.streaming.StreamingMilsoftCsvParser milsoftParser,
                          StreamingReferenceResolver refResolver,
                          CimObjectRecordRepository objectRepo,
                          RawCimObjectRepository rawRepo,
                          ValidationJobRepository jobRepo,
                          CIMHierarchyRegistry registry,
                          NamespaceService namespaceService,
                          Neo4jExportService neo4jExportService,
                          Neo4jExportConfigRepository exportConfigRepo,
                          org.springframework.data.mongodb.core.MongoTemplate mongo,
                          CimTypeFilterService cimTypeFilter,
                          CimEnrichmentService enrichmentService) {
        this.rdfParser          = rdfParser;
        this.milsoftParser      = milsoftParser;
        this.refResolver        = refResolver;
        this.objectRepo         = objectRepo;
        this.rawRepo            = rawRepo;
        this.jobRepo            = jobRepo;
        this.registry           = registry;
        this.namespaceService   = namespaceService;
        this.neo4jExportService = neo4jExportService;
        this.exportConfigRepo   = exportConfigRepo;
        this.mongo              = mongo;
        this.cimTypeFilter      = cimTypeFilter;
        this.enrichmentService  = enrichmentService;
    }

    /**
     * Appends a PhaseRecord to ValidationJob.phaseHistory via atomic
     * MongoDB $push — does not require reading the document first.
     * Called immediately after each import phase completes (or fails).
     *
     * This gives crash-recovery visibility and multi-node consistency:
     * any node querying GET /jobs/{jobId} sees the latest completed
     * phase + duration, even while the import is still running elsewhere.
     */
    /**
     * Writes live progress to MongoDB validation_jobs document.
     * Any cluster node can read this — not limited to the processing node.
     * Called periodically during parsing (every logEvery objects) and at
     * each stage transition.
     */
    private void updateProgress(String jobId, String stage, long parsed,
                                 long saved, int percent, String detail) {
        try {
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(
                            org.springframework.data.mongodb.core.query.Criteria
                                    .where("jobId").is(jobId));
            org.springframework.data.mongodb.core.query.Update u =
                    new org.springframework.data.mongodb.core.query.Update()
                            .set("progressStage",   stage)
                            .set("progressParsed",  parsed)
                            .set("progressSaved",   saved)
                            .set("progressPercent", percent)
                            .set("progressDetail",  detail)
                            .set("progressError",   null);
            mongo.updateFirst(q, u, "validation_jobs");
        } catch (Exception e) {
            log.debug("updateProgress failed (non-fatal): {}", e.getMessage());
        }
    }

    private void recordPhase(String jobId, String phase,
                              Instant startedAt, Instant completedAt,
                              long objectsProcessed, String status,
                              String errorMessage, String description) {
        try {
            com.cim.model.mongo.PhaseRecord record = new com.cim.model.mongo.PhaseRecord(
                    phase, startedAt, completedAt, objectsProcessed, status,
                    errorMessage, description);
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(
                            org.springframework.data.mongodb.core.query.Criteria
                                    .where("jobId").is(jobId));
            org.springframework.data.mongodb.core.query.Update u =
                    new org.springframework.data.mongodb.core.query.Update()
                            .push("phaseHistory", record);
            mongo.updateFirst(q, u, "validation_jobs");
            log.debug("Phase recorded: job={} phase={} status={} duration={}",
                    jobId, phase, status, record.getDurationFormatted());
        } catch (Exception e) {
            // Phase history is an audit/visibility enhancement, not critical
            // to the import succeeding — never let this break the import.
            log.warn("recordPhase failed (non-fatal): job={} phase={} error={}",
                    jobId, phase, e.getMessage());
        }
    }

    // ── Synchronous (≤50MB) ───────────────────────────────────────────────

    /**
     * Cleans up partial data from a failed import so re-import starts fresh.
     * Deletes cim_objects and raw_objects for the given jobId.
     * Called automatically when re-importing a job that previously failed.
     *
     * Issue: Without this, re-importing a failed job would accumulate duplicate
     * documents in cim_objects/raw_objects because the parser inserts new docs
     * without checking for existing ones with the same rdfId+jobId.
     */
    public void cleanupFailedJob(String jobId) {
        try {
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(
                            org.springframework.data.mongodb.core.query.Criteria
                                    .where("jobId").is(jobId));
            long cimDeleted = mongo.remove(q, "cim_objects").getDeletedCount();
            long rawDeleted = mongo.remove(q, "raw_objects").getDeletedCount();
            log.info("cleanupFailedJob: jobId={} cim_objects={} raw_objects={} deleted",
                    jobId, cimDeleted, rawDeleted);
            // Reset progress fields and status to PENDING
            org.springframework.data.mongodb.core.query.Update u =
                    new org.springframework.data.mongodb.core.query.Update()
                            .set("status",          "PENDING")
                            .set("progressStage",   null)
                            .set("progressParsed",  null)
                            .set("progressSaved",   null)
                            .set("progressPercent", null)
                            .set("progressDetail",  null)
                            .set("progressError",   null)
                            .set("totalObjects",    0)
                            .set("errorMessage",    null);
            mongo.updateFirst(q, u, "validation_jobs");
        } catch (Exception e) {
            log.warn("cleanupFailedJob failed: jobId={} error={}", jobId, e.getMessage());
        }
    }

    public void processAndResolve(InputStream in, String fileName,
                                   String format, String jobId,
                                   String version, String orgId) throws Exception {
        ProgressTracker p = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, p);
        // Load namespace cache fresh from MongoDB for this job (cluster-safe)
        namespaceService.loadForJob(jobId, orgId);
        try {
            run(in, fileName, format, jobId, version, orgId, true, p);
        } finally {
            // Always clear — success or failure — prevents stale data
            namespaceService.clearAfterJob(jobId);
            trackers.remove(jobId);
        }
    }

    // ── Async (>50MB) ─────────────────────────────────────────────────────

    // Thread-local path used by runWithPath() to signal run() to skip saveToDisk.
    // Set before calling run(), cleared in finally. One value per thread.
    private static final ThreadLocal<java.nio.file.Path> _preExistingPath = new ThreadLocal<>();

    /**
     * Import directly from a server-side file path — NO temp file created.
     *
     * Unlike processAndResolve(InputStream), this method reads directly from
     * the given filePath. This avoids the unnecessary disk copy that saveToDisk()
     * performs when the file is already on the server.
     *
     * Used by POST /api/import (filePath) for both sync and async cases.
     * The async case (processAndResolveAsync(filePath)) already does this —
     * this sync overload completes the pattern.
     */
    public void processAndResolveFromPath(String filePath, String fileName,
                                           String format, String jobId,
                                           String version, String orgId,
                                           boolean exportToNeo4j) throws Exception {
        ProgressTracker p = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, p);
        namespaceService.loadForJob(jobId, orgId);
        try {
            // Set thread-local so run() skips saveToDisk()
            _preExistingPath.set(Paths.get(filePath));
            run(java.io.InputStream.nullInputStream(), fileName, format,
                    jobId, version, orgId, exportToNeo4j, p);
        } finally {
            _preExistingPath.remove(); // always clear
            namespaceService.clearAfterJob(jobId);
            trackers.remove(jobId);
        }
    }

    @Async("importExecutor")
    /**
     * Async import that opens its OWN FileInputStream on the async thread.
     * This fixes WstxEOFException: when the controller passes an InputStream
     * and fires an async task, the controller's try-with-resources closes the
     * stream as soon as processAndResolveAsync() returns — before the async
     * thread finishes reading. By accepting a file path instead, the stream
     * is opened inside the async task and closed when the task finishes.
     */
    public CompletableFuture<Void> processAndResolveAsync(String filePath,
            String fileName, String format, String jobId,
            String version, String orgId) {
        return processAndResolveAsync(filePath, fileName, format, jobId, version, orgId, null);
    }

    /**
     * Async import with optional FTP temp file cleanup.
     * @param ftpTempFile  Path of a temp file downloaded from FTP that should be deleted
     *                     after import completes. Pass null if filePath is not an FTP temp file.
     */
    public CompletableFuture<Void> processAndResolveAsync(String filePath,
            String fileName, String format, String jobId,
            String version, String orgId, String ftpTempFile) {
        ProgressTracker p = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, p);
        namespaceService.loadForJob(jobId, orgId);
        try (java.io.FileInputStream fis =
                    new java.io.FileInputStream(new java.io.File(filePath));
             java.io.BufferedInputStream bis =
                    new java.io.BufferedInputStream(fis, 65536)) {
            run(bis, fileName, format, jobId, version, orgId, true, p);
        } catch (Exception e) {
            log.error("Async import failed job={}: {}", jobId, e.getMessage());
        } finally {
            namespaceService.clearAfterJob(jobId);
            trackers.remove(jobId);
            // Delete FTP temp file now that import (success or failure) is complete
            if (ftpTempFile != null) {
                try {
                    boolean deleted = new java.io.File(ftpTempFile).delete();
                    if (deleted) log.info("FTP temp file deleted after async import: {}", ftpTempFile);
                    else         log.warn("FTP temp file not found for deletion: {}", ftpTempFile);
                } catch (Exception ex) {
                    log.warn("Could not delete FTP temp file {}: {}", ftpTempFile, ex.getMessage());
                }
            }
        }
        return CompletableFuture.completedFuture(null);
    }

    /** @deprecated Pass a file path for async imports — this overload causes
     *  WstxEOFException when the caller's stream is closed by try-with-resources
     *  before the async thread finishes reading. */
    @Deprecated
    public CompletableFuture<Void> processAndResolveAsync(InputStream in,
            String fileName, String format, String jobId,
            String version, String orgId) {
        ProgressTracker p = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, p);
        namespaceService.loadForJob(jobId, orgId);
        try {
            run(in, fileName, format, jobId, version, orgId, true, p);
        } catch (Exception e) {
            log.error("Async import failed: {}", e.getMessage());
        } finally {
            namespaceService.clearAfterJob(jobId);
        }
        return CompletableFuture.completedFuture(null);
    }

    // ── Core pipeline ─────────────────────────────────────────────────────

    /**
     * Run import directly from a server-side file path.
     * NO temp file created — reads directly from the given path.
     * Used by POST /api/import (filePath) to avoid unnecessary disk copy.
     *
     * For async large files: processAndResolveAsync(filePath) already opens
     * its own FileInputStream inside the async thread — also no temp file.
     */
    private void runFromPath(String filePath, String fileName, String format,
                              String jobId, String version, String orgId,
                              boolean exportToNeo4j,
                              ProgressTracker progress) throws Exception {
        // Delegate to streamValidateAndSave directly with the original path
        // No saveToDisk() — file is already on server disk
        setupJob(jobId, fileName, format, orgId, version, progress);

        StageTimings timings = new StageTimings();
        long pipelineStart = System.currentTimeMillis();
        try {
            // Phase 1: Parse directly from original file
            progress.setStage(ProgressTracker.Stage.STREAMING_PARSE,
                    "Parsing " + fileName + "...");
            Instant parseStartedAt = Instant.now();
            long parseStart = System.currentTimeMillis();
            Path src = java.nio.file.Paths.get(filePath);
            streamValidateAndSave(src, fileName, format, jobId, version, orgId, progress);
            timings.setParseMs(System.currentTimeMillis() - parseStart);
            updateProgress(jobId, "STREAMING_PARSE",
                    progress.getParsed(), progress.getParsed(), 50,
                    "Parsing complete: " + String.format("%,d", progress.getParsed()) + " objects");
            recordPhase(jobId, "STREAMING_PARSE", parseStartedAt, Instant.now(),
                    progress.getParsed(), "COMPLETED", null,
                    String.format("%,d objects parsed from %s in %s",
                            progress.getParsed(), fileName,
                            com.cim.model.mongo.StageTimings.format(timings.getParseMs())));
            // Phases 2 + 3 + export — same as run()
            completeImportPhases(jobId, version, orgId, exportToNeo4j,
                    progress, timings, pipelineStart);
        } catch (Exception e) {
            handleImportFailure(jobId, version, orgId, exportToNeo4j,
                    progress, timings, e);
            throw e;
        }
    }

    private void run(InputStream in, String fileName, String format,
                      String jobId, String version, String orgId,
                      boolean exportToNeo4j,
                      ProgressTracker progress) throws Exception {

        ValidationJob job = jobRepo.findByJobId(jobId).orElseThrow();
        job.setStatus("RUNNING");
        job.setNetworkVersion(version);
        job.setOrgId(orgId);
        // Store enabled namespaces at job level for audit trail
        // Enhancement 4: Only store namespaces relevant to this org
        // (global namespaces + org-specific) — not all orgs' namespaces
        job.setEnabledNamespaces(
                namespaceService.getByOrg(orgId).stream()
                        .filter(ns -> ns.isEnabled())
                        .map(ns -> ns.getPrefix())
                        .collect(java.util.stream.Collectors.toList()));
        jobRepo.save(job);

        StageTimings timings = new StageTimings();
        long pipelineStart = System.currentTimeMillis();

        try {
            // ── Step 1: Stream parse + path-validate + save ───────────────
            progress.setStage(ProgressTracker.Stage.STREAMING_PARSE,
                    "Parsing " + format + "...");
            Instant parseStartedAt = Instant.now();
            long parseStart = System.currentTimeMillis();
            // Check if caller provided a pre-existing path (no temp copy needed)
            // runWithPath() sets this via thread-local; otherwise saveToDisk()
            Path preExistingPath = _preExistingPath.get();
            if (preExistingPath != null) {
                // filePath import — read directly, no temp file
                streamValidateAndSave(preExistingPath, fileName, format, jobId,
                                      version, orgId, progress);
            } else {
                // InputStream import — must save to temp first (stream is one-shot)
                Path tmp = saveToDisk(in, jobId, fileName);
                try {
                    streamValidateAndSave(tmp, fileName, format, jobId,
                                          version, orgId, progress);
                } finally {
                    deleteTempFile(tmp);
                }
            }
            timings.setParseMs(System.currentTimeMillis() - parseStart);
            progress.log("Parse+save done in " + timings.getParseMs() + "ms");
            // Persist phase completion to MongoDB immediately — crash
            // recovery + multi-node visibility, not just in-memory state.
            updateProgress(jobId, "STREAMING_PARSE",
                    progress.getParsed(), progress.getParsed(), 50,
                    "Parsing complete: " + String.format("%,d", progress.getParsed()) + " objects");
            recordPhase(jobId, "STREAMING_PARSE", parseStartedAt, Instant.now(),
                    progress.getParsed(), "COMPLETED", null,
                    String.format("%,d objects parsed from %s in %s",
                            progress.getParsed(), fileName,
                            com.cim.model.mongo.StageTimings.format(timings.getParseMs())));

            // ── Step 2: Resolve cross-references ──────────────────────────
            progress.setStage(ProgressTracker.Stage.RESOLVING_REFERENCES,
                    "Resolving cross-references...");
            Instant refStartedAt = Instant.now();
            long refStart = System.currentTimeMillis();
            long resolved = refResolver.resolveReferencesInMongo(
                    jobId, chunkSize, progress);
            timings.setReferenceMs(System.currentTimeMillis() - refStart);
            progress.log("References resolved: " + resolved
                    + " in " + timings.getReferenceMs() + "ms");
            recordPhase(jobId, "RESOLVING_REFERENCES", refStartedAt, Instant.now(),
                    resolved, "COMPLETED", null,
                    String.format("%,d cross-references resolved in %s",
                            resolved,
                            com.cim.model.mongo.StageTimings.format(timings.getReferenceMs())));

            // ── Phase 3: CIM Enrichment (CAISO + enabled orgs only) ───────
            // Computes nominalVoltage_1 and substationMrid_N/substationName_N
            // by walking resolved reference chains in MongoDB and writing
            // derived attributes directly onto cim_objects.
            //
            // raw_objects: intentionally untouched — kept in vendor-format shape.
            //
            // To enable for another org: add the orgId to
            // CimEnrichmentService.ENRICHMENT_ENABLED_ORGS (one line change).
            // Write totalObjects to the job NOW — before enrichment starts — so
            // that the progress endpoint returns the correct count during Phase 3.
            // Previously totalObjects was only set after enrichment, so it showed 0
            // for the entire duration of the enrichment phase.
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setTotalObjects((int) progress.getParsed());
            jobRepo.save(job);

            Instant enrichStartedAt = Instant.now();
            long enrichStart = System.currentTimeMillis();
            long enrichedCount = enrichmentService.enrich(jobId, orgId);
            if (enrichedCount >= 0) {   // -1 means skipped (org not in ENRICHMENT_ENABLED_ORGS)
                timings.setEnrichmentMs(System.currentTimeMillis() - enrichStart);
                recordPhase(jobId, "ENRICHMENT", enrichStartedAt, Instant.now(),
                        enrichedCount,   // actual count of objects that got derived attributes
                        "COMPLETED", null,
                        String.format("Phase 3 enrichment done in %s — " +
                                "%d objects enriched (nominalVoltage + substation + SGR + GR + FriendlyName)",
                                com.cim.model.mongo.StageTimings.format(timings.getEnrichmentMs()),
                                enrichedCount));
                progress.log("Enrichment done in "
                        + com.cim.model.mongo.StageTimings.format(timings.getEnrichmentMs())
                        + " — " + enrichedCount + " objects enriched");
            }

            // ── Done ──────────────────────────────────────────────────────
            timings.setTotalMs(System.currentTimeMillis() - pipelineStart);
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setStatus("RESOLVED");
            job.setTotalObjects((int) progress.getParsed());
            updateProgress(jobId, "COMPLETED",
                    progress.getParsed(), progress.getParsed(), 100,
                    "Import complete");
            job.setPhysicalObjects((int) objectRepo.countByJobIdAndCategory(jobId,"PHYSICAL"));
            job.setLogicalObjects((int)  objectRepo.countByJobIdAndCategory(jobId,"LOGICAL"));
            job.setPathIssueCount((int)  countPathIssues(jobId));
            job.setStageTimings(timings);
            job.setCompletedAt(Instant.now());
            job.setProcessingMs(timings.getTotalMs());
            jobRepo.save(job);
            progress.done();

            // REQ #7: human-readable stage times in log
            log.info("Import done: job={} version={} orgId={} objects={} resolved={} "
                    + "parse={} reference={} total={}",
                    jobId, version, orgId, progress.getParsed(), resolved,
                    com.cim.model.mongo.StageTimings.format(timings.getParseMs() != null ? timings.getParseMs() : 0),
                    com.cim.model.mongo.StageTimings.format(timings.getReferenceMs() != null ? timings.getReferenceMs() : 0),
                    com.cim.model.mongo.StageTimings.format(timings.getTotalMs() != null ? timings.getTotalMs() : 0));

            // ── Auto-trigger Neo4j export (if enabled by caller) ────────────
            if (exportToNeo4j) {
                recordPhase(jobId, "NEO4J_EXPORT_TRIGGERED",
                        Instant.now(), Instant.now(), 0, "COMPLETED",
                        "Neo4j export triggered automatically after import");
                triggerAutoExport(jobId, version, orgId);
            } else {
                log.info("Neo4j export skipped (exportToNeo4j=false): job={}", jobId);
                recordPhase(jobId, "NEO4J_EXPORT",
                        Instant.now(), Instant.now(), 0, "SKIPPED",
                        "Neo4j export skipped by caller request. " +
                        "Use POST /api/admin/neo4j/export to export manually.");
            }

        } catch (Exception e) {
            timings.setTotalMs(System.currentTimeMillis() - pipelineStart);
            log.error("Import failed job={}: {}", jobId, e.getMessage());
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setStatus("FAILED"); job.setErrorMessage(e.getMessage());
            job.setStageTimings(timings); job.setCompletedAt(Instant.now());
            jobRepo.save(job);
            // Record the failure as a phase entry too — preserves which
            // stage was active when the failure occurred, with timing.
            recordPhase(jobId, progress.getStage() != null
                    ? progress.getStage().name() : "UNKNOWN",
                    Instant.now(), Instant.now(), progress.getParsed(),
                    "FAILED", e.getMessage(),
                    "Import failed: " + e.getMessage());
            progress.fail(e.getMessage());
            throw e;
        }
    }

    // ── Stream, validate, save ────────────────────────────────────────────

    private void streamValidateAndSave(Path tmp, String fileName,
                                        String format, String jobId,
                                        String version, String orgId,
                                        ProgressTracker progress) throws Exception {
        // Load cimType filter for this org.
        // raw_objects receives ALL types — complete audit record.
        // cim_objects receives only allowed types when a filter is configured.
        // Empty set = no filter = store everything (backward compatible).
        java.util.Set<String> allowedTypes = cimTypeFilter.getAllowedTypes(orgId);
        if (!allowedTypes.isEmpty())
            log.info("CimTypeFilter active: {} types allowed for orgId={}",
                    allowedTypes.size(), orgId);

        // Two batches — saved together each chunk
        List<CimObjectRecord> batch    = new ArrayList<>(chunkSize);
        List<RawCimObject>    rawBatch = new ArrayList<>(chunkSize);

        progress.setTotalObjects(estimateObjectCount(tmp, format));

        // Route to correct parser based on format
        java.util.function.Consumer<com.cim.model.cim.CIMObject> onObject = obj -> {
            // raw_objects: ALWAYS store — regardless of filter
            rawBatch.add(toRawObject(obj, jobId, version, orgId, format, fileName));

            // cim_objects: only store if type is allowed by filter
            if (cimTypeFilter.isAllowed(obj.getCimType(), allowedTypes)) {
                batch.add(toRecord(obj, jobId, version, orgId));
            }
            progress.incrementParsed();

            if (rawBatch.size() >= chunkSize) {
                rawRepo.saveAll(new ArrayList<>(rawBatch));
                rawBatch.clear();
                if (!batch.isEmpty()) {
                    objectRepo.saveAll(new ArrayList<>(batch));
                    progress.incrementSaved(batch.size());
                    batch.clear();
                }
            }
        };

        try (InputStream fis = Files.newInputStream(tmp)) {
            if ("MILSOFT_CSV".equalsIgnoreCase(format)) {
                milsoftParser.stream(fis, fileName, onObject);
            } else {
                // Default: RDF/XML (JSON-LD uses same parser with different dialect)
                rdfParser.stream(fis, fileName, onObject);
            }
        }
        // Final batch
        if (!rawBatch.isEmpty()) rawRepo.saveAll(rawBatch);
        if (!batch.isEmpty()) {
            objectRepo.saveAll(batch);
            progress.incrementSaved(batch.size());
        }
        progress.log("Stream complete: " + progress.getParsed() + " parsed → "
                + "raw_objects=" + progress.getParsed()
                + " cim_objects=" + progress.getSaved()
                + (allowedTypes.isEmpty() ? " (no filter)" : " (filtered)"));
    }

    // ── Build CimObjectRecord with namespace filtering ─────────────────────

    CimObjectRecord toRecord(CIMObject obj, String jobId,
                              String version, String orgId) {
        CimObjectRecord r = new CimObjectRecord();
        r.setJobId(jobId);
        r.setRdfId(obj.getRdfId());
        r.setMrid(obj.getMrid());
        r.setCimType(obj.getCimType());
        r.setName(obj.getName());
        r.setSourceFormat(obj.getSourceFormat());
        r.setSourceFile(obj.getSourceFile());
        r.setVersion(version);
        r.setOrgId(orgId);  // REQ #1

        // Category and isRequired from OWL registry only
        String category = registry.getCategory(obj.getCimType());
        if ("UNKNOWN".equals(category)) category = "PHYSICAL"; // safe default
        r.setCategory(category);
        r.setRequired(registry.getDefaultRequired(obj.getCimType()));

        // ── REQ #2 + #3: Namespace-filtered attributes + references ──────
        Map<String,String> filteredAttrs = new LinkedHashMap<>();
        Map<String,String> filteredRefs  = new LinkedHashMap<>();
        List<Map<String,String>> pathIssues = new ArrayList<>();

        // Process attributes
        for (Map.Entry<String,String> e : obj.getAttributes().entrySet()) {
            String tag    = e.getKey();
            String value  = e.getValue();
            String prefix = namespaceService.extractPrefix(tag);

            if (namespaceService.isEnabled(jobId, prefix)) {
                // Namespace enabled → store attribute
                filteredAttrs.put(MapKeySanitizer.encode(tag), value);

                // Path validation — only for namespaces with validatePath=true
                if (namespaceService.shouldValidatePath(jobId, prefix)
                        && registry.isKnownClass(obj.getCimType())) {
                    PathValidationResult res =
                            registry.validateAttributePath(obj.getCimType(), tag);
                    if (res.isInvalid()) {
                        pathIssues.add(Map.of(
                            "tag",         tag,
                            "status",      "INVALID_PATH",
                            "explanation", res.getExplanation()
                        ));
                    }
                }
                // If validatePath=false (custom namespace) → store as-is, no path check
            } else {
                // REQ #3: Namespace disabled → log UNKNOWN_NAMESPACE issue
                // Do NOT store the attribute
                pathIssues.add(Map.of(
                    "tag",         tag,
                    "status",      "UNKNOWN_NAMESPACE",
                    "explanation", "Namespace '" + prefix + "' is not enabled. "
                                   + "Enable via POST /api/admin/namespaces/" + prefix
                                   + "/enable to store these attributes."
                ));
            }
        }

        // Process references (same namespace logic)
        for (Map.Entry<String,String> e : obj.getReferences().entrySet()) {
            String tag    = e.getKey();
            String prefix = namespaceService.extractPrefix(tag);
            if (namespaceService.isEnabled(jobId, prefix)) {
                filteredRefs.put(MapKeySanitizer.encode(tag), e.getValue());
            }
            // Disabled namespace references are silently skipped
            // (already logged under attributes or reference handling)
        }

        r.setAttributes(filteredAttrs);
        r.setReferences(filteredRefs);
        if (!pathIssues.isEmpty()) r.setPathIssues(pathIssues);

        r.setCreatedAt(Instant.now());
        return r;
    }

    // ── REQ #5: estimate object count for accurate percentSaved ──────────

    private long estimateObjectCount(Path tmp, String format) {
        if (!"RDF_XML".equals(format)) return -1;
        try {
            long fileSize = Files.size(tmp);
            // Rough estimate: ~500 bytes per CIM object on average in RDF/XML
            return Math.max(1, fileSize / 500);
        } catch (Exception e) { return -1; }
    }

    // ── Progress ──────────────────────────────────────────────────────────

    public Optional<ProgressTracker> getTracker(String jobId) {
        return Optional.ofNullable(trackers.get(jobId));
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private long countPathIssues(String jobId) {
        org.springframework.data.mongodb.core.query.Query q =
                new org.springframework.data.mongodb.core.query.Query(
                        org.springframework.data.mongodb.core.query.Criteria
                                .where("jobId").is(jobId)
                                .and("pathIssues.0").exists(true));
        // Use repo count — avoids injecting MongoTemplate here
        return objectRepo.findByJobId(jobId,
                org.springframework.data.domain.PageRequest.of(0, 1))
                .getTotalElements(); // approximate, good enough for reporting
    }

    private Path saveToDisk(InputStream in, String jobId,
                             String fileName) throws IOException {
        Path dir = Paths.get(tempDir);
        Files.createDirectories(dir);
        Path file = dir.resolve(jobId + "_" + fileName);
        Files.copy(in, file, StandardCopyOption.REPLACE_EXISTING);
        return file;
    }

    private void deleteTempFile(Path p) {
        try { Files.deleteIfExists(p); } catch (IOException ignored) {}
    }

    /**
     * Triggered automatically after every successful import (status=RESOLVED).
     * Finds all active Neo4jExportConfig records with autoExport=true
     * that match this orgId (or have no orgId restriction).
     * Each matching config triggers a separate async Neo4j export job.
     */
    /**
     * Triggered after every successful import (status=RESOLVED).
     *
     * FIX 1 — OrgId specific:
     *   Queries configs WHERE orgId = this import's orgId OR orgId is empty/null.
     *   A config with orgId="CAISO" only triggers for CAISO imports.
     *   A config with orgId="" triggers for ALL organisations.
     *
     * FIX 2 — Three variant support:
     *   If config has fullCimTypes + sanitisedCimTypes + rationalisedCimTypes set,
     *   triggers all three variants in one multi-variant ExportRequest.
     *   Each variant exports its own CIM type set under its own version suffix.
     *
     * FIX 3 — Version-specific query:
     *   Uses findByOrgIdAndAutoExportTrueAndActiveTrue(orgId) to get
     *   only configs matching this import's orgId.
     */
    private void triggerAutoExport(String jobId, String version, String orgId) {
        try {
            // FIX 1: Query orgId-specific configs directly from DB
            // Gets configs where orgId matches OR orgId is blank (applies to all)
            List<com.cim.model.mongo.Neo4jExportConfig> specificConfigs =
                    exportConfigRepo.findByOrgIdAndAutoExportTrueAndActiveTrue(orgId);
            List<com.cim.model.mongo.Neo4jExportConfig> globalConfigs =
                    exportConfigRepo.findByAutoExportTrueAndActiveTrue()
                    .stream()
                    .filter(c -> c.getOrgId() == null || c.getOrgId().isBlank())
                    .collect(java.util.stream.Collectors.toList());

            // Merge: orgId-specific + global (no orgId restriction)
            List<com.cim.model.mongo.Neo4jExportConfig> configs = new ArrayList<>();
            configs.addAll(specificConfigs);
            globalConfigs.stream()
                    .filter(g -> specificConfigs.stream()
                            .noneMatch(s -> s.getId().equals(g.getId())))
                    .forEach(configs::add);

            if (configs.isEmpty()) {
                log.info("No auto-export configs for orgId={} job={}", orgId, jobId);
                return;
            }

            int triggered = 0;
            for (com.cim.model.mongo.Neo4jExportConfig cfg : configs) {

                // FIX 2: Build multi-variant request if three lists are configured
                boolean hasMultiVariant =
                        (cfg.getFullCimTypes()      != null && !cfg.getFullCimTypes().isEmpty()) ||
                        (cfg.getSanitisedCimTypes() != null && !cfg.getSanitisedCimTypes().isEmpty()) ||
                        (cfg.getRationalisedCimTypes() != null && !cfg.getRationalisedCimTypes().isEmpty());

                if (hasMultiVariant) {
                    // All three variants in one request
                    ExportRequest req = new ExportRequest();
                    req.setJobId(jobId);
                    req.setOrgId(orgId);
                    req.setClearFirst(cfg.isClearFirst());
                    req.setFullCimTypes(cfg.getFullCimTypes()      != null
                            ? cfg.getFullCimTypes()      : new ArrayList<>());
                    req.setSanitisedCimTypes(cfg.getSanitisedCimTypes() != null
                            ? cfg.getSanitisedCimTypes() : new ArrayList<>());
                    req.setRationalisedCimTypes(cfg.getRationalisedCimTypes() != null
                            ? cfg.getRationalisedCimTypes() : new ArrayList<>());

                    neo4jExportService.startExport(req);
                    triggered++;
                    log.info("Auto-export (multi-variant): config='{}' orgId={} job={} "
                            + "full={} sanitised={} rationalised={}",
                            cfg.getConfigName(), orgId, jobId,
                            req.getFullCimTypes().size(),
                            req.getSanitisedCimTypes().size(),
                            req.getRationalisedCimTypes().size());

                } else {
                    // Single variant — REQ #5: default SANITISED for import flow
                    List<String> types = cfg.getSanitisedCimTypes() != null
                            && !cfg.getSanitisedCimTypes().isEmpty()
                            ? cfg.getSanitisedCimTypes()
                            : (cfg.getCimTypes() != null ? cfg.getCimTypes() : new ArrayList<>());

                    if (types.isEmpty()) {
                        log.warn("Config '{}' has no cimTypes — skipping",
                                cfg.getConfigName());
                        continue;
                    }

                    ExportRequest req = new ExportRequest(
                            jobId,
                            ExportRequest.ExportMode.CUSTOM,
                            types,
                            cfg.isClearFirst());
                    req.setVersionType(ExportRequest.VersionType.SANITISED);
                    req.setOrgId(orgId);

                    neo4jExportService.startExport(req);
                    triggered++;
                    log.info("Auto-export (sanitised): config='{}' orgId={} types={} job={}",
                            cfg.getConfigName(), orgId, types.size(), jobId);
                }
            }

            if (triggered > 0)
                log.info("Auto-export complete: {} job(s) triggered for import job={} orgId={}",
                        triggered, jobId, orgId);

        } catch (Exception e) {
            // Auto-export failure must NEVER affect import status
            log.error("Auto-export trigger failed for job={}: {}", jobId, e.getMessage());
        }
    }

    /**
     * Cancel a running import and clean up any data it has already written.
     *
     * Steps:
     *   1. Signal the ProgressTracker — the import loop checks isCancelled()
     *      at every chunk boundary and stops inserting new objects.
     *   2. Wait briefly (up to 5s) for the thread to acknowledge and exit.
     *   3. Delete all partial data written so far (cim_objects + raw_objects).
     *   4. Mark the ValidationJob as CANCELLED.
     *
     * If the job is already DONE, RESOLVED, or FAILED, cancellation is a no-op.
     *
     * @return  "CANCELLED" if the job was successfully cancelled,
     *          "NOT_RUNNING" if the job was not in an active state,
     *          "NOT_FOUND" if no job with that jobId exists.
     */
    public String cancelJob(String jobId) {
        ValidationJob job = jobRepo.findByJobId(jobId).orElse(null);
        if (job == null) return "NOT_FOUND";

        String status = job.getStatus();
        if (status != null && (status.equals("DONE") || status.equals("RESOLVED")
                || status.equals("FAILED") || status.equals("CANCELLED"))) {
            return "NOT_RUNNING";  // already terminal — nothing to cancel
        }

        // 1. Signal the active tracker (if the thread is still parsing)
        ProgressTracker tracker = trackers.get(jobId);
        if (tracker != null) {
            tracker.cancel();
            log.info("Cancel signal sent to import thread: jobId={}", jobId);
            // 2. Wait briefly for the thread to notice and wind down
            long deadline = System.currentTimeMillis() + 5_000;
            while (System.currentTimeMillis() < deadline
                    && trackers.containsKey(jobId)) {
                try { Thread.sleep(200); } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        // 3. Delete all partial data this job has written
        log.info("Deleting partial data for cancelled job={}", jobId);
        try {
            objectRepo.deleteByJobId(jobId);
            log.info("cim_objects deleted: jobId={}", jobId);
        } catch (Exception e) {
            log.warn("Error deleting cim_objects for jobId={}: {}", jobId, e.getMessage());
        }
        try {
            org.springframework.data.mongodb.core.query.Query rawQ =
                    new org.springframework.data.mongodb.core.query.Query(
                            org.springframework.data.mongodb.core.query.Criteria
                                    .where("jobId").is(jobId));
            mongo.remove(rawQ, "raw_objects");
            log.info("raw_objects deleted: jobId={}", jobId);
        } catch (Exception e) {
            log.warn("Error deleting raw_objects for jobId={}: {}", jobId, e.getMessage());
        }

        // 4. Mark job as CANCELLED
        try {
            org.springframework.data.mongodb.core.query.Query q =
                    new org.springframework.data.mongodb.core.query.Query(
                            org.springframework.data.mongodb.core.query.Criteria
                                    .where("jobId").is(jobId));
            org.springframework.data.mongodb.core.query.Update u =
                    new org.springframework.data.mongodb.core.query.Update()
                            .set("status",       "CANCELLED")
                            .set("errorMessage", "Import cancelled by user — partial data cleaned up.")
                            .set("progressStage", "CANCELLED");
            mongo.updateFirst(q, u, "validation_jobs");
            log.info("Job marked CANCELLED: jobId={}", jobId);
        } catch (Exception e) {
            log.warn("Error updating job status for jobId={}: {}", jobId, e.getMessage());
        }

        return "CANCELLED";
    }

    public static String sha256(byte[] data) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : h) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
