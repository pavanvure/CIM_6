package com.cim.controller;

import com.cim.service.ImportService;
import com.cim.service.Neo4jExportService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Data Management REST endpoints.
 *
 * DELETE /api/data/cim-objects    — remove processed CIM objects from MongoDB (cim_objects collection)
 * DELETE /api/data/raw-objects    — remove raw parsed objects from MongoDB (raw_objects collection)
 * DELETE /api/admin/neo4j/data    — remove all Neo4j nodes/rels for a version+orgId
 * POST   /api/import/{jobId}/cancel — signal a running import to stop and clean up partial data
 */
@RestController
@RequestMapping("/api")
public class DataManagementController {

    private static final Logger log = LoggerFactory.getLogger(DataManagementController.class);

    private final ImportService      importService;
    private final Neo4jExportService neo4jExportService;
    private final MongoTemplate      mongo;

    public DataManagementController(ImportService importService,
                                    Neo4jExportService neo4jExportService,
                                    MongoTemplate mongo) {
        this.importService      = importService;
        this.neo4jExportService = neo4jExportService;
        this.mongo              = mongo;
    }

    // ──────────────────────────────────────────────────────────────────────────
    // DELETE MongoDB CIM Objects
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Delete processed CIM objects from the cim_objects MongoDB collection.
     *
     * At least one filter is required (jobId OR networkVersion+orgId).
     *
     * Examples:
     *   DELETE /api/data/cim-objects?jobId=abc123
     *   DELETE /api/data/cim-objects?networkVersion=DB142&orgId=CAISO
     *   DELETE /api/data/cim-objects?jobId=abc123&networkVersion=DB142&orgId=CAISO
     */
    @DeleteMapping("/data/cim-objects")
    public ResponseEntity<?> deleteCimObjects(
            @RequestParam(required = false) String jobId,
            @RequestParam(required = false) String networkVersion,
            @RequestParam(required = false) String orgId) {

        if (isBlank(jobId) && isBlank(networkVersion) && isBlank(orgId)) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error",
                            "At least one filter is required: jobId, networkVersion, or orgId"));
        }

        Query q = new Query();
        if (!isBlank(jobId))           q.addCriteria(Criteria.where("jobId").is(jobId));
        if (!isBlank(networkVersion))  q.addCriteria(Criteria.where("networkVersion").is(networkVersion));
        if (!isBlank(orgId))           q.addCriteria(Criteria.where("orgId").is(orgId));

        try {
            long count = mongo.count(q, "cim_objects");
            mongo.remove(q, "cim_objects");
            log.info("Deleted {} cim_objects — jobId={} version={} orgId={}",
                    count, jobId, networkVersion, orgId);
            return ResponseEntity.ok(Map.of(
                    "deleted",        count,
                    "collection",     "cim_objects",
                    "jobId",          nullToEmpty(jobId),
                    "networkVersion", nullToEmpty(networkVersion),
                    "orgId",          nullToEmpty(orgId)
            ));
        } catch (Exception e) {
            log.error("Error deleting cim_objects: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // DELETE MongoDB Raw Objects
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Delete raw parsed objects from the raw_objects MongoDB collection.
     *
     * At least one filter is required.
     *
     * Examples:
     *   DELETE /api/data/raw-objects?jobId=abc123
     *   DELETE /api/data/raw-objects?networkVersion=DB142&orgId=CAISO
     */
    @DeleteMapping("/data/raw-objects")
    public ResponseEntity<?> deleteRawObjects(
            @RequestParam(required = false) String jobId,
            @RequestParam(required = false) String networkVersion,
            @RequestParam(required = false) String orgId) {

        if (isBlank(jobId) && isBlank(networkVersion) && isBlank(orgId)) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error",
                            "At least one filter is required: jobId, networkVersion, or orgId"));
        }

        Query q = new Query();
        if (!isBlank(jobId))           q.addCriteria(Criteria.where("jobId").is(jobId));
        if (!isBlank(networkVersion))  q.addCriteria(Criteria.where("networkVersion").is(networkVersion));
        if (!isBlank(orgId))           q.addCriteria(Criteria.where("orgId").is(orgId));

        try {
            long count = mongo.count(q, "raw_objects");
            mongo.remove(q, "raw_objects");
            log.info("Deleted {} raw_objects — jobId={} version={} orgId={}",
                    count, jobId, networkVersion, orgId);
            return ResponseEntity.ok(Map.of(
                    "deleted",        count,
                    "collection",     "raw_objects",
                    "jobId",          nullToEmpty(jobId),
                    "networkVersion", nullToEmpty(networkVersion),
                    "orgId",          nullToEmpty(orgId)
            ));
        } catch (Exception e) {
            log.error("Error deleting raw_objects: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // DELETE Neo4j Data
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Delete all Neo4j nodes and relationships for a given network version + orgId.
     *
     * This is a long-running operation for large graphs — runs synchronously.
     * Both parameters are required.
     *
     * Example:
     *   DELETE /api/admin/neo4j/data?version=DB142&orgId=CAISO
     *
     * curl:
     *   curl -X DELETE "http://server:9090/api/admin/neo4j/data?version=DB142&orgId=CAISO"
     */
    @DeleteMapping("/admin/neo4j/data")
    public ResponseEntity<?> deleteNeo4jData(
            @RequestParam String version,
            @RequestParam String orgId) {

        if (isBlank(version) || isBlank(orgId)) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Both 'version' and 'orgId' are required"));
        }

        log.info("DELETE Neo4j data requested: version={} orgId={}", version, orgId);
        try {
            neo4jExportService.deleteNeo4jData(version, orgId);
            log.info("DELETE Neo4j data complete: version={} orgId={}", version, orgId);
            return ResponseEntity.ok(Map.of(
                    "status",  "DELETED",
                    "version", version,
                    "orgId",   orgId,
                    "message", "All nodes and relationships deleted for version=" + version
                                + " orgId=" + orgId
            ));
        } catch (Exception e) {
            log.error("Error deleting Neo4j data version={} orgId={}: {}", version, orgId, e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "version", version, "orgId", orgId));
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Cancel / Suspend Import
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Cancel a running import job and clean up any partial data already written.
     *
     * Behaviour:
     *   - Signals the running import thread to stop at the next chunk boundary.
     *   - Waits up to 5 s for the thread to acknowledge (non-blocking poll).
     *   - Deletes all partial cim_objects and raw_objects for the job from MongoDB.
     *   - Marks the job as CANCELLED in MongoDB.
     *
     * Response codes:
     *   200 CANCELLED    — job was running; signal sent and data cleaned up.
     *   200 NOT_RUNNING  — job already in a terminal state (DONE/RESOLVED/FAILED/CANCELLED).
     *   404 NOT_FOUND    — no job with that jobId exists.
     *
     * Example:
     *   POST /api/import/abc123/cancel
     *
     * curl:
     *   curl -X POST http://server:9090/api/import/abc123/cancel
     */
    @PostMapping("/import/{jobId}/cancel")
    public ResponseEntity<?> cancelImport(@PathVariable String jobId) {
        if (isBlank(jobId)) {
            return ResponseEntity.badRequest().body(Map.of("error", "jobId is required"));
        }

        log.info("Cancel import requested: jobId={}", jobId);
        String result = importService.cancelJob(jobId);

        return switch (result) {
            case "NOT_FOUND"  -> ResponseEntity.status(404)
                    .body(Map.of("jobId", jobId, "status", "NOT_FOUND",
                            "message", "No import job found with jobId=" + jobId));
            case "NOT_RUNNING" -> ResponseEntity.ok()
                    .body(Map.of("jobId", jobId, "status", "NOT_RUNNING",
                            "message", "Job is already in a terminal state and cannot be cancelled"));
            case "CANCELLED"   -> ResponseEntity.ok()
                    .body(Map.of("jobId", jobId, "status", "CANCELLED",
                            "message", "Import cancelled; partial data has been cleaned up"));
            default            -> ResponseEntity.internalServerError()
                    .body(Map.of("jobId", jobId, "status", "ERROR",
                            "message", "Unexpected result: " + result));
        };
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────────────────────────────────

    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String  nullToEmpty(String s) { return s == null ? "" : s; }
}
