package com.cim.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * OpenAPI 3 configuration — springdoc auto-generates the spec from
 * @RestController/@GetMapping/@PostMapping etc. annotations at runtime.
 *
 * Live endpoints once the app is running:
 *   Swagger UI:    http://localhost:8080/swagger-ui.html
 *   OpenAPI JSON:  http://localhost:8080/v3/api-docs
 *   OpenAPI YAML:  http://localhost:8080/v3/api-docs.yaml
 *
 * This is preferable to a hand-maintained static YAML file because it can
 * never drift out of sync with the actual controller code — every new
 * @PostMapping etc. is picked up automatically on next restart.
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI cimPlatformOpenApi() {
        return new OpenAPI()
            .info(new Info()
                .title("CIM Network Data Import Platform API")
                .description(
                    "Imports IEC 61970/61968 CIM power system files (RDF/XML, " +
                    "JSON-LD, Milsoft CSV), validates against the CIM OWL " +
                    "hierarchy, stores results in MongoDB (raw_objects + " +
                    "cim_objects), and exports topology graphs to Neo4j with " +
                    "four version variants: FULL, SANITISED, RATIONALISED, CUSTOM.")
                .version("v5")
                .contact(new Contact()
                    .name("CIM Platform Team")
                    .email("cim-platform@oati.com"))
                .license(new License()
                    .name("Internal Use Only")))
            .servers(List.of(
                new Server().url("http://localhost:8080").description("Local development"),
                new Server().url("https://cim-platform.internal").description("Production")
            ));
    }
}
