package com.cim.service;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Phase 3 post-import enrichment for cim_objects.
 *
 * Computes derived attributes (nominalVoltage_1, substationMrid_1/Name_1 etc.)
 * by walking resolved reference chains in MongoDB, then stores them directly
 * on cim_objects. Raw objects (raw_objects) are left untouched — existing logic.
 *
 * ORGANISATION GATE:
 *   Currently enabled for CAISO only.
 *   To enable for another org, add it to ENRICHMENT_ENABLED_ORGS below.
 *   No other code changes needed — the gate is in one place.
 *
 * WHY THIS IS BETTER THAN POST-NEO4J ENRICHMENT:
 *   - Runs ONCE at import time, not per export variant (3x for FULL/SANITISED/RATIONALISED)
 *   - Uses fast MongoDB in-memory map lookups (O(1) per hop)
 *   - No Neo4j traversal needed — properties exported automatically
 *   - Queryable via REST API without any Neo4j export
 *
 * CHAINS RESOLVED (confirmed from CAISO graph analysis):
 *
 *   nominalVoltage:
 *     CimObject.resolvedRefIds["ConductingEquipment.BaseVoltage"] → baseVoltage.rdfId
 *     baseVoltage.attributes["BaseVoltage.nominalVoltage"]        → "115"
 *     → writes nominalVoltage_1 on the equipment object
 *
 *   substationMrid / substationName (unlimited, dynamic _N suffix):
 *     CimObject.rdfId ← Terminal.resolvedRefIds["Terminal.ConductingEquipment"]
 *     Terminal.resolvedRefIds["Terminal.ConnectivityNode"]             → cn.rdfId
 *     ConnectivityNode.resolvedRefIds["ConnectivityNodeContainer"]     → vl.rdfId
 *     VoltageLevel.resolvedRefIds["VoltageLevel.MemberOf_Substation"] → sub.rdfId
 *     Substation.mrid + Substation.attributes["IdentifiedObject.name"]
 *     → writes substationMrid_1, substationName_1, _2... (unlimited)
 */
@Service
public class CimEnrichmentService {

    private static final Logger log = LoggerFactory.getLogger(CimEnrichmentService.class);

    /**
     * ORGANISATION GATE — add org IDs here to enable Phase 3 enrichment.
     * Uses case-insensitive comparison.
     * To add ERCOT: just add "ERCOT" to this set. Nothing else changes.
     */
    private static final Set<String> ENRICHMENT_ENABLED_ORGS = new java.util.HashSet<>(
            Arrays.asList(
                "CAISO"
                // "ERCOT",   ← uncomment to enable for ERCOT
                // "SPC",     ← uncomment to enable for SPC
                // "MILSOFT"  ← uncomment to enable for Milsoft
            ));

    private static final int PAGE_SIZE   = 500;   // objects per processing page
    private static final int WRITE_BATCH = 200;   // MongoDB updates per bulk call

    private final MongoTemplate mongo;

    public CimEnrichmentService(MongoTemplate mongo) {
        this.mongo = mongo;
    }

    // ── Public entry point ────────────────────────────────────────────────

    /**
     * Called by ImportService after Phase 2 (reference resolution) completes.
     * Checks org gate before doing any work.
     *
     * @param jobId  the import job ID
     * @param orgId  the organisation ID — checked against ENRICHMENT_ENABLED_ORGS
     * @return true if enrichment ran, false if skipped (org not enabled)
     */
    public boolean enrich(String jobId, String orgId) {
        if (!isEnrichmentEnabled(orgId)) {
            log.info("CimEnrichment skipped for org={} (not in ENRICHMENT_ENABLED_ORGS)", orgId);
            return false;
        }

        long start = System.currentTimeMillis();
        log.info("CimEnrichment Phase 3 starting: job={} org={}", jobId, orgId);

        // ── Build in-memory lookup maps (lightweight projections from MongoDB) ──
        Map<String, String>       baseVoltageMap   = buildBaseVoltageMap(jobId);
        Map<String, List<String>> terminalsByEquip = buildTerminalsByEquipMap(jobId);
        Map<String, String>       cnByTerminal     = buildCnByTerminalMap(jobId);
        Map<String, String>       vlByCn           = buildVlByCnMap(jobId);
        // Build subByVl with SGR + GR info attached to each SubInfo
        Map<String, SubInfo>      subByVl          = buildSubByVlMap(jobId);
        enrichSubInfoWithSgrAndGr(jobId, subByVl);

        log.info("CimEnrichment maps: bv={} termsByEquip={} cnByT={} vlByCn={} subByVl={}",
                baseVoltageMap.size(), terminalsByEquip.size(),
                cnByTerminal.size(), vlByCn.size(), subByVl.size());

        // ── Process all cim_objects in pages ───────────────────────────────────
        long voltageCount    = 0;
        long substationCount = 0;
        String lastId = null;

        while (true) {
            List<CimObjectRecord> page = fetchPage(jobId, lastId);
            if (page.isEmpty()) break;
            lastId = page.get(page.size() - 1).getId();

            List<Map<String, Object>> updates = new ArrayList<>();

            for (CimObjectRecord rec : page) {
                Map<String, String> enriched = new LinkedHashMap<>();

                computeNominalVoltage(rec, baseVoltageMap, enriched);
                computeSubstations(rec, terminalsByEquip, cnByTerminal,
                        vlByCn, subByVl, enriched);

                if (!enriched.isEmpty()) {
                    if (enriched.containsKey(
                            MapKeySanitizer.encode("nominalVoltage_1"))) voltageCount++;
                    if (enriched.containsKey(
                            MapKeySanitizer.encode("substationMrid_1"))) substationCount++;
                    Map<String, Object> upd = new LinkedHashMap<>();
                    upd.put("id",      rec.getId());
                    upd.put("enriched", enriched);
                    updates.add(upd);
                }
            }

            // Bulk write sub-batches
            for (int from = 0; from < updates.size(); from += WRITE_BATCH) {
                bulkWrite(updates.subList(from,
                        Math.min(from + WRITE_BATCH, updates.size())));
            }
        }

        log.info("CimEnrichment done: job={} org={} time={} nominalVoltage={} substation={}",
                jobId, orgId,
                com.cim.model.mongo.StageTimings.format(
                        System.currentTimeMillis() - start),
                voltageCount, substationCount);
        return true;
    }

    // ── Organisation gate ─────────────────────────────────────────────────

    /** Case-insensitive check against ENRICHMENT_ENABLED_ORGS. */
    private boolean isEnrichmentEnabled(String orgId) {
        if (orgId == null) return false;
        return ENRICHMENT_ENABLED_ORGS.stream()
                .anyMatch(o -> o.equalsIgnoreCase(orgId.trim()));
    }

    // ── Lookup map builders ───────────────────────────────────────────────

    /**
     * BaseVoltage.rdfId → nominalVoltage string value.
     * Only BaseVoltage objects with a valid nominalVoltage attribute are included.
     */
    private Map<String, String> buildBaseVoltageMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String attrKey = MapKeySanitizer.encode("BaseVoltage.nominalVoltage");
        String lastId = null;
        while (true) {
            Query q = pageQuery(
                    Criteria.where("jobId").is(jobId).and("cimType").is("BaseVoltage"),
                    lastId);
            q.fields().include("rdfId").include("attributes." + attrKey);
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getAttributes() == null) continue;
                String val = r.getAttributes().get(attrKey);
                if (val != null && !val.isBlank())
                    map.put(r.getRdfId(), val);
            }
        }
        log.debug("buildBaseVoltageMap: {} entries", map.size());
        return map;
    }

    /**
     * equipment.rdfId → List of Terminal rdfIds that reference this equipment.
     * Inverted index built from Terminal.resolvedRefIds["Terminal.ConductingEquipment"].
     */
    private Map<String, List<String>> buildTerminalsByEquipMap(String jobId) {
        Map<String, List<String>> map = new HashMap<>();
        String refKey = MapKeySanitizer.encode("Terminal.ConductingEquipment");
        String lastId = null;
        while (true) {
            Query q = pageQuery(
                    Criteria.where("jobId").is(jobId).and("cimType").is("Terminal"),
                    lastId);
            q.fields().include("rdfId").include("resolvedRefIds." + refKey);
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String equipRdfId = r.getResolvedRefIds().get(refKey);
                if (equipRdfId == null || equipRdfId.isBlank()) continue;
                map.computeIfAbsent(equipRdfId, k -> new ArrayList<>())
                   .add(r.getRdfId());
            }
        }
        log.debug("buildTerminalsByEquipMap: {} equipment entries", map.size());
        return map;
    }

    /**
     * Terminal.rdfId → ConnectivityNode.rdfId.
     */
    private Map<String, String> buildCnByTerminalMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        String refKey = MapKeySanitizer.encode("Terminal.ConnectivityNode");
        String lastId = null;
        while (true) {
            Query q = pageQuery(
                    Criteria.where("jobId").is(jobId).and("cimType").is("Terminal"),
                    lastId);
            q.fields().include("rdfId").include("resolvedRefIds." + refKey);
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String cnRdfId = r.getResolvedRefIds().get(refKey);
                if (cnRdfId != null && !cnRdfId.isBlank())
                    map.put(r.getRdfId(), cnRdfId);
            }
        }
        log.debug("buildCnByTerminalMap: {} entries", map.size());
        return map;
    }

    /**
     * ConnectivityNode.rdfId → VoltageLevel.rdfId.
     * Tries ConnectivityNode.ConnectivityNodeContainer first, then ConnectivityNodeContainer.
     */
    private Map<String, String> buildVlByCnMap(String jobId) {
        Map<String, String> map = new HashMap<>();
        // Try both key variants — different CIM profiles use different attribute names
        List<String> refKeys = Arrays.asList(
                MapKeySanitizer.encode("ConnectivityNode.ConnectivityNodeContainer"),
                MapKeySanitizer.encode("ConnectivityNodeContainer"));
        String lastId = null;
        while (true) {
            Query q = pageQuery(
                    Criteria.where("jobId").is(jobId).and("cimType").is("ConnectivityNode"),
                    lastId);
            q.fields().include("rdfId").include("resolvedRefIds");
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                for (String key : refKeys) {
                    String vlRdfId = r.getResolvedRefIds().get(key);
                    if (vlRdfId != null && !vlRdfId.isBlank()) {
                        map.put(r.getRdfId(), vlRdfId);
                        break; // first matching key wins
                    }
                }
            }
        }
        log.debug("buildVlByCnMap: {} entries", map.size());
        return map;
    }

    /**
     * VoltageLevel.rdfId → SubInfo(mrid, name) of its parent Substation.
     * Two-step: VL → substationRdfId, then fetch Substation details.
     */
    private Map<String, SubInfo> buildSubByVlMap(String jobId) {
        // Step A: VoltageLevel → substationRdfId
        Map<String, String> subRdfByVl = new HashMap<>();
        String vlRefKey = MapKeySanitizer.encode("VoltageLevel.MemberOf_Substation");
        String lastId = null;
        while (true) {
            Query q = pageQuery(
                    Criteria.where("jobId").is(jobId).and("cimType").is("VoltageLevel"),
                    lastId);
            q.fields().include("rdfId").include("resolvedRefIds." + vlRefKey);
            List<CimObjectRecord> batch = mongo.find(q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            lastId = batch.get(batch.size() - 1).getId();
            for (CimObjectRecord r : batch) {
                if (r.getRdfId() == null || r.getResolvedRefIds() == null) continue;
                String subRdfId = r.getResolvedRefIds().get(vlRefKey);
                if (subRdfId != null && !subRdfId.isBlank())
                    subRdfByVl.put(r.getRdfId(), subRdfId);
            }
        }
        if (subRdfByVl.isEmpty()) return new HashMap<>();

        // Step B: fetch Substation mrid + name for each unique rdfId
        Set<String> uniqueSubRdfIds = new HashSet<>(subRdfByVl.values());
        Map<String, SubInfo> subInfoByRdfId = new HashMap<>();
        String nameKey = MapKeySanitizer.encode("IdentifiedObject.name");
        Query subQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("Substation")
                .and("rdfId").in(uniqueSubRdfIds));
        subQ.fields().include("rdfId").include("mrid").include("attributes." + nameKey);
        List<CimObjectRecord> subStations =
                mongo.find(subQ, CimObjectRecord.class, "cim_objects");
        for (CimObjectRecord r : subStations) {
            if (r.getRdfId() == null) continue;
            String name = r.getAttributes() != null
                    ? r.getAttributes().get(nameKey) : null;
            subInfoByRdfId.put(r.getRdfId(), new SubInfo(r.getMrid(), name));
        }

        // Step C: compose vlRdfId → SubInfo
        Map<String, SubInfo> result = new HashMap<>();
        for (Map.Entry<String, String> e : subRdfByVl.entrySet()) {
            SubInfo info = subInfoByRdfId.get(e.getValue());
            if (info != null) result.put(e.getKey(), info);
        }
        log.debug("buildSubByVlMap: {} vl→substation entries", result.size());
        return result;
    }

    /**
     * Enriches each SubInfo in the map with SGR (SubGeographicalRegion) and
     * GR (GeographicalRegion) mrid + name, by:
     *   Substation.resolvedRefIds["Substation.Region"]           → sgrRdfId
     *   SubGeographicalRegion.resolvedRefIds["SubGeographicalRegion.Region"] → grRdfId
     *
     * Mutates the SubInfo objects in place — avoids rebuilding the whole map.
     */
    private void enrichSubInfoWithSgrAndGr(String jobId,
                                            Map<String, SubInfo> subByVl) {
        if (subByVl.isEmpty()) return;

        // Collect all unique substationRdfIds we need to resolve
        // subByVl values have mrid = substationMrid; we need substationRdfId.
        // We stored substationRdfId in Step C of buildSubByVlMap —
        // but SubInfo only stores mrid/name. We need a reverse lookup.
        // APPROACH: query Substation objects directly by mrid to get rdfId + SGR ref.

        String subRegionKey = MapKeySanitizer.encode("Substation.Region");
        String nameKey      = MapKeySanitizer.encode("IdentifiedObject.name");

        // Collect distinct substation mrids from SubInfo values
        Set<String> subMrids = new HashSet<>();
        for (SubInfo si : subByVl.values()) {
            if (si.mrid != null && !si.mrid.isBlank()) subMrids.add(si.mrid);
        }
        if (subMrids.isEmpty()) return;

        // Fetch all matching Substation objects
        // Map: substationMrid → {rdfId, sgrRdfId}
        Map<String, String[]> subMridToRdfAndSgr = new HashMap<>();
        Query subQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("Substation")
                .and("mrid").in(subMrids));
        subQ.fields().include("rdfId").include("mrid")
                     .include("resolvedRefIds." + subRegionKey);
        List<CimObjectRecord> subs = mongo.find(subQ, CimObjectRecord.class, "cim_objects");
        for (CimObjectRecord r : subs) {
            if (r.getMrid() == null || r.getRdfId() == null) continue;
            String sgrRdfId = r.getResolvedRefIds() != null
                    ? r.getResolvedRefIds().get(subRegionKey) : null;
            subMridToRdfAndSgr.put(r.getMrid(),
                    new String[]{r.getRdfId(), sgrRdfId});
        }

        // Collect distinct SGR rdfIds
        Set<String> sgrRdfIds = new HashSet<>();
        for (String[] v : subMridToRdfAndSgr.values()) {
            if (v[1] != null && !v[1].isBlank()) sgrRdfIds.add(v[1]);
        }
        if (sgrRdfIds.isEmpty()) return;

        // Fetch SGR objects → get mrid, name, and GR rdfId
        String sgrRegionKey = MapKeySanitizer.encode("SubGeographicalRegion.Region");
        Map<String, String[]> sgrRdfToInfo = new HashMap<>(); // rdfId → [mrid, name, grRdfId]
        Query sgrQ = new Query(Criteria.where("jobId").is(jobId)
                .and("cimType").is("SubGeographicalRegion")
                .and("rdfId").in(sgrRdfIds));
        sgrQ.fields().include("rdfId").include("mrid")
                     .include("attributes." + nameKey)
                     .include("resolvedRefIds." + sgrRegionKey);
        List<CimObjectRecord> sgrs = mongo.find(sgrQ, CimObjectRecord.class, "cim_objects");
        for (CimObjectRecord r : sgrs) {
            if (r.getRdfId() == null) continue;
            String sgrName  = r.getAttributes() != null ? r.getAttributes().get(nameKey) : null;
            String grRdfId  = r.getResolvedRefIds() != null
                    ? r.getResolvedRefIds().get(sgrRegionKey) : null;
            sgrRdfToInfo.put(r.getRdfId(),
                    new String[]{r.getMrid(), sgrName, grRdfId});
        }

        // Collect distinct GR rdfIds
        Set<String> grRdfIds = new HashSet<>();
        for (String[] v : sgrRdfToInfo.values()) {
            if (v[2] != null && !v[2].isBlank()) grRdfIds.add(v[2]);
        }

        // Fetch GR objects → mrid + name
        Map<String, String[]> grRdfToInfo = new HashMap<>(); // rdfId → [mrid, name]
        if (!grRdfIds.isEmpty()) {
            Query grQ = new Query(Criteria.where("jobId").is(jobId)
                    .and("cimType").is("GeographicalRegion")
                    .and("rdfId").in(grRdfIds));
            grQ.fields().include("rdfId").include("mrid").include("attributes." + nameKey);
            List<CimObjectRecord> grs = mongo.find(grQ, CimObjectRecord.class, "cim_objects");
            for (CimObjectRecord r : grs) {
                if (r.getRdfId() == null) continue;
                String grName = r.getAttributes() != null ? r.getAttributes().get(nameKey) : null;
                grRdfToInfo.put(r.getRdfId(), new String[]{r.getMrid(), grName});
            }
        }

        // Now enrich SubInfo objects in subByVl
        for (SubInfo si : subByVl.values()) {
            if (si.mrid == null) continue;
            String[] subRdfAndSgr = subMridToRdfAndSgr.get(si.mrid);
            if (subRdfAndSgr == null || subRdfAndSgr[1] == null) continue;

            String sgrRdfId = subRdfAndSgr[1];
            String[] sgrInfo = sgrRdfToInfo.get(sgrRdfId);
            if (sgrInfo == null) continue;

            si.sgrRdfId = sgrRdfId;
            si.sgrMrid  = sgrInfo[0];
            si.sgrName  = sgrInfo[1];

            if (sgrInfo[2] != null) {
                String[] grInfo = grRdfToInfo.get(sgrInfo[2]);
                if (grInfo != null) {
                    si.grMrid = grInfo[0];
                    si.grName = grInfo[1];
                }
            }
        }
        log.debug("enrichSubInfoWithSgrAndGr: enriched {} substation entries", subByVl.size());
    }

    // ── Per-object computation ─────────────────────────────────────────────

    /**
     * Resolves nominalVoltage via direct BaseVoltage ref.
     * Adds nominalVoltage_1 to enriched map if found.
     */
    private void computeNominalVoltage(CimObjectRecord rec,
                                        Map<String, String> baseVoltageMap,
                                        Map<String, String> enriched) {
        if (rec.getResolvedRefIds() == null) return;
        String bvKey   = MapKeySanitizer.encode("ConductingEquipment.BaseVoltage");
        String bvRdfId = rec.getResolvedRefIds().get(bvKey);
        if (bvRdfId == null || bvRdfId.isBlank()) return;
        String voltage = baseVoltageMap.get(bvRdfId);
        if (voltage == null || voltage.isBlank()) return;
        enriched.put(MapKeySanitizer.encode("nominalVoltage_1"), voltage);
    }

    /**
     * Resolves substation(s) via Terminal → CN → VL → Substation chain.
     * Supports unlimited substations — adds substationMrid_N / substationName_N.
     * Deduplicates by substation mrid.
     */
    private void computeSubstations(CimObjectRecord rec,
                                     Map<String, List<String>> terminalsByEquip,
                                     Map<String, String> cnByTerminal,
                                     Map<String, String> vlByCn,
                                     Map<String, SubInfo> subByVl,
                                     Map<String, String> enriched) {
        if (rec.getRdfId() == null) return;
        List<String> terminals = terminalsByEquip.get(rec.getRdfId());
        if (terminals == null || terminals.isEmpty()) return;

        // Walk each terminal through the chain, collect distinct substations
        // LinkedHashMap preserves insertion order, keyed by mrid for dedup
        LinkedHashMap<String, SubInfo> found = new LinkedHashMap<>();
        for (String tRdfId : terminals) {
            String cnRdfId = cnByTerminal.get(tRdfId);
            if (cnRdfId == null) continue;
            String vlRdfId = vlByCn.get(cnRdfId);
            if (vlRdfId == null) continue;
            SubInfo sub = subByVl.get(vlRdfId);
            if (sub == null) continue;
            // Deduplicate by mrid (fallback to name if mrid is null)
            String dedupKey = sub.mrid != null ? sub.mrid : sub.name;
            if (dedupKey != null) found.put(dedupKey, sub);
        }

        if (found.isEmpty()) return;

        // Write substationMrid_N, substationName_N,
        //       subGeographicalRegionMrid_N, subGeographicalRegionName_N,
        //       geographicalRegionMrid_N, geographicalRegionName_N
        // (unlimited, same _N suffix for tie-lines with multiple substations)
        int idx = 1;
        for (SubInfo sub : found.values()) {
            // Substation
            if (sub.mrid != null && !sub.mrid.isBlank())
                enriched.put(MapKeySanitizer.encode("substationMrid_" + idx), sub.mrid);
            if (sub.name != null && !sub.name.isBlank())
                enriched.put(MapKeySanitizer.encode("substationName_" + idx), sub.name);
            // SubGeographicalRegion
            if (sub.sgrMrid != null && !sub.sgrMrid.isBlank())
                enriched.put(MapKeySanitizer.encode(
                        "subGeographicalRegionMrid_" + idx), sub.sgrMrid);
            if (sub.sgrName != null && !sub.sgrName.isBlank())
                enriched.put(MapKeySanitizer.encode(
                        "subGeographicalRegionName_" + idx), sub.sgrName);
            // GeographicalRegion (shared across substations in same region —
            // still stored per substation index for consistency)
            if (sub.grMrid != null && !sub.grMrid.isBlank())
                enriched.put(MapKeySanitizer.encode(
                        "geographicalRegionMrid_" + idx), sub.grMrid);
            if (sub.grName != null && !sub.grName.isBlank())
                enriched.put(MapKeySanitizer.encode(
                        "geographicalRegionName_" + idx), sub.grName);
            idx++;
        }
    }

    // ── Write ──────────────────────────────────────────────────────────────

    /**
     * Bulk-writes enriched attributes onto cim_objects documents.
     * Each entry in updates: {id: mongoId, enriched: {encodedKey: value, ...}}
     * Written into the existing attributes map: attributes.encodedKey = value
     *
     * NOTE: raw_objects are intentionally NOT touched here —
     * they remain in their original vendor-format shape (existing logic unchanged).
     */
    private void bulkWrite(List<Map<String, Object>> updates) {
        for (Map<String, Object> upd : updates) {
            String id = (String) upd.get("id");
            @SuppressWarnings("unchecked")
            Map<String, String> enriched = (Map<String, String>) upd.get("enriched");
            if (enriched == null || enriched.isEmpty()) continue;
            Update update = new Update();
            for (Map.Entry<String, String> e : enriched.entrySet()) {
                update.set("attributes." + e.getKey(), e.getValue());
            }
            try {
                mongo.updateFirst(
                    new Query(Criteria.where("_id").is(
                            new org.bson.types.ObjectId(id))),
                    update, "cim_objects");
            } catch (Exception ex) {
                log.warn("bulkWrite failed for id={}: {}", id, ex.getMessage());
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<CimObjectRecord> fetchPage(String jobId, String lastId) {
        Criteria c = Criteria.where("jobId").is(jobId);
        Query q = new Query(lastId == null ? c :
                new Criteria().andOperator(c,
                        Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId))))
                .limit(PAGE_SIZE)
                .with(Sort.by(Sort.Direction.ASC, "_id"));
        // Projection: only fields needed for enrichment calculation
        q.fields().include("rdfId").include("cimType")
                  .include("resolvedRefIds").include("mrid");
        return mongo.find(q, CimObjectRecord.class, "cim_objects");
    }

    private Query pageQuery(Criteria base, String lastId) {
        Criteria c = lastId == null ? base :
                new Criteria().andOperator(base,
                        Criteria.where("_id").gt(new org.bson.types.ObjectId(lastId)));
        return new Query(c).limit(PAGE_SIZE)
                .with(Sort.by(Sort.Direction.ASC, "_id"));
    }

    /** Holds Substation + its SGR + its GR info — resolved together at build time. */
    private static class SubInfo {
        final String mrid;
        final String name;
        // SubGeographicalRegion
        String sgrRdfId;
        String sgrMrid;
        String sgrName;
        // GeographicalRegion
        String grMrid;
        String grName;

        SubInfo(String mrid, String name) {
            this.mrid = mrid;
            this.name = name;
        }
    }
}
