package com.cim.service;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Downloads CIM files from a remote FTP server using credentials configured
 * in application.yml under the cim.ftp.* namespace.
 *
 * Usage:
 *   String localPath = ftpFileService.downloadFile("CAISO_EMS_20240101.xml");
 *   // localPath is an absolute path to a temp file — caller must delete when done.
 *
 * Config (application.yml):
 *   cim:
 *     ftp:
 *       host:           ftp.example.com
 *       port:           21
 *       username:       ftpuser
 *       password:       ftppassword
 *       remote-dir:     /cim-files
 *       local-temp-dir: /tmp/cim-ftp
 */
@Service
public class FtpFileService {

    private static final Logger log = LoggerFactory.getLogger(FtpFileService.class);

    @Value("${cim.ftp.host:}")
    private String host;

    @Value("${cim.ftp.port:21}")
    private int port;

    @Value("${cim.ftp.username:}")
    private String username;

    @Value("${cim.ftp.password:}")
    private String password;

    @Value("${cim.ftp.remote-dir:/}")
    private String remoteDir;

    @Value("${cim.ftp.local-temp-dir:/tmp/cim-ftp}")
    private String localTempDir;

    /**
     * When {@code true}, the remote FTP file is deleted after a successful import.
     * Controlled by {@code cim.ftp.delete-after-import} in application.yml.
     * Defaults to {@code false} — the file is left in place unless explicitly enabled.
     */
    @Value("${cim.ftp.delete-after-import:false}")
    private boolean deleteAfterImport;

    public boolean isDeleteAfterImport() { return deleteAfterImport; }

    /**
     * Downloads a single file from the configured FTP server.
     *
     * @param fileName  Plain file name (no directory). Must not contain path
     *                  separators — validated before use.
     * @return          Absolute path to the downloaded local temp file.
     *                  The caller is responsible for deleting this file when done.
     * @throws IOException  If connection, login, or download fails.
     */
    public String downloadFile(String fileName) throws IOException {
        validateConfig();
        validateFileName(fileName);

        // Ensure local temp directory exists
        Path tempDir = Paths.get(localTempDir);
        Files.createDirectories(tempDir);

        Path localFile = tempDir.resolve(fileName);
        String remotePath = buildRemotePath(fileName);

        log.info("FTP download starting: {}@{}:{}{} → {}",
                username, host, port, remotePath, localFile);

        FTPClient ftp = new FTPClient();
        try {
            // ── Connect ───────────────────────────────────────────────────
            ftp.connect(host, port);
            int reply = ftp.getReplyCode();
            if (!FTPReply.isPositiveCompletion(reply)) {
                throw new IOException("FTP server refused connection. Reply code: " + reply);
            }

            // ── Login ─────────────────────────────────────────────────────
            boolean loggedIn = ftp.login(username, password);
            if (!loggedIn) {
                throw new IOException("FTP login failed for user: " + username
                        + ". Check credentials in application.yml (cim.ftp.username/password).");
            }

            // ── Transfer mode ─────────────────────────────────────────────
            ftp.setFileType(FTP.BINARY_FILE_TYPE);   // binary — CIM files are XML/RDF
            ftp.enterLocalPassiveMode();              // passive mode — works through firewalls/NAT

            // ── Download ──────────────────────────────────────────────────
            try (OutputStream out = new BufferedOutputStream(
                    new FileOutputStream(localFile.toFile()))) {
                boolean success = ftp.retrieveFile(remotePath, out);
                if (!success) {
                    int rc = ftp.getReplyCode();
                    // Clean up empty file on failure
                    Files.deleteIfExists(localFile);
                    throw new IOException("FTP download failed for: " + remotePath
                            + ". Server reply code: " + rc
                            + " — check that the file exists in the FTP remote directory.");
                }
            }

            long sizeBytes = Files.size(localFile);
            log.info("FTP download complete: {} → {} ({} bytes, {:.2f} MB)",
                    remotePath, localFile, sizeBytes, sizeBytes / (1024.0 * 1024.0));

            return localFile.toAbsolutePath().toString();

        } catch (IOException e) {
            // Clean up partial file if download threw mid-stream
            Files.deleteIfExists(localFile);
            throw e;
        } finally {
            // ── Always disconnect ─────────────────────────────────────────
            try {
                if (ftp.isConnected()) {
                    ftp.logout();
                    ftp.disconnect();
                }
            } catch (IOException ex) {
                log.warn("FTP disconnect error (non-fatal): {}", ex.getMessage());
            }
        }
    }

    /**
     * Lists all files in the configured FTP remote directory.
     * Useful for admin/debug — not called during normal import.
     *
     * @return Array of file names in the remote directory.
     */
    public String[] listRemoteFiles() throws IOException {
        validateConfig();

        FTPClient ftp = new FTPClient();
        try {
            ftp.connect(host, port);
            if (!FTPReply.isPositiveCompletion(ftp.getReplyCode()))
                throw new IOException("FTP server refused connection.");

            if (!ftp.login(username, password))
                throw new IOException("FTP login failed for user: " + username);

            ftp.enterLocalPassiveMode();
            String[] names = ftp.listNames(remoteDir);
            log.info("FTP listRemoteFiles: {} files in {}", names == null ? 0 : names.length, remoteDir);
            return names == null ? new String[0] : names;

        } finally {
            try {
                if (ftp.isConnected()) { ftp.logout(); ftp.disconnect(); }
            } catch (IOException ex) {
                log.warn("FTP disconnect error: {}", ex.getMessage());
            }
        }
    }

    /**
     * Returns the size of a file on the FTP server in bytes, or -1 if unknown.
     *
     * Uses the FTP SIZE command (RFC 3659). Not all FTP servers support it;
     * when unsupported the command returns a 550 reply and this method returns -1.
     * The caller should treat -1 as "size unknown — assume large, use downloadFile()".
     *
     * A separate short-lived FTP connection is opened and immediately closed,
     * so this does not interfere with a subsequent openStream() call.
     *
     * @param fileName Plain file name, no path separators.
     * @return File size in bytes, or -1 if the server does not support SIZE.
     * @throws IOException If connection or login fails.
     */
    public long remoteFileSize(String fileName) throws IOException {
        validateConfig();
        validateFileName(fileName);
        String remotePath = buildRemotePath(fileName);

        FTPClient ftp = new FTPClient();
        ftp.setConnectTimeout(15_000);
        try {
            ftp.connect(host, port);
            if (!FTPReply.isPositiveCompletion(ftp.getReplyCode()))
                throw new IOException("FTP server refused connection.");
            if (!ftp.login(username, password))
                throw new IOException("FTP login failed for user: " + username);
            ftp.enterLocalPassiveMode();

            // SIZE command — returns -1 if not supported by server
            long size = ftp.getSize(remotePath);   // Commons Net 3.3+ wraps FTP SIZE
            log.debug("FTP SIZE {}: {} bytes", remotePath, size);
            return size;   // -1 if server returned 550 "SIZE not understood"
        } finally {
            try { if (ftp.isConnected()) { ftp.logout(); ftp.disconnect(); } }
            catch (IOException ex) { log.warn("FTP disconnect (size check): {}", ex.getMessage()); }
        }
    }

    /**
     * Opens a direct streaming connection to the FTP file — no local temp file written.
     *
     * Returns an InputStream that reads bytes directly from the FTP socket.
     * The FTP connection is kept alive for the lifetime of the stream and is
     * disconnected automatically when the stream is closed.
     *
     * IMPORTANT: The caller MUST close the returned stream when parsing is done,
     * even on exception. Use try-with-resources:
     *
     *   try (InputStream in = ftpFileService.openStream("grid.xml")) {
     *       importService.processAndResolve(in, ...);
     *   }
     *
     * TIMEOUT RISK: The FTP socket stays open during the entire parse. If the
     * parser is slow (e.g. large CIM file, heavy enrichment), the FTP server
     * may drop the connection mid-stream. Commons Net's default timeout is 0
     * (infinite) — but the FTP server itself may impose one. For large files
     * (> 50 MB) consider using downloadFile() instead (which downloads first,
     * then streams from local disk — no FTP socket timeout risk).
     *
     * @param fileName Plain file name, no path separators.
     * @return InputStream backed by the FTP data socket. Must be closed by caller.
     * @throws IOException If connection, login, or transfer command fails.
     */
    public InputStream openStream(String fileName) throws IOException {
        validateConfig();
        validateFileName(fileName);

        String remotePath = buildRemotePath(fileName);
        log.info("FTP stream open: {}@{}:{}{}", username, host, port, remotePath);

        FTPClient ftp = new FTPClient();
        // Give the FTP socket 10 minutes to transfer data before timing out.
        // Parsing a 200 MB CIM file takes ~30–60 s on typical hardware;
        // 600 000 ms is generous and avoids spurious timeout errors.
        ftp.setDataTimeout(600_000);
        ftp.setConnectTimeout(30_000);

        boolean connected = false;
        try {
            ftp.connect(host, port);
            connected = true;
            int reply = ftp.getReplyCode();
            if (!FTPReply.isPositiveCompletion(reply)) {
                throw new IOException("FTP server refused connection. Reply code: " + reply);
            }

            if (!ftp.login(username, password)) {
                throw new IOException("FTP login failed for user: " + username);
            }

            ftp.setFileType(FTP.BINARY_FILE_TYPE);
            ftp.enterLocalPassiveMode();

            InputStream ftpStream = ftp.retrieveFileStream(remotePath);
            if (ftpStream == null) {
                int rc = ftp.getReplyCode();
                throw new IOException("FTP stream open failed for: " + remotePath
                        + ". Server reply code: " + rc
                        + " — check that the file exists in the FTP remote directory.");
            }

            // Wrap in a stream that disconnects FTP when closed.
            // The AtomicBoolean ensures we only disconnect once even if
            // close() is called multiple times (FilterInputStream.close()
            // can be invoked by try-with-resources AND a finally block).
            final FTPClient ftpRef   = ftp;
            final AtomicBoolean done = new AtomicBoolean(false);

            return new FilterInputStream(new BufferedInputStream(ftpStream, 65536)) {
                @Override
                public void close() throws IOException {
                    if (!done.compareAndSet(false, true)) return;  // already closed
                    try {
                        super.close();             // close data socket / BufferedInputStream
                        ftpRef.completePendingCommand();   // read "226 Transfer complete"
                    } catch (IOException e) {
                        log.debug("FTP stream close: completePendingCommand error (usually harmless): {}", e.getMessage());
                    } finally {
                        try {
                            if (ftpRef.isConnected()) {
                                ftpRef.logout();
                                ftpRef.disconnect();
                            }
                            log.info("FTP stream closed: {}", remotePath);
                        } catch (IOException ex) {
                            log.warn("FTP disconnect error after stream close (non-fatal): {}", ex.getMessage());
                        }
                    }
                }
            };

        } catch (IOException e) {
            // If we got a connection but failed before returning the stream,
            // clean up immediately — the caller never gets a stream to close.
            if (connected) {
                try {
                    if (ftp.isConnected()) { ftp.logout(); ftp.disconnect(); }
                } catch (IOException ex) {
                    log.warn("FTP disconnect during error cleanup: {}", ex.getMessage());
                }
            }
            throw e;
        }
    }

    /**
     * Deletes a file from the remote FTP server.
     *
     * Opens a fresh FTP connection, sends DELE, then disconnects.
     * Logs a warning and returns {@code false} if the file does not exist
     * or the server rejects the delete — it does NOT throw, because a
     * missing-after-import file should not cause the whole pipeline to
     * appear failed.
     *
     * @param fileName Plain file name (no directory). Same name used for download.
     * @return {@code true} if the server confirmed deletion, {@code false} otherwise.
     * @throws IOException If the FTP connection or login itself fails.
     */
    public boolean deleteFile(String fileName) throws IOException {
        validateConfig();
        validateFileName(fileName);
        String remotePath = buildRemotePath(fileName);

        log.info("FTP delete: {}@{}:{}{}", username, host, port, remotePath);

        FTPClient ftp = new FTPClient();
        ftp.setConnectTimeout(15_000);
        try {
            ftp.connect(host, port);
            if (!FTPReply.isPositiveCompletion(ftp.getReplyCode()))
                throw new IOException("FTP server refused connection during delete.");
            if (!ftp.login(username, password))
                throw new IOException("FTP login failed for user: " + username);

            ftp.enterLocalPassiveMode();

            boolean deleted = ftp.deleteFile(remotePath);
            if (deleted) {
                log.info("FTP delete succeeded: {}", remotePath);
            } else {
                log.warn("FTP delete returned false (file may not exist or permission denied): {} — reply code: {}",
                        remotePath, ftp.getReplyCode());
            }
            return deleted;

        } finally {
            try {
                if (ftp.isConnected()) { ftp.logout(); ftp.disconnect(); }
            } catch (IOException ex) {
                log.warn("FTP disconnect error after delete (non-fatal): {}", ex.getMessage());
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String buildRemotePath(String fileName) {
        String dir = remoteDir.endsWith("/") ? remoteDir : remoteDir + "/";
        return dir + fileName;
    }

    private void validateFileName(String fileName) {
        if (fileName == null || fileName.isBlank())
            throw new IllegalArgumentException("fileName must not be blank.");
        // Reject any path traversal attempt
        String safe = new File(fileName).getName();
        if (!safe.equals(fileName))
            throw new IllegalArgumentException(
                "fileName must be a plain file name with no directory components: " + fileName);
    }

    private void validateConfig() {
        if (host == null || host.isBlank())
            throw new IllegalStateException(
                "cim.ftp.host is not configured in application.yml.");
        if (username == null || username.isBlank())
            throw new IllegalStateException(
                "cim.ftp.username is not configured in application.yml.");
    }
}
